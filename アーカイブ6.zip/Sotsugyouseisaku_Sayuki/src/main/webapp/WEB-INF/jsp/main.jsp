<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ page import="userMS.model.beans.UsersBeans"%>
<%
UsersBeans user = (UsersBeans) session.getAttribute("loginUser");
if (user == null) {
	response.sendRedirect("UsersLoginServlet");
	return;
}
%>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>SAYUKI SAKOTA - Official Portal</title>
<style>
/* --- 1. 全体設定 --- */
html {
	scroll-behavior: smooth;
}

body {
	margin: 0;
	padding: 0;
	font-family: 'Helvetica Neue', 'Hiragino Kaku Gothic ProN', Arial,
		sans-serif;
	background: #111;
	color: #fff;
	overflow-x: hidden;
}

/* --- 2. 上部固定ナビ --- */
.top-nav {
	position: fixed;
	top: 0;
	left: 0;
	width: 100%;
	height: 70px;
	background: rgba(0, 0, 0, 0.6);
	backdrop-filter: blur(10px);
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 0 40px;
	box-sizing: border-box;
	z-index: 1000;
	border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.nav-brand {
	font-size: 1.5em;
	font-weight: bold;
	color: #ff69b4;
	letter-spacing: 2px;
}

.nav-links {
	display: flex;
	gap: 30px;
}

.nav-links a {
	text-decoration: none;
	color: #eee;
	font-weight: bold;
	transition: 0.3s;
}

.nav-links a:hover {
	color: #ff69b4;
}

.nav-right-cluster {
	display: flex;
	align-items: center;
	gap: 20px;
}

.user-info {
	font-size: 0.85em;
	color: #aaa;
	white-space: nowrap;
}

.logout-link {
	color: #ff4d4d;
	text-decoration: none;
	font-weight: bold;
	margin-left: 5px;
}

/* --- 🌟 3. ハンバーガー＆バツ ボタン --- */
.hamburger {
	width: 35px; height: 24px; cursor: pointer;
	display: flex; flex-direction: column; justify-content: space-between;
	position: relative; z-index: 4000;
	transition: 0.4s;
}

.hamburger span {
	display: block; width: 100%; height: 3px;
	background-color: #ff69b4; /* サユキカラー */
	border-radius: 2px; transition: all 0.4s;
}

/* メニューを開いた時の状態（バツ印になる） */
.active-btn span:nth-child(1) {
	transform: translateY(10.5px) rotate(45deg); /* 1本目を斜めに */
}
.active-btn span:nth-child(2) {
	opacity: 0; /* 2本目は消える */
}
.active-btn span:nth-child(3) {
	transform: translateY(-10.5px) rotate(-45deg); /* 3本目を逆斜めに */
}

/* --- 🌟 4. 隠しメニュー画面 (Art.jspと統一) --- */
.full-menu {
	position: fixed; top: 0; right: -100%; width: 400px; height: 100vh;
	background: rgba(10, 10, 15, 0.98); border-left: 1px solid rgba(74, 144, 226, 0.3);
	z-index: 3500; transition: 0.5s cubic-bezier(0.4, 0, 0.2, 1); padding-top: 100px;
}
.full-menu.active { right: 0; }
.full-menu ul { list-style: none; padding: 0 50px; }
.full-menu ul li { margin-bottom: 25px; opacity: 0; transform: translateX(30px); transition: 0.5s; }
.full-menu.active ul li { opacity: 1; transform: translateX(0); }
/* 演出遅延 */
.full-menu.active ul li:nth-child(1) { transition-delay: 0.1s; }
.full-menu.active ul li:nth-child(2) { transition-delay: 0.2s; }
.full-menu.active ul li:nth-child(3) { transition-delay: 0.3s; }
.full-menu.active ul li:nth-child(4) { transition-delay: 0.4s; }
.full-menu.active ul li:nth-child(5) { transition-delay: 0.5s; }

.full-menu ul li a {
    color: #ccc; text-decoration: none; font-size: 1.4em; letter-spacing: 2px;
    transition: 0.3s; display: block; padding-bottom: 10px; border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}
.full-menu ul li a:hover { color: #ff69b4; border-bottom-color: #ff69b4; padding-left: 10px; }

/* --- 5. 各セクション設定 --- */
section {
	width: 100%;
	min-height: 100vh;
	display: flex;
	flex-direction: column;
	justify-content: center;
	align-items: center;
	padding: 80px 20px;
	box-sizing: border-box;
}

#top {
	background: linear-gradient(135deg, #1a1a2e, #16213e);
}

#game {
	background: linear-gradient(135deg, #2b1055, #7597de);
}

#prof {
	background: linear-gradient(135deg, #2c3e50, #3498db);
}

#art {
	background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
}

#item {
	background: linear-gradient(135deg, #141e30, #243b55);
}

.glass-panel {
	background: rgba(255, 255, 255, 0.1);
	backdrop-filter: blur(15px);
	border: 1px solid rgba(255, 255, 255, 0.2);
	padding: 50px;
	border-radius: 20px;
	text-align: center;
	max-width: 800px;
	width: 90%;
}

/* --- 6. ボタンのデザイン --- */
.btn-container {
	margin-top: 30px;
	display: flex;
	justify-content: center;
	gap: 20px;
	flex-wrap: wrap;
}

.action-btn {
	display: inline-block;
	padding: 15px 30px;
	background: #ff69b4;
	color: #fff;
	text-decoration: none;
	font-size: 1.1em;
	font-weight: bold;
	border-radius: 30px;
	transition: 0.3s;
	border: none;
	cursor: pointer;
}

.action-btn:hover {
	background: #ff1493;
	transform: translateY(-3px);
	box-shadow: 0 5px 15px rgba(255, 105, 180, 0.4);
}

.btn-continue {
	background: #4169e1;
}

.btn-continue:hover {
	background: #1e90ff;
	box-shadow: 0 5px 15px rgba(65, 105, 225, 0.4);
}

.btn-danger {
	background: #dc143c;
}

.btn-danger:hover {
	background: #ff0000;
	box-shadow: 0 5px 15px rgba(220, 20, 60, 0.4);
}

/* --- 🌟 モーダル共通スタイル (アニメーション対応版) --- */
.save-modal {
    /* 💡 display:none をやめて、visibility と opacity で見えなくする */
    visibility: hidden; 
    opacity: 0;
    
    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0, 0, 0, 0.85); backdrop-filter: blur(15px);
    z-index: 5000; display: flex; justify-content: center; align-items: center;
    
    /* 背景のフェードイン時間 */
    transition: opacity 0.4s ease, visibility 0.4s ease;
}

/* 💡 activeが付いた時に表示される */
.save-modal.active {
    visibility: visible; 
    opacity: 1;
}

.modal-content {
    background: rgba(15, 15, 25, 0.95); border: 2px solid #ff69b4;
    border-radius: 30px; padding: 40px; width: 500px; text-align: center;
    box-shadow: 0 0 40px rgba(255, 105, 180, 0.2);
    
    /* 💡 アニメーションの初期状態（少し下にあって、少し小さい） */
    transform: translateY(40px) scale(0.9);
    opacity: 0;
    
    /* cubic-bezierを使って、ちょっと跳ねるような弾力のある動きを作る */
    transition: transform 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275), opacity 0.4s ease;
}

/* 💡 activeが付いた時に、本来の位置とサイズに戻る */
.save-modal.active .modal-content {
    transform: translateY(0) scale(1);
    opacity: 1;
}

.modal-title {
	font-size: 1.6em;
	color: #ff69b4;
	margin-bottom: 25px;
	letter-spacing: 4px;
	font-weight: bold;
}

.slot-list {
	display: flex;
	flex-direction: column;
	gap: 15px;
}

.slot-card {
	background: rgba(255, 255, 255, 0.03);
	border: 1px solid rgba(255, 255, 255, 0.1);
	border-left: 6px solid #ff69b4;
	padding: 18px;
	border-radius: 12px;
	cursor: pointer;
	transition: 0.3s;
	display: flex;
	justify-content: space-between;
	align-items: center;
}

.slot-card:hover:not(.empty-load) {
	background: rgba(255, 105, 180, 0.15);
	border-color: #ff69b4;
	transform: translateX(10px);
}

.slot-card.empty-load {
	cursor: default;
	border-left-color: #444;
	opacity: 0.6;
}

.slot-info {
	text-align: left;
}

.slot-label {
	font-size: 0.8em;
	font-weight: bold;
	display: block;
	margin-bottom: 5px;
}

.slot-detail {
	display: flex;
	gap: 12px;
	font-size: 0.9em;
	color: #ccc;
}

.detail-tag {
	background: rgba(255, 255, 255, 0.1);
	padding: 2px 8px;
	border-radius: 4px;
}

.detail-tag b {
	color: #ff69b4;
}

.btn-cancel {
	margin-top: 25px;
	background: none;
	border: none;
	color: #888;
	cursor: pointer;
	text-decoration: underline;
	font-size: 1em;
}

/* くるくるローダー */
#loader-wrapper {
	position: fixed;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	background: #05050a;
	display: none;
	flex-direction: column;
	justify-content: center;
	align-items: center;
	z-index: 9999;
}

.atelier-loader {
	width: 60px;
	height: 60px;
	border: 5px solid rgba(255, 105, 180, 0.2);
	border-top: 5px solid #ff69b4;
	border-radius: 50%;
	animation: spin 1s linear infinite;
	margin-bottom: 20px;
}

.loader-text {
	color: #ff69b4;
	font-weight: bold;
	letter-spacing: 4px;
	font-size: 1.2em;
	animation: pulse 1.5s infinite;
}

@
keyframes spin { 0% {
	transform: rotate(0deg);
}

100


%
{
transform


:


rotate
(


360deg


)
;


}
}
@
keyframes pulse { 0%, 100% {
	opacity: 1;
}
50


%
{
opacity


:


0
.4
;


}
}
</style>
</head>
<body>
	<div id="loader-wrapper">
		<div class="atelier-loader"></div>
		<div class="loader-text">ACCESSING ATELIER...</div>
	</div>

	<nav class="full-menu" id="full-menu">
		<ul>
			<li><a href="MainServlet">Portal Top</a></li>
			<li><a href="#game">Atelier Game</a></li>
			<li><a href="ProfServlet">Official Profile</a></li>
			<li><a href="ArtServlet">Illustration Gallery</a></li>
			<li><a href="ItemServlet">Technical Tools</a></li>
		</ul>
	</nav>

	<nav class="top-nav">
		<div class="nav-brand">SAYUKI PORTAL</div>
		<div class="nav-links">
			<a href="#top">HOME</a> <a href="#game">GAME</a> <a href="#prof">PROFILE</a>
			<a href="#art">GALLERY</a> <a href="#item">TOOLS</a>
		</div>
		<div class="nav-right-cluster">
			<div class="user-info">
				Welcome,
				<%=user.getHn()%>
				| <a href="UsersLoginServlet" class="logout-link">Logout</a>
			</div>
			<div class="hamburger" id="ham-btn">
				<span></span> <span></span> <span></span>
			</div>
		</div>
	</nav>

	<section id="top">
		<div class="glass-panel">
			<h2>Welcome to the Atelier</h2>
			<p>
				ここは、迫田サユキの全てが交差する場所。<br>下へスクロールして、彼女の様々な顔を覗いてみてください。
			</p>
		</div>
	</section>

	<section id="game">
		<div class="glass-panel">
			<h2>サユキのアトリエ</h2>
			<p>
				彼女との1年間の物語。<br>あなたの選択が、彼女の未来を形作ります。
			</p>

			<div class="btn-container">
				<%
				if ("guest".equals(user.getId())) {
				%>
				<p style="color: #ff4d4d; font-weight: bold; width: 100%;">⚠️
					ゲストモードではセーブ機能は利用できません</p>
				<a href="SayukiGameServlet?mode=new&slotId=1" class="action-btn">最初からプレイ（セーブ不可）</a>
				<%
				} else {
				%>

				<button type="button" class="action-btn btn-danger"
					onclick="openNewGameModal()">NEW GAME</button>

				<c:if test="${hasSaveData}">
					<button type="button" class="action-btn btn-continue"
						onclick="openLoadModal()">CONTINUE</button>
				</c:if>

				<%
				}
				%>
			</div>
		</div>
	</section>

	<section id="prof">
		<div class="glass-panel">
			<h2>Who is Sayuki?</h2>
			<a href="ProfServlet" class="action-btn">プロフィールを閲覧</a>
		</div>
	</section>
	<section id="art">
		<div class="glass-panel">
			<h2>Illustration Gallery</h2>
			<a href="ArtServlet" class="action-btn">ギャラリーに入る</a>
		</div>
	</section>
	<section id="item">
		<div class="glass-panel">
			<h2>Technical Tools</h2>
			<a href="ItemServlet" class="action-btn">ツールをダウンロード</a>
		</div>
	</section>


	<div id="load-modal" class="save-modal">
		<div class="modal-content">
			<div class="modal-title">LOAD PROGRESS</div>

			<div class="slot-list">
				<c:forEach var="slot" items="${saveSlots}" varStatus="status">
					<c:set var="hasData" value="${not empty slot}" />
					<div class="slot-card ${hasData ? '' : 'empty-load'}"
						<c:if test="${hasData}">onclick="executeLoad(${status.count})"</c:if>>
						<div class="slot-info">
							<span class="slot-label" style="color: #ff69b4;">SLOT
								0${status.count}</span>
							<c:choose>
								<c:when test="${hasData}">
									<div class="slot-detail">
										<span class="detail-tag">WEEK: <b>${slot.currentTurn}</b></span>
										<span class="detail-tag">LOVE: <b>${slot.lovePoint}</b></span>
										<span class="detail-tag">LIKE: <b>${slot.likePoint}</b></span>
									</div>
								</c:when>
								<c:otherwise>
									<div style="color: #555; font-style: italic; margin-top: 5px;">---
										NO DATA ---</div>
								</c:otherwise>
							</c:choose>
						</div>
						<c:if test="${hasData}">
							<span style="font-size: 1.4em">📂</span>
						</c:if>
					</div>
				</c:forEach>
			</div>

			<button type="button" class="btn-cancel" onclick="closeLoadModal()">CLOSE</button>
		</div>
	</div>

	<div id="new-modal" class="save-modal">
		<div class="modal-content" style="border-color: #dc143c;">
			<div class="modal-title" style="color: #dc143c;">SELECT NEW
				GAME SLOT</div>

			<div class="slot-list">
				<c:forEach var="slot" items="${saveSlots}" varStatus="status">
					<c:set var="hasData" value="${not empty slot}" />
					<div class="slot-card"
						style="border-left-color: ${hasData ? '#dc143c' : '#666'}; cursor: pointer;"
						onclick="executeNewGame(${status.count}, ${hasData ? 'true' : 'false'})">
						<div class="slot-info">
							<span class="slot-label"
								style="color: ${hasData ? '#dc143c' : '#ccc'};">SLOT
								0${status.count}</span>
							<c:choose>
								<c:when test="${hasData}">
									<div class="slot-detail">
										<span class="detail-tag">WEEK: <b
											style="color: #dc143c;">${slot.currentTurn}</b></span> <span
											class="detail-tag">LOVE: <b style="color: #dc143c;">${slot.lovePoint}</b></span>
										<span class="detail-tag">LIKE: <b
											style="color: #dc143c;">${slot.likePoint}</b></span>
									</div>
									<div
										style="color: #ff4d4d; font-size: 0.8em; margin-top: 5px; font-weight: bold;">⚠️
										上書きされます</div>
								</c:when>
								<c:otherwise>
									<div style="color: #aaa; font-style: italic; margin-top: 5px;">---
										EMPTY (新規作成) ---</div>
								</c:otherwise>
							</c:choose>
						</div>
						<span style="font-size: 1.4em">${hasData ? '⚠️' : '✨'}</span>
					</div>
				</c:forEach>
			</div>

			<button type="button" class="btn-cancel"
				onclick="closeNewGameModal()">CLOSE</button>
		</div>
	</div>


	<script>
        // ハンバーガーメニュー
        document.addEventListener('DOMContentLoaded', () => {
            const hamBtn = document.getElementById('ham-btn');
            const fullMenu = document.getElementById('full-menu');
            if (hamBtn && fullMenu) {
                hamBtn.addEventListener('click', () => {
                    hamBtn.classList.toggle('active-btn');
                    fullMenu.classList.toggle('active');
                });
            }
        });

        // 🌟 ロードモーダル制御
        function openLoadModal() { document.getElementById('load-modal').classList.add('active'); }
        function closeLoadModal() { document.getElementById('load-modal').classList.remove('active'); }
        function executeLoad(slotId) {
            window.location.href = "SayukiGameServlet?mode=continue&slotId=" + slotId;
        }

		// 🌟 NEW GAMEモーダル制御
        function openNewGameModal() { document.getElementById('new-modal').classList.add('active'); }
        function closeNewGameModal() { document.getElementById('new-modal').classList.remove('active'); }
        function executeNewGame(slotId, hasData) {
            if (hasData) {
                if (!confirm("スロット 0" + slotId + " には既にデータがあります。\n上書きして最初からゲームを始めますか？")) {
                    return; 
                }
            }
            window.location.href = "SayukiGameServlet?mode=new&slotId=" + slotId;
        }
    </script>
</body>
</html>