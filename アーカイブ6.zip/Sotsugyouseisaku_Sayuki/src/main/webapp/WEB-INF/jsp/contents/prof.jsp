<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%-- 🌟 元の安定したJSTLのURIに戻しました --%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ page import="userMS.model.beans.UsersBeans"%>
<%
UsersBeans user = (UsersBeans) session.getAttribute("loginUser");
if (user == null) {
	response.sendRedirect("UsersLoginServlet");
	return;
}
%>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>Profile - SAYUKI PORTAL</title>
<style>
/* --- 1. 全体設定 --- */
body { margin: 0; padding: 0; background: #0a0a14; color: #fff; font-family: 'Helvetica Neue', 'Hiragino Kaku Gothic ProN', Arial, sans-serif; overflow: hidden; background: radial-gradient(circle at 70% 30%, #2b1055 0%, #05050a 80%); }

/* --- 2. 共通ナビゲーション --- */
.hamburger { position: fixed; top: 35px; right: 40px; width: 35px; height: 24px; cursor: pointer; display: flex; flex-direction: column; justify-content: space-between; z-index: 4000; }
.hamburger span { display: block; width: 100%; height: 3px; background-color: #ff69b4; border-radius: 2px; transition: all 0.4s; }
.active-btn span:nth-child(1) { transform: translateY(10.5px) rotate(45deg); }
.active-btn span:nth-child(2) { opacity: 0; }
.active-btn span:nth-child(3) { transform: translateY(-10.5px) rotate(-45deg); }

/* 隠しメニュー */
.full-menu { position: fixed; top: 0; right: -100%; width: 400px; height: 100vh; background: rgba(10, 10, 15, 0.98); border-left: 1px solid rgba(255, 105, 180, 0.3); z-index: 3500; transition: 0.5s cubic-bezier(0.4, 0, 0.2, 1); padding-top: 100px; }
.full-menu.active { right: 0; }
.full-menu ul { list-style: none; padding: 0 50px; }
.full-menu ul li { margin-bottom: 25px; opacity: 0; transform: translateX(30px); transition: 0.5s; }
.full-menu.active ul li { opacity: 1; transform: translateX(0); }
.full-menu.active ul li:nth-child(1) { transition-delay: 0.1s; }
.full-menu.active ul li:nth-child(2) { transition-delay: 0.2s; }
.full-menu.active ul li:nth-child(3) { transition-delay: 0.3s; }
.full-menu.active ul li:nth-child(4) { transition-delay: 0.4s; }
.full-menu.active ul li:nth-child(5) { transition-delay: 0.5s; }
.full-menu.active ul li:nth-child(6) { transition-delay: 0.6s; }
.full-menu ul li a { color: #ccc; text-decoration: none; font-size: 1.4em; letter-spacing: 2px; transition: 0.3s; display: block; padding-bottom: 10px; border-bottom: 1px solid rgba(255, 255, 255, 0.05); }
.full-menu ul li a:hover { color: #ff69b4; border-bottom-color: #ff69b4; padding-left: 10px; }

.user-greeting { color: #aaa; font-size: 1.1em; display: block; padding-bottom: 10px; border-bottom: 1px solid rgba(255, 105, 180, 0.5); letter-spacing: 1px; }
.logout-btn { color: #ff4d4d !important; border-bottom-color: rgba(255, 77, 77, 0.3) !important; }
.logout-btn:hover { color: #ff0000 !important; border-bottom-color: #ff0000 !important; }

/* =========================================
   🌟 キャラクター紹介レイアウト
========================================= */
.profile-viewport { display: flex; width: 100vw; height: 100vh; align-items: center; justify-content: flex-end; padding-right: 8vw; box-sizing: border-box; }
.char-showcase { position: absolute; left: 5vw; bottom: -5vh; height: 95vh; z-index: 10; pointer-events: none; animation: slideUpFade 1.2s forwards; }
.char-showcase img { height: 100%; width: auto; filter: drop-shadow(10px 10px 25px rgba(0, 0, 0, 0.7)); }
.bg-text { position: absolute; left: -2vw; top: 20vh; font-size: 15vw; font-weight: 900; color: rgba(255, 255, 255, 0.02); z-index: 1; pointer-events: none; white-space: nowrap; letter-spacing: -5px; transform: rotate(-5deg); }

/* 🌟 修正ポイント：opacity: 0 を削除し、Eclipseのフォーマットバグでアニメーションが死んでも確実に表示されるようにしました */
.info-panel { 
    width: 48vw; max-width: 700px; height: 75vh; z-index: 20; 
    background: linear-gradient(135deg, rgba(20, 20, 30, 0.8), rgba(10, 10, 15, 0.9)); 
    backdrop-filter: blur(20px); border: 1px solid rgba(255, 255, 255, 0.05); 
    border-top: 1px solid rgba(255, 105, 180, 0.3); border-bottom: 1px solid rgba(255, 105, 180, 0.3); 
    padding: 40px 50px; position: relative; 
    animation: slideLeftFade 1s forwards; /* 安全なアニメーション呼び出し */
    overflow-y: auto; overflow-x: hidden; 
}
.info-panel::-webkit-scrollbar { width: 6px; }
.info-panel::-webkit-scrollbar-thumb { background: #ff69b4; border-radius: 3px; }

.role-title { color: #ff69b4; font-size: 1.1em; letter-spacing: 5px; margin-bottom: 10px; font-weight: bold; }
.char-name { font-size: 3.5em; font-weight: 900; margin: 0 0 5px 0; letter-spacing: 2px; }
.char-name-sub { font-size: 1.2em; color: #888; font-weight: 300; letter-spacing: 3px; display: block; margin-bottom: 30px; }
.char-quote { font-size: 1.1em; line-height: 1.8; color: #ddd; font-style: italic; border-left: 4px solid #ff69b4; padding-left: 20px; margin-bottom: 40px; background: rgba(255, 105, 180, 0.05); padding: 20px; border-radius: 0 10px 10px 0; }
.attr-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
.attr-box { background: rgba(0, 0, 0, 0.3); border: 1px solid rgba(255, 255, 255, 0.08); padding: 20px; border-radius: 12px; }
.attr-label { font-size: 0.8em; color: #ff69b4; letter-spacing: 2px; margin-bottom: 8px; display: block; text-transform: uppercase; font-weight: bold; }
.attr-value { font-size: 1.0em; color: #eee; line-height: 1.6; }
.locked-ui { display: flex; align-items: center; gap: 8px; color: #777; font-size: 0.9em; }
.locked-ui span { background: rgba(255, 255, 255, 0.1); padding: 4px 10px; border-radius: 20px; font-size: 0.8em; letter-spacing: 1px; color: #ccc; }

@keyframes slideUpFade { 
    0% { transform: translateY(50px); } 
    100% { transform: translateY(0); } 
}
@keyframes slideLeftFade { 
    0% { transform: translateX(50px); } 
    100% { transform: translateX(0); } 
}

/* =========================================
   🌟 ゲーム選択モーダル用CSS
========================================= */
.save-modal { visibility: hidden; opacity: 0; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.85); backdrop-filter: blur(15px); z-index: 5000; display: flex; justify-content: center; align-items: center; transition: opacity 0.4s ease, visibility 0.4s ease; }
.save-modal.active { visibility: visible; opacity: 1; }
.modal-content { background: rgba(15, 15, 25, 0.95); border: 2px solid #ff69b4; border-radius: 30px; padding: 40px; width: 500px; text-align: center; box-shadow: 0 0 40px rgba(255, 105, 180, 0.2); transform: translateY(40px) scale(0.9); transition: transform 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
.save-modal.active .modal-content { transform: translateY(0) scale(1); }
.modal-title { font-size: 1.6em; color: #ff69b4; margin-bottom: 25px; letter-spacing: 4px; font-weight: bold; }
.slot-list { display: flex; flex-direction: column; gap: 15px; }
.slot-card { background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.1); border-left: 6px solid #ff69b4; padding: 18px; border-radius: 12px; cursor: pointer; transition: 0.3s; display: flex; justify-content: space-between; align-items: center; }
.slot-card:hover:not(.empty-load) { background: rgba(255, 105, 180, 0.15); border-color: #ff69b4; transform: translateX(10px); }
.slot-card.empty-load { cursor: default; border-left-color: #444; opacity: 0.6; }
.slot-info { text-align: left; }
.slot-label { font-size: 0.8em; font-weight: bold; display: block; margin-bottom: 5px; }
.slot-detail { display: flex; gap: 12px; font-size: 0.9em; color: #ccc; }
.detail-tag { background: rgba(255, 255, 255, 0.1); padding: 2px 8px; border-radius: 4px; }
.detail-tag b { color: #ff69b4; }
.btn-cancel { margin-top: 25px; background: none; border: none; color: #888; cursor: pointer; text-decoration: underline; font-size: 1em; }
.game-choice-btn { display: block; width: 100%; padding: 15px; margin-bottom: 15px; background: #4169e1; color: white; border: none; border-radius: 10px; font-size: 1.2em; font-weight: bold; cursor: pointer; transition: 0.3s; }
.game-choice-btn.new-game { background: #dc143c; }
.game-choice-btn:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(255, 255, 255, 0.2); }
</style>
</head>
<body>

	<div class="hamburger" id="ham-btn">
		<span></span> <span></span> <span></span>
	</div>

	<nav class="full-menu" id="full-menu">
		<ul>
			<li><span class="user-greeting">Welcome, <%=user.getHn()%></span></li>
			<li><a href="MainServlet">Portal Top</a></li>
			<li><a href="#" onclick="openGameSelectModal(event)">Atelier Game</a></li>
			<li><a href="ProfServlet" style="color: #ff69b4; border-bottom-color: #ff69b4;">Official Profile</a></li>
			<li><a href="ArtServlet">Illustration Gallery</a></li>
			<li><a href="ItemServlet">Technical Tools</a></li>
			<li><a href="#" class="logout-btn" onclick="confirmLogout(event)">Logout</a></li>
		</ul>
	</nav>

	<div class="bg-text">ILLUSTRATOR</div>

	<div class="profile-viewport">
		<div class="char-showcase">
			<img src="${pageContext.request.contextPath}/images/prof/sayuki_normal.png" alt="サユキ">
		</div>

		<div class="info-panel">
			<div class="role-title">ILLUSTRATOR</div>
			<h1 class="char-name">迫田 サユキ</h1>
			<span class="char-name-sub">SAKOTA SAYUKI</span>

			<div class="char-quote">
				<c:choose>
					<c:when test="${unlocks.personalUnlocked}">
						「休日はもっぱらコーヒーを飲みながらコードを書いています。<br>
						……最近は、あなたと話す時間が一番の息抜きかも。」
					</c:when>
					<c:otherwise><div class="locked-ui"><span>🔒 LOCKED</span> 親愛度(Love 50)で解放</div></c:otherwise>
				</c:choose>
			</div>

			<div class="attr-grid">
				<div class="attr-box" style="grid-column: span 2;">
					<span class="attr-label">Basic Info</span> <span class="attr-value">
						10月14日生まれ / てんびん座 / 血液型A型<br> 身長: 158cm
					</span>
				</div>

				<div class="attr-box">
					<span class="attr-label">Work Style & Tools</span> <span class="attr-value">
                        <c:choose>
							<c:when test="${unlocks.workUnlocked}">
								【本業】イラストレーター<br>
								【ツール】CLIP STUDIO PAINT, Live2D<br>
								プログラミングは絶賛勉強中の初心者。
							</c:when>
							<c:otherwise><div class="locked-ui"><span>🔒 LOCKED</span> 信頼度(Like 30)</div></c:otherwise>
						</c:choose>
					</span>
				</div>

				<div class="attr-box">
					<span class="attr-label">Favorite / Dislike</span> <span class="attr-value">
                        <c:choose>
							<c:when test="${unlocks.likesUnlocked}">
								<b style="color: #ffb3d9;">好き：</b>甘いカフェラテ。<br>
								<span style="font-size: 0.85em; color: #aaa;">（仕事中は強がってブラックのフリをしているが、裏でシロップを大量に入れている）</span><br><br>
								<b style="color: #b3d9ff;">嫌い：</b>トマト。<br>
								<span style="font-size: 0.85em; color: #aaa;">（あのグチャッとした食感がどうしても無理らしい）</span>
							</c:when>
							<c:otherwise><div class="locked-ui"><span>🔒 LOCKED</span> 親愛度(Love 30)</div></c:otherwise>
						</c:choose>
					</span>
				</div>

				<div class="attr-box" style="grid-column: span 2;">
					<span class="attr-label">Measurements</span> <span class="attr-value">
                        <c:choose>
							<c:when test="${unlocks.sizesUnlocked}">
								B82 / W56 / H83<br>
								<span style="font-style: italic; color: #ffb3d9;">「……ちょっと。私の立ち絵をジロジロ見ながら数値確認するのやめてもらえます？セクハラで通報しますよ」</span>
							</c:when>
							<c:otherwise><div class="locked-ui"><span>🔒 LOCKED</span> 親愛度(Love 80)で解放</div></c:otherwise>
						</c:choose>
					</span>
				</div>

				<div class="attr-box" style="grid-column: span 2;">
					<span class="attr-label">Secret Account</span> <span class="attr-value">
                        <c:choose>
							<c:when test="${unlocks.secretUnlocked}">
								<b style="color: #ff69b4;">【TOP SECRET】</b><br>
								実は美少女アニメやゲームの熱狂的なガチオタク。<br>
								誰にも言っていない裏アカウントが存在し、そこでは毎晩のように作画考察や、熱量の高すぎるファンアートを連投している。
							</c:when>
							<c:otherwise><div class="locked-ui"><span>🔒 TOP SECRET</span> トゥルー条件で解放</div></c:otherwise>
						</c:choose>
					</span>
				</div>
			</div>
		</div>
	</div>

	<div id="game-select-modal" class="save-modal">
		<div class="modal-content">
			<div class="modal-title" style="color: #fff;">START GAME</div>
			<% if ("guest".equals(user.getId())) { %>
			<p style="color: #ff4d4d; font-weight: bold; margin-bottom: 20px;">⚠️ ゲストモードではセーブ機能は利用できません</p>
			<button class="game-choice-btn new-game" onclick="window.location.href='SayukiGameServlet?mode=new&slotId=1'">最初からプレイ</button>
			<% } else { %>
			<button class="game-choice-btn new-game" onclick="openNewGameModal()">NEW GAME (最初から)</button>
			<c:if test="${not empty saveSlots}">
				<button class="game-choice-btn" onclick="openLoadModal()">CONTINUE (続きから)</button>
			</c:if>
			<% } %>
			<button type="button" class="btn-cancel" onclick="closeAllModals()">CLOSE</button>
		</div>
	</div>

	<div id="load-modal" class="save-modal">
		<div class="modal-content">
			<div class="modal-title">LOAD PROGRESS</div>
			<div class="slot-list">
				<c:forEach var="slot" items="${saveSlots}" varStatus="status">
					<c:set var="hasData" value="${not empty slot}" />
					<div class="slot-card ${hasData ? '' : 'empty-load'}" <c:if test="${hasData}">onclick="executeLoad(${status.count})"</c:if>>
						<div class="slot-info">
							<span class="slot-label" style="color: #ff69b4;">SLOT 0${status.count}</span>
							<c:choose>
								<c:when test="${hasData}">
									<div class="slot-detail">
										<span class="detail-tag">WEEK: <b>${slot.currentTurn}</b></span>
										<span class="detail-tag">LOVE: <b>${slot.lovePoint}</b></span>
										<span class="detail-tag">LIKE: <b>${slot.likePoint}</b></span>
									</div>
								</c:when>
								<c:otherwise><div style="color: #555; font-style: italic; margin-top: 5px;">--- NO DATA ---</div></c:otherwise>
							</c:choose>
						</div>
						<c:if test="${hasData}"><span style="font-size: 1.4em">📂</span></c:if>
					</div>
				</c:forEach>
			</div>
			<button type="button" class="btn-cancel" onclick="openGameSelectModal(event)">BACK</button>
		</div>
	</div>

	<div id="new-modal" class="save-modal">
		<div class="modal-content" style="border-color: #dc143c;">
			<div class="modal-title" style="color: #dc143c;">SELECT NEW GAME SLOT</div>
			<div class="slot-list">
				<c:forEach var="slot" items="${saveSlots}" varStatus="status">
					<c:set var="hasData" value="${not empty slot}" />
					<div class="slot-card" style="border-left-color: ${hasData ? '#dc143c' : '#666'}; cursor: pointer;" onclick="executeNewGame(${status.count}, ${hasData ? 'true' : 'false'})">
						<div class="slot-info">
							<span class="slot-label" style="color: ${hasData ? '#dc143c' : '#ccc'};">SLOT 0${status.count}</span>
							<c:choose>
								<c:when test="${hasData}">
									<div class="slot-detail">
										<span class="detail-tag">WEEK: <b style="color: #dc143c;">${slot.currentTurn}</b></span> 
                                        <span class="detail-tag">LOVE: <b style="color: #dc143c;">${slot.lovePoint}</b></span>
										<span class="detail-tag">LIKE: <b style="color: #dc143c;">${slot.likePoint}</b></span>
									</div>
									<div style="color: #ff4d4d; font-size: 0.8em; margin-top: 5px; font-weight: bold;">⚠️ 上書きされます</div>
								</c:when>
								<c:otherwise><div style="color: #aaa; font-style: italic; margin-top: 5px;">--- EMPTY (新規作成) ---</div></c:otherwise>
							</c:choose>
						</div>
						<span style="font-size: 1.4em">${hasData ? '⚠️' : '✨'}</span>
					</div>
				</c:forEach>
			</div>
			<button type="button" class="btn-cancel" onclick="openGameSelectModal(event)">BACK</button>
		</div>
	</div>

	<script>
	const hamBtn = document.getElementById('ham-btn');
	const menu = document.getElementById('full-menu');

	// メニュー開閉
	hamBtn.addEventListener('click', () => {
		menu.classList.toggle('active');
		hamBtn.classList.toggle('active-btn');
	});

    // リンククリック時の制御
	menu.addEventListener('click', (e) => {
		if(e.target.tagName === 'A' && !e.target.classList.contains('logout-btn') && !e.target.hasAttribute('onclick')) {
			menu.classList.remove('active');
			hamBtn.classList.remove('active-btn');
		}
	});

    // ログアウト確認
    function confirmLogout(event) {
        event.preventDefault();
        if (confirm("ログアウトしてタイトル画面に戻りますか？")) {
            window.location.href = "UsersLoginServlet";
        }
    }

	// 🌟 モーダル制御関連
	function closeAllModals() {
		document.querySelectorAll('.save-modal').forEach(m => m.classList.remove('active'));
	}

	function openGameSelectModal(event) {
        if(event) event.preventDefault();
		closeAllModals(); // 一旦全部閉じる
		menu.classList.remove('active'); // ハンバーガーも閉じる
		hamBtn.classList.remove('active-btn');
		document.getElementById('game-select-modal').classList.add('active'); // START GAMEを出す
	}

	function openLoadModal() {
		closeAllModals();
		document.getElementById('load-modal').classList.add('active');
	}
	function executeLoad(slotId) { window.location.href = "SayukiGameServlet?mode=continue&slotId=" + slotId; }

	function openNewGameModal() {
		closeAllModals();
		document.getElementById('new-modal').classList.add('active');
	}
	function executeNewGame(slotId, hasData) {
		if (hasData && !confirm("スロット 0" + slotId + " には既にデータがあります。\n上書きして最初からゲームを始めますか？")) {
			return; 
		}
		window.location.href = "SayukiGameServlet?mode=new&slotId=" + slotId;
	}
	</script>
</body>
</html>