<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page import="userMS.model.beans.UsersBeans"%>
<%
UsersBeans user = (UsersBeans) session.getAttribute("loginUser");
if (user == null) {
	response.sendRedirect("UsersLoginServlet");
	return;
}
%>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>GALLERY - SAYUKI PORTAL</title>
<style>
/* --- 1. 全体設定 --- */
body {
	margin: 0; padding: 0; background: #0a0a14; color: #fff;
	font-family: 'Helvetica Neue', 'Hiragino Kaku Gothic ProN', Arial, sans-serif;
	overflow: hidden; 
	background: radial-gradient(circle at 30% 70%, #0f2027 0%, #203a43 50%, #2c5364 100%);
}

.bg-text {
	position: fixed; right: -5vw; top: 15vh; font-size: 15vw; font-weight: 900;
	color: rgba(255, 255, 255, 0.02); z-index: 1; pointer-events: none; white-space: nowrap;
	letter-spacing: -5px; transform: rotate(5deg);
}

/* =========================================
   🌟 ナビゲーション
========================================= */
.hamburger {
	position: fixed; top: 35px; right: 40px; width: 35px; height: 24px;
	cursor: pointer; display: flex; flex-direction: column; justify-content: space-between;
	z-index: 4000;
}
.hamburger span {
	display: block; width: 100%; height: 3px; background-color: #4a90e2; 
	border-radius: 2px; transition: all 0.4s;
}
.active-btn span:nth-child(1) { transform: translateY(10.5px) rotate(45deg); }
.active-btn span:nth-child(2) { opacity: 0; }
.active-btn span:nth-child(3) { transform: translateY(-10.5px) rotate(-45deg); }

.full-menu {
	position: fixed; top: 0; right: -100%; width: 400px; height: 100vh;
	background: rgba(10, 10, 15, 0.98); border-left: 1px solid rgba(74, 144, 226, 0.3);
	z-index: 3500; transition: 0.5s cubic-bezier(0.4, 0, 0.2, 1); padding-top: 100px;
}
.full-menu.active { right: 0; }
.full-menu ul { list-style: none; padding: 0 50px; }
.full-menu ul li { margin-bottom: 25px; opacity: 0; transform: translateX(30px); transition: 0.5s; }
.full-menu.active ul li { opacity: 1; transform: translateX(0); }
.full-menu.active ul li:nth-child(1) { transition-delay: 0.1s; }
.full-menu.active ul li:nth-child(2) { transition-delay: 0.2s; }
.full-menu.active ul li:nth-child(3) { transition-delay: 0.3s; }
.full-menu.active ul li:nth-child(4) { transition-delay: 0.4s; }
.full-menu.active ul li:nth-child(5) { transition-delay: 0.5s; }
.full-menu.active ul li:nth-child(6) { transition-delay: 0.6s; }

.full-menu ul li a {
    color: #ccc; text-decoration: none; font-size: 1.4em; letter-spacing: 2px;
    transition: 0.3s; display: block; padding-bottom: 10px; border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}
.full-menu ul li a:hover { color: #4a90e2; border-bottom-color: #4a90e2; padding-left: 10px; }
.user-greeting { color: #aaa; font-size: 1.1em; display: block; padding-bottom: 10px; border-bottom: 1px solid rgba(74, 144, 226, 0.5); letter-spacing: 1px; }
.logout-btn { color: #ff4d4d !important; border-bottom-color: rgba(255, 77, 77, 0.3) !important; }
.logout-btn:hover { color: #ff0000 !important; border-bottom-color: #ff0000 !important; }

/* =========================================
   🌟 ギャラリー本体
========================================= */
.gallery-viewport {
	position: absolute; top: 0; left: 0; width: 100vw; height: 100vh;
	overflow-y: auto; overflow-x: hidden; padding: 60px 5vw 100px; box-sizing: border-box;
	z-index: 10;
}
.gallery-viewport::-webkit-scrollbar { width: 8px; }
.gallery-viewport::-webkit-scrollbar-thumb { background: #4a90e2; border-radius: 4px; }

.section-title {
	text-align: center; letter-spacing: 5px; margin: 40px 0 30px; font-size: 2em;
	animation: fadeInDown 1s ease forwards;
}
.sayuki-title { color: #ff69b4; text-shadow: 0 0 15px rgba(255, 105, 180, 0.5); }
.dev-title-sec { color: #00d4ff; text-shadow: 0 0 15px rgba(0, 212, 255, 0.5); font-family: 'Courier New', monospace; margin-top: 80px; }

.gallery-grid {
	display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 40px;
	max-width: 1400px; margin: 0 auto;
}

.art-card {
	background: rgba(20, 20, 30, 0.6); backdrop-filter: blur(10px);
	border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.5);
	transition: 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
	border: 1px solid rgba(255, 255, 255, 0.05);
	animation: fadeInUp 0.8s ease forwards; opacity: 0; transform: translateY(30px);
}
.sayuki-card { border-top: 3px solid #ff69b4; }
.sayuki-card:not(.locked):hover { transform: translateY(-10px); border-color: #ff69b4; box-shadow: 0 20px 40px rgba(255, 105, 180, 0.2); }
.dev-card { border-top: 3px solid #00d4ff; }
.dev-card:hover { transform: translateY(-10px); border-color: #00d4ff; box-shadow: 0 20px 40px rgba(0, 212, 255, 0.2); }

a.art-card { text-decoration: none; display: block; }

.art-img-box {
	width: 100%; height: 220px; background: #05050a; display: flex; align-items: center; justify-content: center;
	overflow: hidden; position: relative;
}
.art-img-box img { width: 100%; height: 100%; object-fit: cover; transition: 0.5s; }
.art-card:not(.locked):hover .art-img-box img { transform: scale(1.05); }

.art-info { padding: 20px; }
.art-title { font-weight: bold; margin-bottom: 8px; font-size: 1.2em; letter-spacing: 1px; }
.sayuki-card .art-title { color: #fff; }
.dev-card .art-title { color: #00d4ff; }
.art-desc { font-size: 0.9em; color: #bbb; line-height: 1.5; }

/* 🔒 ロック演出 */
.locked .art-img-box img { filter: blur(20px) brightness(0.3) grayscale(80%); }
.lock-icon { position: absolute; font-size: 3.5em; color: rgba(255,255,255,0.4); text-shadow: 0 0 20px rgba(255, 105, 180, 0.5); z-index: 5; }
.locked .art-title { color: #666 !important; }
.locked .art-desc { color: #555; font-style: italic; }

.gallery-grid .art-card:nth-child(1) { animation-delay: 0.1s; }
.gallery-grid .art-card:nth-child(2) { animation-delay: 0.2s; }
.gallery-grid .art-card:nth-child(3) { animation-delay: 0.3s; }
.gallery-grid .art-card:nth-child(4) { animation-delay: 0.4s; }
.gallery-grid .art-card:nth-child(5) { animation-delay: 0.5s; }
.gallery-grid .art-card:nth-child(6) { animation-delay: 0.6s; }

@keyframes fadeInUp { to { opacity: 1; transform: translateY(0); } }
@keyframes fadeInDown { from{ opacity:0; transform: translateY(-30px); } to { opacity: 1; transform: translateY(0); } }

/* =========================================
   🌟 ゲーム選択モーダル用CSS
========================================= */
.save-modal { visibility: hidden; opacity: 0; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.85); backdrop-filter: blur(15px); z-index: 5000; display: flex; justify-content: center; align-items: center; transition: opacity 0.4s ease, visibility 0.4s ease; }
.save-modal.active { visibility: visible; opacity: 1; }
.modal-content { background: rgba(15, 15, 25, 0.95); border: 2px solid #4a90e2; border-radius: 30px; padding: 40px; width: 500px; text-align: center; box-shadow: 0 0 40px rgba(74, 144, 226, 0.2); transform: translateY(40px) scale(0.9); transition: transform 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
.save-modal.active .modal-content { transform: translateY(0) scale(1); }
.modal-title { font-size: 1.6em; color: #4a90e2; margin-bottom: 25px; letter-spacing: 4px; font-weight: bold; }
.slot-list { display: flex; flex-direction: column; gap: 15px; }
.slot-card { background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.1); border-left: 6px solid #4a90e2; padding: 18px; border-radius: 12px; cursor: pointer; transition: 0.3s; display: flex; justify-content: space-between; align-items: center; }
.slot-card:hover:not(.empty-load) { background: rgba(74, 144, 226, 0.15); border-color: #4a90e2; transform: translateX(10px); }
.slot-card.empty-load { cursor: default; border-left-color: #444; opacity: 0.6; }
.slot-info { text-align: left; }
.slot-label { font-size: 0.8em; font-weight: bold; display: block; margin-bottom: 5px; }
.slot-detail { display: flex; gap: 12px; font-size: 0.9em; color: #ccc; }
.detail-tag { background: rgba(255, 255, 255, 0.1); padding: 2px 8px; border-radius: 4px; }
.detail-tag b { color: #4a90e2; }
.btn-cancel { margin-top: 25px; background: none; border: none; color: #888; cursor: pointer; text-decoration: underline; font-size: 1em; }
.game-choice-btn { display: block; width: 100%; padding: 15px; margin-bottom: 15px; background: #4a90e2; color: white; border: none; border-radius: 10px; font-size: 1.2em; font-weight: bold; cursor: pointer; transition: 0.3s; }
.game-choice-btn.new-game { background: #dc143c; }
.game-choice-btn:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(255, 255, 255, 0.2); }
</style>
</head>
<body>

	<div class="bg-text">GALLERY</div>

	<div class="hamburger" id="ham-btn">
		<span></span> <span></span> <span></span>
	</div>

	<nav class="full-menu" id="full-menu">
		<ul>
			<li><span class="user-greeting">Welcome, <%=user.getHn()%></span></li>
			<li><a href="MainServlet">Portal Top</a></li>
			<li><a href="#" onclick="openGameSelectModal(event)">Atelier Game</a></li>
			<li><a href="ProfServlet">Official Profile</a></li>
			<li><a href="ArtServlet" style="color: #4a90e2; border-bottom-color: #4a90e2;">Illustration Gallery</a></li>
			<li><a href="ItemServlet">Technical Tools</a></li>
			<li><a href="#" class="logout-btn" onclick="confirmLogout(event)">Logout</a></li>
		</ul>
	</nav>

	<div class="gallery-viewport">
	
	    <h1 class="section-title sayuki-title">SAYUKI'S ARTWORKS</h1>
	    <div class="gallery-grid">
	        <c:forEach var="art" items="${sayukiList}"> 
	            <%-- 🌟 Tomcat 11対応：DBから取得した実績フラグ（Normal, Love, Like, True）を直接判定 --%>
	            <c:set var="isUnlocked" value="${clearHistory[art.reqFlag] == true}" />
	            
	            <c:choose>
	                <%-- 🌟 解放済みの場合は、後日談ワープリンク（aタグ）を生成！ --%>
	                <c:when test="${isUnlocked}">
	                    <%-- Servletで設定したreqFlag（"Normal"等）をそのままtypeパラメータに渡す --%>
	                    <a href="SayukiGameServlet?mode=bonus&type=${art.reqFlag}" onclick="submitGameAction();" class="art-card sayuki-card" style="text-decoration: none; display: block;">
	                        <div class="art-img-box">
	                            <img src="${pageContext.request.contextPath}/images/background/${art.fileName}">
	                        </div>
	                        <div class="art-info">
	                            <div class="art-title">${art.title}</div>
	                            <div class="art-desc">${art.description} <span style="color:#ff69b4; display:block; margin-top:8px; font-weight:bold; font-size:0.85em; text-shadow:0 0 5px rgba(255,105,180,0.3)">👉 クリックで後日談を再生する</span></div>
	                        </div>
	                    </a>
	                </c:when>
	                <c:otherwise>
	                    <%-- 未クリアで完全にロックされている状態 --%>
	                    <div class="art-card sayuki-card locked">
	                        <div class="art-img-box">
	                            <img src="${pageContext.request.contextPath}/images/background/${art.fileName}">
	                            <div class="lock-icon">🔒</div>
	                        </div>
	                        <div class="art-info">
	                            <div class="art-title">？？？？？？</div>
	                            <div class="art-desc">特定の条件クリア後に解放されます。</div>
	                        </div>
	                    </div>
	                </c:otherwise>
	            </c:choose>
	        </c:forEach>
	    </div>
	
	    <h1 class="section-title dev-title-sec">DEVELOPMENT ARCHIVES</h1>
	    <div class="gallery-grid">
	        <c:forEach var="dev" items="${devList}"> 
	            <div class="art-card dev-card">
	                <div class="art-img-box">
	                    <img src="${pageContext.request.contextPath}/images/developer/${dev.fileName}">
	                </div>
	                <div class="art-info">
	                    <div class="art-title">${dev.title}</div>
	                    <div class="art-desc">${dev.description}</div>
	                </div>
	            </div>
	        </c:forEach>
	    </div>
	    
	</div>

	<div id="game-select-modal" class="save-modal">
		<div class="modal-content">
			<div class="modal-title" style="color: #fff;">START GAME</div>
			<% if ("guest".equals(user.getId())) { %>
			<p style="color: #ff4d4d; font-weight: bold; margin-bottom: 20px;">⚠️ ゲストモードではセーブ機能は利用できません</p>
			<button class="game-choice-btn new-game" onclick="window.location.href='SayukiGameServlet?mode=new&slotId=1'">最初からプレイ</button>
			<% } else { %>
			<button class="game-choice-btn new-game" onclick="openNewGameModal()">NEW GAME (最初から)</button>
			<c:if test="${not empty saveSlots}">
				<button class="game-choice-btn" onclick="openLoadModal()">CONTINUE (続きから)</button>
			</c:if>
			<% } %>
			<button type="button" class="btn-cancel" onclick="closeAllModals()">CLOSE</button>
		</div>
	</div>

	<div id="load-modal" class="save-modal">
		<div class="modal-content">
			<div class="modal-title">LOAD PROGRESS</div>
			<div class="slot-list">
				<c:forEach var="slot" items="${saveSlots}" varStatus="status">
					<c:set var="hasData" value="${not empty slot}" />
					<div class="slot-card ${hasData ? '' : 'empty-load'}" <c:if test="${hasData}">onclick="executeLoad(${status.count})"</c:if>>
						<div class="slot-info">
							<span class="slot-label" style="color: #4a90e2;">SLOT 0${status.count}</span>
							<c:choose>
								<c:when test="${hasData}">
									<div class="slot-detail">
										<span class="detail-tag">WEEK: <b>${slot.currentTurn}</b></span>
										<span class="detail-tag">LOVE: <b>${slot.lovePoint}</b></span>
										<span class="detail-tag">LIKE: <b>${slot.likePoint}</b></span>
									</div>
								</c:when>
								<c:otherwise><div style="color: #555; font-style: italic; margin-top: 5px;">--- NO DATA ---</div></c:otherwise>
							</c:choose>
						</div>
						<c:if test="${hasData}"><span style="font-size: 1.4em">📂</span></c:if>
					</div>
				</c:forEach>
			</div>
			<button type="button" class="btn-cancel" onclick="openGameSelectModal(event)">BACK</button>
		</div>
	</div>

	<div id="new-modal" class="save-modal">
		<div class="modal-content" style="border-color: #dc143c;">
			<div class="modal-title" style="color: #dc143c;">SELECT NEW GAME SLOT</div>
			<div class="slot-list">
				<c:forEach var="slot" items="${saveSlots}" varStatus="status">
					<c:set var="hasData" value="${not empty slot}" />
					<div class="slot-card" style="border-left-color: ${hasData ? '#dc143c' : '#666'}; cursor: pointer;" onclick="executeNewGame(${status.count}, ${hasData ? 'true' : 'false'})">
						<div class="slot-info">
							<span class="slot-label" style="color: ${hasData ? '#dc143c' : '#ccc'};">SLOT 0${status.count}</span>
							<c:choose>
								<c:when test="${hasData}">
									<div class="slot-detail">
										<span class="detail-tag">WEEK: <b style="color: #dc143c;">${slot.currentTurn}</b></span> 
                                        <span class="detail-tag">LOVE: <b style="color: #dc143c;">${slot.lovePoint}</b></span>
										<span class="detail-tag">LIKE: <b style="color: #dc143c;">${slot.likePoint}</b></span>
									</div>
									<div style="color: #ff4d4d; font-size: 0.8em; margin-top: 5px; font-weight: bold;">⚠️ 上書きされます</div>
								</c:when>
								<c:otherwise><div style="color: #aaa; font-style: italic; margin-top: 5px;">--- EMPTY (新規作成) ---</div></c:otherwise>
							</c:choose>
						</div>
						<span style="font-size: 1.4em">${hasData ? '⚠️' : '✨'}</span>
					</div>
				</c:forEach>
			</div>
			<button type="button" class="btn-cancel" onclick="openGameSelectModal(event)">BACK</button>
		</div>
	</div>

	<script>
	const hamBtn = document.getElementById('ham-btn');
	const menu = document.getElementById('full-menu');

	hamBtn.addEventListener('click', () => {
		menu.classList.toggle('active');
		hamBtn.classList.toggle('active-btn');
	});

	menu.addEventListener('click', (e) => {
		if(e.target.tagName === 'A' && !e.target.classList.contains('logout-btn') && !e.target.hasAttribute('onclick')) {
			menu.classList.remove('active');
			hamBtn.classList.remove('active-btn');
		}
	});

    function confirmLogout(event) {
        event.preventDefault();
        if (confirm("ログアウトしてタイトル画面に戻りますか？")) {
            window.location.href = "UsersLoginServlet";
        }
    }

	function closeAllModals() {
		document.querySelectorAll('.save-modal').forEach(m => m.classList.remove('active'));
	}

	function openGameSelectModal(event) {
        if(event) event.preventDefault();
		closeAllModals(); 
		menu.classList.remove('active'); 
		hamBtn.classList.remove('active-btn');
		document.getElementById('game-select-modal').classList.add('active'); 
	}

	function openLoadModal() {
		closeAllModals();
		document.getElementById('load-modal').classList.add('active');
	}
	function executeLoad(slotId) { window.location.href = "SayukiGameServlet?mode=continue&slotId=" + slotId; }

	function openNewGameModal() {
		closeAllModals();
		document.getElementById('new-modal').classList.add('active');
	}
	function executeNewGame(slotId, hasData) {
		if (hasData && !confirm("スロット 0" + slotId + " には既にデータがあります。\n上書きして最初からゲームを始めますか？")) {
			return; 
		}
		window.location.href = "SayukiGameServlet?mode=new&slotId=" + slotId;
	}
	
	function submitGameAction() {
	    // 隠し後日談ワープを正常に実行させるための空関数
	}
	</script>
</body>
</html>