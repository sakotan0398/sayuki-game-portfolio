<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>SAYUKI ATELIER - IN GAME</title>
<style>
/* --- 1. 基本レイアウト --- */
body {
	margin: 0;
	padding: 0;
	background-color: #05050a;
	display: flex;
	justify-content: center;
	align-items: center;
	height: 100vh;
	overflow: hidden;
	font-family: 'Helvetica Neue', 'Hiragino Kaku Gothic ProN', sans-serif;
	color: #fff;
}

.game-viewport {
	position: relative;
	width: 95vw;
	height: 95vh;
	max-width: 1600px;
	max-height: 900px;
	overflow: hidden;
	border: 4px solid rgba(255, 105, 180, 0.4);
	border-radius: 20px;
	box-shadow: 0 0 50px rgba(0, 0, 0, 0.8);
	background-size: cover;
	background-position: center;
	transition: background-image 1.0s ease-in-out;
}

/* --- 2. 立ち絵と演出フィルター --- */
.character-stage {
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	display: flex;
	justify-content: center;
	align-items: flex-start;
	z-index: 2;
	pointer-events: none;
}

.character-img {
	height: 120vh;
	width: auto;
	object-fit: contain;
	margin-top: 15vh;
	transition: all 0.8s ease;
}

/*.filter-day {
	filter: brightness(1.02) contrast(0.98) saturate(1.1) sepia(0.05)
		drop-shadow(0 0 30px rgba(255, 105, 180, 0.3));
}

.filter-sunset {
	filter: sepia(0.5) hue-rotate(-15deg) saturate(1.5) brightness(0.85)
		drop-shadow(0 0 25px rgba(255, 69, 0, 0.4));
}

.filter-night {
	filter: brightness(0.5) contrast(1.1) sepia(0.2) hue-rotate(180deg)
		saturate(0.8) drop-shadow(0 0 25px rgba(0, 100, 255, 0.3));
}*/

.zoom-normal {
	transform: scale(1) translateY(0);
}

.zoom-close_up {
	transform: scale(1.3) translateY(50px);
}

/* --- 3. UIパーツ (ステータス・システムボタン) --- */
.status-container {
	position: absolute;
	top: 20px;
	left: 50%;
	transform: translateX(-50%);
	display: flex;
	gap: 25px;
	z-index: 1000;
	background: rgba(10, 10, 20, 0.7);
	padding: 10px 40px;
	border-radius: 50px;
	backdrop-filter: blur(10px);
	border: 1px solid rgba(255, 255, 255, 0.1);
}

.stat-item {
	text-align: center;
}

.stat-label {
	font-size: 0.6em;
	color: #aaa;
	display: block;
	margin-bottom: 2px;
}

.stat-value {
	font-weight: bold;
	color: #ff69b4;
	text-shadow: 0 0 10px #ff69b4;
}

.btn-system-trigger {
	position: absolute;
	top: 25px;
	right: 25px;
	z-index: 2000;
	background: rgba(10, 10, 20, 0.6);
	border: 1px solid rgba(255, 105, 180, 0.5);
	color: #ff69b4;
	padding: 10px 20px;
	border-radius: 8px;
	cursor: pointer;
	font-weight: bold;
	transition: 0.3s;
}

.btn-system-trigger:hover {
	background: #ff69b4;
	color: white;
	border-color: white;
}

/* --- 4. モーダル共通 --- */
.system-modal {
	visibility: hidden;
	opacity: 0;
	position: fixed;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	background: rgba(0, 0, 0, 0.85);
	backdrop-filter: blur(12px);
	z-index: 5000;
	display: flex;
	justify-content: center;
	align-items: center;
	transition: opacity 0.4s ease, visibility 0.4s ease;
}

.system-modal.active {
	visibility: visible;
	opacity: 1;
}

.system-modal .modal-content {
	background: rgba(15, 15, 25, 0.98);
	border: 2px solid #ff69b4;
	border-radius: 30px;
	padding: 40px;
	width: 500px;
	text-align: center;
	box-shadow: 0 0 40px rgba(255, 105, 180, 0.2);
	transform: translateY(40px) scale(0.9);
	opacity: 0;
	transition: transform 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275),
		opacity 0.4s ease;
	position: relative;
}

.system-modal.active .modal-content {
	transform: translateY(0) scale(1);
	opacity: 1;
}

.modal-title {
	font-size: 1.5em;
	color: #ff69b4;
	margin-bottom: 25px;
	letter-spacing: 3px;
	font-weight: bold;
}

.modal-close-x {
	position: absolute;
	top: 20px;
	right: 25px;
	background: none;
	border: none;
	color: #666;
	font-size: 2.5em;
	cursor: pointer;
	line-height: 1;
	transition: 0.3s;
}

.modal-close-x:hover {
	color: #ff69b4;
	transform: rotate(90deg);
}

.slot-list {
	display: flex;
	flex-direction: column;
	gap: 15px;
}

.slot-card {
	background: rgba(255, 255, 255, 0.03);
	border: 1px solid rgba(255, 255, 255, 0.1);
	border-left: 6px solid #ff69b4;
	padding: 18px;
	border-radius: 12px;
	cursor: pointer;
	transition: 0.3s;
	display: flex;
	justify-content: space-between;
	align-items: center;
}

.slot-card:hover {
	background: rgba(255, 105, 180, 0.1);
	border-color: #ff69b4;
	transform: translateX(10px);
}

.slot-info {
	text-align: left;
}

.slot-label {
	font-size: 0.8em;
	color: #ff69b4;
	font-weight: bold;
	margin-bottom: 5px;
	display: block;
}

.slot-detail {
	display: flex;
	gap: 10px;
	font-size: 0.85em;
	color: #ccc;
}

.detail-tag {
	background: rgba(255, 255, 255, 0.08);
	padding: 2px 8px;
	border-radius: 4px;
}

.detail-tag b {
	color: #ff69b4;
}

.mode-switcher {
	margin-top: 30px;
	display: flex;
	justify-content: center;
	gap: 10px;
}

.btn-mode {
	flex: 1;
	background: #222;
	border: 1px solid #444;
	color: #888;
	padding: 12px;
	border-radius: 8px;
	cursor: pointer;
	font-weight: bold;
	transition: 0.3s;
}

.btn-mode.active {
	background: #ff69b4;
	color: white;
	border-color: white;
	box-shadow: 0 0 15px rgba(255, 105, 180, 0.4);
}

.btn-cancel {
	display: inline-block;
	margin-top: 20px;
	padding: 10px 40px;
	border: 1px solid #444;
	border-radius: 50px;
	color: #888;
	cursor: pointer;
	transition: 0.3s;
}

.btn-cancel:hover {
	border-color: #ff69b4;
	color: #ff69b4;
	background: rgba(255, 105, 180, 0.1);
}

/* --- 📜 バックログ用スタイル --- */
.log-modal .modal-content {
	width: 850px;
	max-width: 95vw;
	height: 85vh;
	display: flex;
	flex-direction: column;
	text-align: left !important;
	position: relative;
}

.log-scroll-area {
	flex: 1;
	overflow-y: auto;
	background: rgba(0, 0, 0, 0.5);
	border-radius: 15px;
	padding: 20px;
	border: 1px solid rgba(255, 255, 255, 0.05);
	text-align: left !important;
}

.log-entry {
	display: flex;
	align-items: flex-start;
	margin-bottom: 12px;
	padding: 10px;
	border-radius: 8px;
	background: rgba(255, 255, 255, 0.03);
}

.log-name {
	width: 110px;
	flex-shrink: 0;
	color: #ff69b4;
	font-weight: bold;
	font-size: 0.85em;
	border-right: 1px solid rgba(255, 105, 180, 0.3);
	margin-right: 15px;
	text-align: right;
	padding-right: 10px;
}

.log-text {
	flex: 1;
	color: #eee;
	line-height: 1.6;
	font-size: 1.0em;
	word-break: break-all;
	text-align: left !important;
}

/* バックログの名前別カラー設定 */
.sayuki-name {
	color: #ff69b4 !important;
	border-right-color: rgba(255, 105, 180, 0.4) !important;
	text-shadow: 0 0 5px rgba(255, 105, 180, 0.3);
}

.player-name {
	color: #4a90e2 !important;
	border-right-color: rgba(74, 144, 226, 0.4) !important;
	text-shadow: 0 0 5px rgba(74, 144, 226, 0.3);
}

.sys-name {
	color: #888 !important;
	border-right-color: rgba(255, 255, 255, 0.1) !important;
}

.player-log {
	border-left: 4px solid #4a90e2;
	background: rgba(74, 144, 226, 0.05);
}

/* --- 5. メッセージウィンドウ --- */
.message-window {
	position: absolute;
	bottom: 30px;
	left: 50%;
	transform: translateX(-50%);
	width: 85%;
	max-width: 1000px;
	min-height: 280px;
	background: rgba(10, 10, 20, 0.95);
	backdrop-filter: blur(20px);
	border: 1px solid rgba(255, 105, 180, 0.4);
	border-radius: 25px;
	padding: 50px 50px 30px;
	z-index: 100;
	cursor: pointer;
	box-sizing: border-box;
}

/* メイン画面のネームプレート用デザイン */
.speaker-name {
	position: absolute;
	top: -18px;
	left: 50px;
	color: white;
	padding: 6px 35px;
	border-radius: 50px;
	font-weight: bold;
	transition: background 0.3s;
}

.badge-sayuki {
	background: linear-gradient(90deg, #ff69b4, #ff1493) !important;
	box-shadow: 0 5px 15px rgba(255, 105, 180, 0.3);
}

.badge-player {
	background: linear-gradient(90deg, #4a90e2, #0066cc) !important;
	box-shadow: 0 5px 15px rgba(74, 144, 226, 0.3);
}

.badge-system {
	background: linear-gradient(90deg, #666666, #444444) !important;
	box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
}

.message-controls {
	position: absolute;
	top: 15px;
	right: 30px;
	display: flex;
	gap: 8px;
}

.ctrl-btn {
	background: rgba(255, 255, 255, 0.05);
	border: 1px solid rgba(255, 105, 180, 0.5);
	color: #ff69b4;
	font-size: 0.7em;
	padding: 4px 10px;
	border-radius: 6px;
	cursor: pointer;
	transition: 0.3s;
}

.ctrl-btn.active {
	background: #ff69b4;
	color: white;
}

.choice-btn {
	width: 100%;
	background: rgba(255, 255, 255, 0.05);
	border: 1px solid rgba(255, 255, 255, 0.1);
	color: #eee;
	padding: 18px;
	border-radius: 12px;
	cursor: pointer;
	transition: 0.3s;
	font-size: 1.1em;
	text-align: left;
	margin-bottom: 10px;
}

.choice-btn:hover {
	background: rgba(255, 105, 180, 0.15);
	border-color: #ff69b4;
	transform: scale(1.01);
	color: #fff;
}

@
keyframes blink { 0%, 100% {
	opacity: 1;
}
50
%
{
opacity
:
0;
}
}
</style>
</head>
<body>

	<div class="game-viewport"
		style="background-image: url('${pageContext.request.contextPath}/images/background/${not empty backgroundImage ? backgroundImage : 'bg06819201440.jpg'}');">

		<button type="button" class="btn-system-trigger" style="right: 150px;"
			onclick="openLogModal()">📜 LOG</button>
		<button type="button" class="btn-system-trigger"
			onclick="openSystemModal()">⚙️ SYSTEM</button>

		<div class="status-container">
			<div class="stat-item">
				<span class="stat-label">WEEK</span> <span class="stat-value">第
					<c:out value="${sayukiData.currentTurn}" default="1" /> 週
				</span>
			</div>
			<div class="stat-item">
				<span class="stat-label">DATE</span> <span class="stat-value">${calendarDate}</span>
			</div>
			<div class="stat-item">
				<span class="stat-label">LOVE</span> <span class="stat-value">${sayukiData.lovePoint}</span>
			</div>
			<div class="stat-item">
				<span class="stat-label">LIKE</span> <span class="stat-value">${sayukiData.likePoint}</span>
			</div>
		</div>

		<div class="character-stage">
			<img
				src="images/character/${not empty characterImage ? characterImage : 'sayuki_normal.png'}"
				class="character-img filter-${not empty timeFilter ? timeFilter : 'day'} zoom-${not empty zoomType ? zoomType : 'normal'}"
				id="sayuki-img" alt="サユキ">
		</div>

		<div class="message-window" onclick="handleWindowClick()">
			<div id="speaker-badge" class="speaker-name badge-system">SYSTEM</div>

			<div class="message-controls">
				<button type="button" id="btn-auto"
					onclick="event.stopPropagation(); toggleAuto();" class="ctrl-btn">AUTO</button>
				<button type="button" id="btn-ff"
					onclick="event.stopPropagation(); toggleFF();" class="ctrl-btn">FF</button>
				<button type="button" id="btn-skip"
					onclick="event.stopPropagation(); toggleSkip();" class="ctrl-btn">SKIP</button>
			</div>
			<p id="typewriter"
				style="font-size: 1.2em; line-height: 1.8; color: #f0f0f0; margin: 0;">${message}</p>

			<form action="SayukiGameServlet" method="post" id="choice-area"
				style="display: none; margin-top: 30px;">
				<%-- 🌟【神アップデート】JSP側で一本道（次へ進むだけ）か、通常の3つの選択肢かを自動判定！ --%>
				<c:choose>
					<%-- 選択肢1と2が同じ文字列、あるいは選択肢2が空の場合は「一本道（次へ）」用の特大ボタン1個だけを表示する --%>
					<c:when test="${choice1Text == choice2Text || empty choice2Text}">
						<button type="submit" name="choice" value="1" class="choice-btn"
							style="text-align: center;" onclick="submitGameAction()">${choice1Text}</button>
					</c:when>
					<c:otherwise>
						<%-- 選択肢がちゃんと3つある本編・イベント分岐の時は、いつもの綺麗な3本並びを出す --%>
						<button type="submit" name="choice" value="1" class="choice-btn"
							onclick="submitGameAction()">1. ${choice1Text}</button>
						<button type="submit" name="choice" value="2" class="choice-btn"
							onclick="submitGameAction()">2. ${choice2Text}</button>
						<button type="submit" name="choice" value="3" class="choice-btn"
							onclick="submitGameAction()">3. ${choice3Text}</button>
					</c:otherwise>
				</c:choose>
			</form>
		</div>
	</div>

	<div id="system-modal" class="system-modal">
		<div class="modal-content">
			<button type="button" class="modal-close-x"
				onclick="closeSystemModal()">&times;</button>
			<div class="modal-title" id="modal-title">SYSTEM - SAVE</div>

			<c:if test="${loginUser.id != 'guest'}">
				<div class="slot-list">
					<c:forEach var="slot" items="${saveSlots}" varStatus="status">
						<div class="slot-card" onclick="handleSlotClick(${status.count})">
							<div class="slot-info">
								<span class="slot-label">SLOT 0${status.count}</span>
								<c:choose>
									<c:when test="${not empty slot}">
										<div class="slot-detail">
											<span class="detail-tag">WEEK: <b>${slot.currentTurn}</b></span>
											<span class="detail-tag">LOVE: <b>${slot.lovePoint}</b></span>
											<span class="detail-tag">LIKE: <b>${slot.likePoint}</b></span>
										</div>
									</c:when>
									<c:otherwise>
										<span
											style="color: #555; font-style: italic; font-size: 0.9em;">---
											NO DATA ---</span>
									</c:otherwise>
								</c:choose>
							</div>
							<span id="slot-icon-${status.count}" style="font-size: 1.4em">💾</span>
						</div>
					</c:forEach>
				</div>
				<div class="mode-switcher">
					<button type="button" id="btn-save-mode" class="btn-mode active"
						onclick="setMode('save')">SAVE PROGRESS</button>
					<button type="button" id="btn-load-mode" class="btn-mode"
						onclick="setMode('load')">LOAD PROGRESS</button>
				</div>
			</c:if>

			<c:if test="${loginUser.id == 'guest'}">
				<p style="color: #aaa; margin: 30px 0;">ゲストユーザーはセーブ・ロード機能を利用できません。</p>
			</c:if>

			<div style="margin-top: 10px;">
				<a href="MainServlet" class="btn-cancel"
					style="text-decoration: none; text-align: center; padding: 12px;"
					onclick="submitGameAction()">TITLEへ戻る</a>
				<div class="btn-cancel" onclick="closeSystemModal()">閉じる</div>
			</div>
		</div>
	</div>

	<div id="log-modal" class="system-modal log-modal">
		<div class="modal-content">
			<button type="button" class="modal-close-x" onclick="closeLogModal()">&times;</button>
			<div class="modal-title">MESSAGE LOG</div>
			<div class="log-scroll-area" id="log-scroll-area">
				<c:forEach var="log" items="${backlog}">${log}</c:forEach>

				<c:forEach var="currentLog" items="${currentTurnLogs}"
					varStatus="status">
					<div id="current-log-${status.index}" style="display: none;">${currentLog}</div>
				</c:forEach>
			</div>
			<div style="margin-top: 10px;">
				<div class="btn-cancel" onclick="closeLogModal()">CLOSE</div>
			</div>
		</div>
	</div>

	<form id="hidden-save-form" action="SaveGameServlet" method="post">
		<input type="hidden" name="slotId" id="save-slot-id">
	</form>

	<script>
// 1. ゲスト判定の導入
const isGuest = "${loginUser.id}" === "guest" || "${loginUser.id}" === "";
let isDirty = true; 
let currentMode = 'save'; 

/* 2. ブラウザの「戻る」ボタン制圧（HOMEへ強制送還） */
window.history.pushState(null, null, window.location.href);
window.addEventListener('popstate', function(e) {
    isDirty = false; // 警告をスキップ
    window.location.href = 'MainServlet';
});

/* 警告制御（ゲストなら警告しない） */
window.onbeforeunload = function(e) { 
    if (isDirty && !isGuest) return "セーブしていないデータは失われます。"; 
};
function submitGameAction() { isDirty = false; } 

/* --- モーダル制御 --- */
function openSystemModal() { document.getElementById('system-modal').classList.add('active'); }
function closeSystemModal() { document.getElementById('system-modal').classList.remove('active'); }

function openLogModal() { 
    if (isTyping) { handleWindowClick(); } 
    document.getElementById('log-modal').classList.add('active'); 
    setTimeout(() => {
        let logArea = document.getElementById('log-scroll-area');
        if (logArea) logArea.scrollTop = logArea.scrollHeight;
    }, 100);
}
function closeLogModal() { document.getElementById('log-modal').classList.remove('active'); }

/* --- セーブ・ロード処理 --- */
function setMode(mode) {
    if(isGuest) return; // ゲストは何もしない
    currentMode = mode;
    document.getElementById('modal-title').innerText = "SYSTEM - " + mode.toUpperCase();
    document.getElementById('btn-save-mode').classList.toggle('active', mode === 'save');
    document.getElementById('btn-load-mode').classList.toggle('active', mode === 'load');
    for(let i=1; i<=3; i++) { document.getElementById('slot-icon-'+i).innerText = (mode === 'save') ? "💾" : "📂"; }
}

function handleSlotClick(slotId) {
    if (currentMode === 'save') {
        if (confirm("スロット 0" + slotId + " に現在の進捗を上書き保存しますか？")) {
            submitGameAction();
            document.getElementById('save-slot-id').value = slotId;
            document.getElementById('hidden-save-form').submit();
        }
    } else {
        if (confirm("スロット 0" + slotId + " からデータをロードしますか？")) {
            submitGameAction();
            window.location.href = "SayukiGameServlet?mode=continue&slotId=" + slotId;
        }
    }
}

/* --- 演出制御 --- */
let textQueue = []; let queueIndex = 0; let currentText = ""; let charIndex = 0; let isTyping = false; let typingTimer = null;
const S_NORMAL = 40; const S_FF = 10;
let isAuto = localStorage.getItem('sayuki_auto') === 'true';
let isFF   = localStorage.getItem('sayuki_ff')   === 'true';
let isSkip = localStorage.getItem('sayuki_skip') === 'true';

document.addEventListener('DOMContentLoaded', () => {
    const textElement = document.getElementById('typewriter');
    if (!textElement) return;
    textQueue = textElement.innerHTML.trim().split('[NEXT]');
    updateUI('btn-auto', isAuto); updateUI('btn-ff', isFF); updateUI('btn-skip', isSkip);
    startTyping(); 
});

// 3. ネームプレートの「色」と「名前」を動的に変える
function updateSpeakerBadge(rawName) {
    const playerName = "${loginUser.hn}";
    let dispName = rawName.trim();
    const badge = document.getElementById('speaker-badge');
    if (!badge) return;

    // 一旦クラスをリセット
    badge.className = 'speaker-name';

    if (dispName.toUpperCase() === 'SAYUKI' || dispName === 'サユキ') {
        dispName = 'SAYUKI';
        badge.classList.add('badge-sayuki');
    } else if (dispName.toUpperCase() === 'PLAYER' || dispName === playerName) {
        dispName = playerName;
        badge.classList.add('badge-player');
    } else if (dispName.toUpperCase() === 'NONE' || dispName.toUpperCase() === 'SYSTEM') {
        dispName = 'SYSTEM';
        badge.classList.add('badge-system');
    } else {
        badge.classList.add('badge-system'); // 万が一のデフォルト
    }
    badge.innerHTML = dispName;
}

function applyTagsFromText(text) {
    let nameRegex = /\[NAME:(.*?)\]/g;
    let match;
    while ((match = nameRegex.exec(text)) !== null) { 
        updateSpeakerBadge(match[1]); 
    }
    
    let imgRegex = /\[IMG:(.*?)\]/g;
    let imgMatch;
    while ((imgMatch = imgRegex.exec(text)) !== null) {
        let img = document.getElementById('sayuki-img');
        img.style.display = 'block'; img.src = 'images/character/' + imgMatch[1];
    }
}

function startTyping() { 
    isTyping = true; charIndex = 0; currentText = textQueue[queueIndex]; 
    document.getElementById('typewriter').innerHTML = ""; 
    
    // 表示される前に一旦ネームプレートを判定しておく
    applyTagsFromText(currentText);

    let currentLogDiv = document.getElementById('current-log-' + queueIndex);
    if (currentLogDiv) {
        currentLogDiv.style.display = 'block';
    }
    
    typeNextChar(); 
}

function typeNextChar() {
    const element = document.getElementById('typewriter');
    if (!element) return;
    if (isSkip) {
        element.innerHTML += currentText.substring(charIndex).replace(/\[NAME:.*?\]/g, '').replace(/\[IMG:.*?\]/g, '');
        finishTyping(); return;
    }
    if (charIndex < currentText.length) {
        if (currentText.substring(charIndex, charIndex + 6) === '[NAME:') {
            let end = currentText.indexOf(']', charIndex);
            charIndex = end + 1; typeNextChar(); return; // 名前タグは出力しない
        }
        if (currentText.substring(charIndex, charIndex + 5) === '[IMG:') {
            let end = currentText.indexOf(']', charIndex);
            charIndex = end + 1; typeNextChar(); return; // 画像タグも出力しない
        }
        element.innerHTML += currentText.charAt(charIndex); charIndex++;
        typingTimer = setTimeout(typeNextChar, isFF ? S_FF : S_NORMAL);
    } else { finishTyping(); }
}

function finishTyping() {
    isTyping = false; clearTimeout(typingTimer);
    if (queueIndex < textQueue.length - 1) {
        document.getElementById('typewriter').innerHTML += " <span style='color:#ff69b4; animation:blink 1s infinite'>▼</span>";
        if (isAuto || isSkip) setTimeout(() => { handleWindowClick(); }, isSkip ? 100 : 1500);
    } else { document.getElementById('choice-area').style.display = 'grid'; }
}

function handleWindowClick() {
    if (isTyping) {
        clearTimeout(typingTimer);
        document.getElementById('typewriter').innerHTML += currentText.substring(charIndex).replace(/\[NAME:.*?\]/g, '').replace(/\[IMG:.*?\]/g, '');
        finishTyping();
    } else { if (queueIndex < textQueue.length - 1) { queueIndex++; startTyping(); } }
}

function toggleAuto() { isAuto = !isAuto; localStorage.setItem('sayuki_auto', isAuto); updateUI('btn-auto', isAuto); if (isAuto && !isTyping && queueIndex < textQueue.length - 1) handleWindowClick(); }
function toggleFF() { isFF = !isFF; if (isFF) { isSkip = false; localStorage.setItem('sayuki_skip', false); } localStorage.setItem('sayuki_ff', isFF); updateUI('btn-ff', isFF); updateUI('btn-skip', isSkip); }
function toggleSkip() { isSkip = !isSkip; if (isSkip) { isFF = false; localStorage.setItem('sayuki_ff', false); } localStorage.setItem('sayuki_skip', isSkip); updateUI('btn-skip', isSkip); updateUI('btn-ff', isFF); if (isSkip && isTyping) { clearTimeout(typingTimer); typeNextChar(); } else if (isSkip && !isTyping && queueIndex < textQueue.length - 1) handleWindowClick(); }
function updateUI(id, state) { const btn = document.getElementById(id); if (btn) state ? btn.classList.add('active') : btn.classList.remove('active'); }
</script>
</body>
</html>