<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="sayukiGame.model.beans.Sayuki_Sakota" %>
<%
    // Servletから渡されたエンディングの種類を取得
    String endingType = (String) request.getAttribute("endingType");
    if (endingType == null) endingType = "Unknown End";

    // セッションからサユキの最終ステータスを取得
    Sayuki_Sakota s = (Sayuki_Sakota) session.getAttribute("sayukiData");
    int finalLove = (s != null) ? s.getLovePoint() : 0;
    int finalLike = (s != null) ? s.getLikePoint() : 0;
    int totalScore = finalLove + finalLike;

    // 🌟 ランクに応じたイメージカラーの判定（文字色として活かします）
    String rankColor = "#a0a0a0"; // グレー
    if (totalScore >= 180) { 
        rankColor = "#ffd700"; // ゴールド
    } else if (totalScore >= 120) { 
        rankColor = "#ff7f50"; // コーラルピンク
    } else if (totalScore >= 80) { 
        rankColor = "#87ceeb"; // スカイブルー
    }

    // 各ルートの変数初期化
    String bgImage = "bg068800600.jpg"; 
    String charImage = "Sayuki_nomal.png"; 
    String endTitle = "Normal End";
    String endSubTitle = "境界線の向こう側";
    String message = "アトリエでの日々は、いつか良い思い出になるだろう。";
    String secretMsg = "「いつかまた、どこかの現場で。」";

    // エンディング分岐による上書き
    if (endingType.contains("True")) {
        bgImage = "bg_blue_sky.jpg"; 
        charImage = "Sayuki_nomal.png"; 
        endTitle = "True End";
        endSubTitle = "境界線のないアトリエ";
        message = "クリエイターとして、人生の伴侶として。二人の物語はここから始まる。";
        secretMsg = "「ずっと一緒に、最高のゲームを作ろうね。」";
    } else if (endingType.contains("Love")) {
        bgImage = "bg068nnr800600.jpg"; 
        charImage = "Sayuki_mesorasi.png"; 
        endTitle = "Love End";
        endSubTitle = "私だけのエンジニア";
        message = "仕事が終わっても、俺たちの甘い日常はずっと続いていく。";
        secretMsg = "「今日から、私の専属だからね。」";
    } else if (endingType.contains("Like")) {
        bgImage = "bg068800600.jpg"; 
        charImage = "Sayuki_dakara.png"; 
        endTitle = "Like End";
        endSubTitle = "最高の相棒（バディ）";
        message = "恋愛という枠には収まらない、唯一無二の戦友として。";
        secretMsg = "「さあ、次のバグ取りの時間だよ、相棒！」";
    }
%>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>Ending - <%= endTitle %></title>
    <link href="https://fonts.googleapis.com/css2?family=Yuji+Syuku&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0; padding: 0; background-color: #000; color: #fff;
            font-family: 'Hiragino Mincho ProN', 'Yu Mincho', serif;
            display: flex; justify-content: center; align-items: center;
            height: 100vh; overflow: hidden;
        }

        .ending-container {
            position: relative; width: 800px; height: 600px;
            background-image: url('images/<%= bgImage %>');
            background-size: cover; background-position: center;
            box-shadow: 0 0 20px rgba(255,255,255,0.2); overflow: hidden;
        }

        /* 🌟【新演出】最初の22秒間、スタッフロールを読みやすくするために画面全体を覆う黒いベール */
        .credit-mask {
            position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.75);
            z-index: 3;
            /* 22秒間維持し、その後2秒かけてフワッと消える */
            animation: fadeOutMask 2s ease-in-out 22s forwards;
        }
        @keyframes fadeOutMask {
            0% { opacity: 1; }
            100% { opacity: 0; pointer-events: none; }
        }

        /* 🌟【改善】リザルトUIレイヤーは、スタッフロールが終わる「22秒後」に左側からフワッと出現！ */
        .ui-layer {
            position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            background: linear-gradient(to right, rgba(0, 0, 0, 0.95) 0%, rgba(0, 0, 0, 0.75) 50%, rgba(0, 0, 0, 0) 100%);
            display: flex; flex-direction: column; justify-content: center;
            align-items: flex-start; padding-left: 50px; box-sizing: border-box;
            z-index: 10; opacity: 0;
            animation: fadeInUI 2s ease-in-out 22s forwards;
        }
        @keyframes fadeInUI {
            0% { opacity: 0; transform: translateX(-20px); }
            100% { opacity: 1; transform: translateX(0); pointer-events: auto; }
        }

        /* 🌟【改善】サユキちゃんの立ち絵も、スタッフロールが終わる「22秒後」に右側からクッキリ出現！ */
        .character-img {
            position: absolute; bottom: 0; right: 20px; height: 85%;
            z-index: 5; opacity: 0;
            filter: drop-shadow(0 0 15px rgba(255,255,255,0.3));
            animation: fadeInChar 2s ease-in-out 22s forwards;
        }
        @keyframes fadeInChar {
            0% { opacity: 0; transform: scale(0.98); }
            100% { opacity: 0.85; transform: scale(1); }
        }

        /* 🌟【改善】スタッフロールは中央に大きく配置し、邪魔なUIがない状態で静かに流す */
        .credits-container {
            position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            overflow: hidden; z-index: 4; pointer-events: none;
        }

        .credits-content {
            position: absolute; width: 100%; bottom: -100%;
            text-align: center; color: rgba(255, 255, 255, 0.8);
            line-height: 2;
            animation: scrollUp 22s linear forwards; 
        }

        .credits-content h3 { font-size: 1.1em; margin-top: 50px; margin-bottom: 5px; letter-spacing: 4px; color: #ffb6c1; text-shadow: 0 0 8px rgba(255,182,193,0.5); }
        .credits-content p { font-size: 0.95em; margin: 6px 0; letter-spacing: 2px; }

        @keyframes scrollUp { 
            0% { bottom: -100%; } 
            100% { bottom: 105%; } 
        }

        /* 文字装飾の調整 */
        .title-box { margin-bottom: 20px; text-align: left; }
        .title-box h1 {
            font-size: 2.8em; margin: 0; letter-spacing: 3px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.8);
            background: linear-gradient(45deg, #ff9a9e, #fecfef);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        }
        .title-box h2 { font-size: 1.2em; font-weight: normal; margin-top: 5px; color: #ddd; text-shadow: 1px 1px 2px #000; }

        .result-box {
            background: rgba(0, 0, 0, 0.6); border-left: 4px solid <%= rankColor %>;
            padding: 20px 25px; border-radius: 0 10px 10px 0; 
            backdrop-filter: blur(4px); margin-bottom: 30px;
            width: 420px; text-align: left;
        }
        .result-box p { font-size: 1em; margin: 10px 0; letter-spacing: 1px; line-height: 1.5; }
        .val { font-weight: bold; font-size: 1.25em; color: #ffb6c1; }
        
        /* 🌟エンディング名をそのまま評価にするCSSクラス */
        .rank-val { font-weight: bold; font-size: 1.4em; color: <%= rankColor %>; text-shadow: 0 0 8px <%= rankColor %>; }

        /* ボタン */
        .btn-container { display: flex; gap: 15px; }
        .btn {
            padding: 10px 25px; font-size: 1em; color: #fff; text-decoration: none;
            border: 1px solid rgba(255,255,255,0.6); border-radius: 25px; transition: all 0.3s; 
            background: rgba(0,0,0,0.6); cursor: pointer;
        }
        .btn:hover { background: #fff; color: #000; border-color: #fff; transform: scale(1.05); }

        /* 🌟手書きメッセージは、リザルト画面が出現したさらに後（25秒後）にフワッと表示 */
        .secret-message {
            position: absolute; bottom: 40px; right: 40px; z-index: 20;
            font-family: 'Yuji Syuku', serif; font-size: 1.5em; color: #fff;
            text-shadow: 0 0 6px rgba(255,255,255,0.8), 2px 2px 4px rgba(0,0,0,0.9);
            transform: rotate(-3deg); opacity: 0;
            animation: floatText 3s ease-in 25s forwards; 
        }

        @keyframes floatText {
            0% { opacity: 0; transform: rotate(-3deg) translateY(10px); }
            100% { opacity: 1; transform: rotate(-3deg) translateY(0); }
        }
    </style>
</head>
<body>

<div class="ending-container">
    <div class="credit-mask"></div>

    <div class="credits-container">
        <div class="credits-content">
            <h3>- CAST -</h3>
            <p>サユキ</p>
            <h3>- SCENARIO & DIRECTING -</h3>
            <p>匿名</p>
            <h3>- SYSTEM DEVELOPMENT -</h3>
            <p>匿名</p>
            <h3>- GRAPHIC & UI DESIGN -</h3>
            <p>匿名</p>
            <h3>- SPECIAL THANKS -</h3>
            <p>最後までプレイしてくれたあなた</p>
            <p style="margin-top: 60px; font-size: 1.2em; color: #ffb6c1;">Thank you for playing!</p>
        </div>
    </div>

    <img src="images/<%= charImage %>" class="character-img" alt="Sayuki">
    
    <div class="ui-layer">
        <div class="title-box">
            <h1><%= endTitle %></h1>
            <h2>- <%= endSubTitle %> -</h2>
        </div>

        <div class="result-box">
            <p style="font-size: 0.85em; color: #ccc; margin-bottom: 15px; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 10px;">
                <%= message %>
            </p>
            <p>最終 Love ポイント : <span class="val"><%= finalLove %></span></p>
            <p>最終 Like ポイント : <span class="val"><%= finalLike %></span></p>
            
            <p style="margin-top: 15px; border-top: 1px dashed rgba(255,255,255,0.3); padding-top: 15px;">
                最終評価：<span class="rank-val"><%= endTitle %></span> <span style="font-size: 0.9em; color:#ddd;"><%= endSubTitle %></span>
            </p>
        </div>

        <div class="btn-container">
            <a href="ArtServlet" class="btn">ギャラリーへ</a>
            <a href="MainServlet" class="btn">タイトルへ戻る</a>
        </div>
    </div>

    <div class="secret-message">
        <%= secretMsg %>
    </div>
</div>

</body>
</html>