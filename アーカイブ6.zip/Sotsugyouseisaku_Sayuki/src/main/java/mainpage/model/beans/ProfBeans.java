package mainpage.model.beans;

import java.io.Serializable;

public class ProfBeans implements Serializable {
	private String userId;
	private boolean isIntroUnlocked; // 最初から
	private boolean isWorkUnlocked; // Like 30
	private boolean isLikesUnlocked; // Love 30
	private boolean isPersonalUnlocked; // Love 50
	private boolean isSizesUnlocked; // Love 80
	private boolean isSecretUnlocked; // Love 80 & Like 80

	public ProfBeans() {
		this.isIntroUnlocked = true;
		this.isWorkUnlocked = false;
		this.isLikesUnlocked = false;
		this.isPersonalUnlocked = false;
		this.isSizesUnlocked = false;
		this.isSecretUnlocked = false;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public boolean isIntroUnlocked() {
		return isIntroUnlocked;
	}

	public void setIntroUnlocked(boolean isIntroUnlocked) {
		this.isIntroUnlocked = isIntroUnlocked;
	}

	public boolean isWorkUnlocked() {
		return isWorkUnlocked;
	}

	public void setWorkUnlocked(boolean isWorkUnlocked) {
		this.isWorkUnlocked = isWorkUnlocked;
	}

	public boolean isLikesUnlocked() {
		return isLikesUnlocked;
	}

	public void setLikesUnlocked(boolean isLikesUnlocked) {
		this.isLikesUnlocked = isLikesUnlocked;
	}

	public boolean isPersonalUnlocked() {
		return isPersonalUnlocked;
	}

	public void setPersonalUnlocked(boolean isPersonalUnlocked) {
		this.isPersonalUnlocked = isPersonalUnlocked;
	}

	public boolean isSizesUnlocked() {
		return isSizesUnlocked;
	}

	public void setSizesUnlocked(boolean isSizesUnlocked) {
		this.isSizesUnlocked = isSizesUnlocked;
	}

	public boolean isSecretUnlocked() {
		return isSecretUnlocked;
	}

	public void setSecretUnlocked(boolean isSecretUnlocked) {
		this.isSecretUnlocked = isSecretUnlocked;
	}
}