package mainpage.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import mainpage.model.beans.ProfBeans;

public class ProfDAO {
	private final String JDBC_URL = "jdbc:mysql://localhost:3306/sayuki_page";
	private final String DB_USER = "root";
	private final String DB_PASS = "1234";

	// 1. ユーザーのプロフィール解放状況を取得する
	public ProfBeans getProfileUnlocks(String userId) {
		ProfBeans prof = new ProfBeans();
		prof.setUserId(userId);
		if ("guest".equals(userId)) return prof;

		String sql = "SELECT * FROM user_profile_unlocks WHERE user_id = ?";
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
			 PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, userId);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				prof.setIntroUnlocked(rs.getBoolean("is_intro_unlocked"));
				prof.setWorkUnlocked(rs.getBoolean("is_work_unlocked"));
				prof.setLikesUnlocked(rs.getBoolean("is_likes_unlocked"));
				prof.setPersonalUnlocked(rs.getBoolean("is_personal_unlocked"));
				prof.setSizesUnlocked(rs.getBoolean("is_sizes_unlocked"));
				prof.setSecretUnlocked(rs.getBoolean("is_secret_unlocked"));
			} else {
				insertInitialProf(userId);
			}
		} catch (SQLException e) { e.printStackTrace(); }
		return prof;
	}

	private void insertInitialProf(String userId) {
		String sql = "INSERT INTO user_profile_unlocks (user_id, is_intro_unlocked, is_work_unlocked, is_likes_unlocked, is_personal_unlocked, is_sizes_unlocked, is_secret_unlocked) VALUES (?, true, false, false, false, false, false)";
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
			 PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, userId);
			ps.executeUpdate();
		} catch (SQLException e) { e.printStackTrace(); }
	}

	public void unlockFeature(String userId, String columnName) {
		if ("guest".equals(userId)) return;
		String sql = "UPDATE user_profile_unlocks SET " + columnName + " = true WHERE user_id = ?";
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
			 PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, userId);
			ps.executeUpdate();
		} catch (SQLException e) { e.printStackTrace(); }
	}
}