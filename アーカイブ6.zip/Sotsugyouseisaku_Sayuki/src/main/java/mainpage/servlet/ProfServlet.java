package mainpage.servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import mainpage.model.beans.ProfBeans;
import mainpage.model.dao.ProfDAO;
import sayukiGame.model.beans.Sayuki_Sakota;
import sayukiGame.model.dao.SayukiGameDAO;
import userMS.model.beans.UsersBeans;

@WebServlet("/ProfServlet")
public class ProfServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		UsersBeans user = (UsersBeans) session.getAttribute("loginUser");
		Sayuki_Sakota sayuki = (Sayuki_Sakota) session.getAttribute("sayukiData");

		if (user == null) {
			response.sendRedirect("UsersLoginServlet");
			return;
		}
		// 1. プロフィール解放状況の取得 (既存処理)
		ProfDAO dao = new ProfDAO();
		ProfBeans unlocks = dao.getProfileUnlocks(user.getId());

		if (sayuki != null && !"guest".equals(user.getId())) {
			int love = sayuki.getLovePoint();
			int like = sayuki.getLikePoint();

			if (like >= 30 && !unlocks.isWorkUnlocked()) {
				dao.unlockFeature(user.getId(), "is_work_unlocked");
				unlocks.setWorkUnlocked(true);
			}
			if (love >= 30 && !unlocks.isLikesUnlocked()) {
				dao.unlockFeature(user.getId(), "is_likes_unlocked");
				unlocks.setLikesUnlocked(true);
			}
			if (love >= 50 && !unlocks.isPersonalUnlocked()) {
				dao.unlockFeature(user.getId(), "is_personal_unlocked");
				unlocks.setPersonalUnlocked(true);
			}
			if (love >= 80 && !unlocks.isSizesUnlocked()) {
				dao.unlockFeature(user.getId(), "is_sizes_unlocked");
				unlocks.setSizesUnlocked(true);
			}
			if (love >= 80 && like >= 80 && !unlocks.isSecretUnlocked()) {
				dao.unlockFeature(user.getId(), "is_secret_unlocked");
				unlocks.setSecretUnlocked(true);
			}
		}

		// 🌟 2. 【追加】セーブデータの読み込み（モーダル表示用）
	    if (!"guest".equals(user.getId())) {
	        SayukiGameDAO sDao = new SayukiGameDAO();
	        List<Sayuki_Sakota> saveSlots = sDao.getAllSlots(user.getId());
	        request.setAttribute("saveSlots", saveSlots);

	        // ひとつでもデータがあるか判定
	        boolean hasSaveData = false;
	        for (Sayuki_Sakota slot : saveSlots) {
	            if (slot != null) { hasSaveData = true; break; }
	        }
	        request.setAttribute("hasSaveData", hasSaveData);
	    }
		request.setAttribute("unlocks", unlocks);
		request.getRequestDispatcher("WEB-INF/jsp/contents/prof.jsp").forward(request, response);
	}
}