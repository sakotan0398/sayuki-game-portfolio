package sayukiGame.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import sayukiGame.model.beans.Player;
import sayukiGame.model.beans.Sayuki_Sakota;
import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;
import sayukiGame.model.bo.SayukiGameLogic;
import sayukiGame.model.dao.SayukiGameDAO;
import userMS.model.beans.UsersBeans;

@WebServlet("/SayukiGameServlet")
public class SayukiGameServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		UsersBeans loginUser = (UsersBeans) session.getAttribute("loginUser");

		if (loginUser == null) {
			response.sendRedirect("UsersLoginServlet");
			return;
		}

		String userId = loginUser.getId();
		Player p = (Player) session.getAttribute("playerData");
		if (p == null) {
			p = new Player();
		}
		// セッションに古い「ゲスト」の名前が残っていても、常に最新のログインユーザーのHNで強制上書きする
		p.setName(loginUser.getHn());
		session.setAttribute("playerData", p);

		SayukiGameLogic logic = new SayukiGameLogic();
		Sayuki_Sakota s = null;
		SayukiGameDAO dao = new SayukiGameDAO();

		String slotIdStr = request.getParameter("slotId");
		int slotId = (slotIdStr != null) ? Integer.parseInt(slotIdStr) : 1;
		session.setAttribute("currentSlotId", slotId);

		if (!"guest".equals(userId)) {
			String mode = request.getParameter("mode");
			if ("new".equals(mode)) {
				dao.deleteSaveSlot(userId, slotId);
			} else if ("continue".equals(mode)) {
				s = dao.loadGameData(userId, slotId);

				// 🌟【追加】ギャラリー（Art.jsp）から呼ばれる「おまけシナリオ」開始モード
			} else if ("bonus".equals(mode)) {
				s = new Sayuki_Sakota(); // セーブデータを汚さない空の一時データ
				String bonusType = request.getParameter("type");
				int bonusPhase = 100; // True後日談
				if ("Love".equals(bonusType))
					bonusPhase = 101;
				if ("Like".equals(bonusType))
					bonusPhase = 102;
				if ("Normal".equals(bonusType))
					bonusPhase = 103;

				session.setAttribute("currentPhaseLevel", bonusPhase);
				session.setAttribute("currentScenarioId", 0);
				session.setAttribute("sayukiData", s);
			}
		}

		String displayImage = "sayuki_normal.png";
		String displayBg = "bg06819201440.jpg";
		String timeFilter = "day";

		List<String> backlog = new ArrayList<>();

		// ロード成功、またはおまけモード開始時
		if (s != null) {
			// mode=bonusの時はすでにセッションにセットしてあるので、ロード時のみ上書き
			if (!"bonus".equals(request.getParameter("mode"))) {
				int loadedPhase = s.getLoadedPhase();
				int loadedScenarioId = s.getLoadedScenarioId();
				session.setAttribute("currentPhaseLevel", loadedPhase);
				session.setAttribute("currentScenarioId", loadedScenarioId);
				session.setAttribute("sayukiData", s);
			}

			int currentPhase = (Integer) session.getAttribute("currentPhaseLevel");
			int currentScenId = (Integer) session.getAttribute("currentScenarioId");

			ScenarioData resumeData = logic.getScenarioData(currentPhase, currentScenId, p, s);

			String msgPrefix = "bonus".equals(request.getParameter("mode")) ? "【おまけシナリオ開始】"
					: "【データ " + slotId + " ロード完了】";
			String msg = "[NAME:SYSTEM]" + msgPrefix + "[NEXT]" + resumeData.getMessage();

			request.setAttribute("message", msg);
			request.setAttribute("choice1Text", resumeData.getChoice1Text());
			request.setAttribute("choice2Text", resumeData.getChoice2Text());
			request.setAttribute("choice3Text", resumeData.getChoice3Text());

			session.setAttribute("lastDisplayedMessage", msg);
			request.setAttribute("currentTurnLogs", formatLogMessageAsList(msg, p.getName()));

			if (resumeData.getVisuals() != null) {
				VisualBeans vb = resumeData.getVisuals();
				if (vb.getCharacterImage() != null && !vb.getCharacterImage().isEmpty())
					displayImage = vb.getCharacterImage();
				if (vb.getBackgroundImage() != null && !vb.getBackgroundImage().isEmpty())
					displayBg = vb.getBackgroundImage();
				if (vb.getTimeFilter() != null)
					timeFilter = vb.getTimeFilter();
			}
		} else {
			// 完全新規ゲーム開始
			s = new Sayuki_Sakota();
			session.setAttribute("currentPhaseLevel", 0);
			session.setAttribute("currentScenarioId", 0);
			session.setAttribute("sayukiData", s);

			ScenarioData introData = logic.getScenarioData(0, 0, p, s);
			request.setAttribute("message", introData.getMessage());
			request.setAttribute("choice1Text", introData.getChoice1Text());
			request.setAttribute("choice2Text", introData.getChoice2Text());
			request.setAttribute("choice3Text", introData.getChoice3Text());

			session.setAttribute("lastDisplayedMessage", introData.getMessage());

			request.setAttribute("currentTurnLogs", formatLogMessageAsList(introData.getMessage(), p.getName()));

			if (introData.getVisuals() != null) {
				VisualBeans vb = introData.getVisuals();
				if (vb.getCharacterImage() != null && !vb.getCharacterImage().isEmpty())
					displayImage = vb.getCharacterImage();
				if (vb.getBackgroundImage() != null && !vb.getBackgroundImage().isEmpty())
					displayBg = vb.getBackgroundImage();
				if (vb.getTimeFilter() != null)
					timeFilter = vb.getTimeFilter();
			}
		}

		session.setAttribute("backlog", backlog);

		if (!"guest".equals(userId)) {
			List<Sayuki_Sakota> saveSlots = dao.getAllSlots(userId);
			request.setAttribute("saveSlots", saveSlots);
		}

		request.setAttribute("calendarDate", logic.getCalendarDate(s.getCurrentTurn()));
		request.setAttribute("characterImage", displayImage);
		request.setAttribute("backgroundImage", displayBg);
		request.setAttribute("timeFilter", timeFilter);

		request.getRequestDispatcher("WEB-INF/jsp/game/sayuki_game.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		Sayuki_Sakota s = (Sayuki_Sakota) session.getAttribute("sayukiData");
		UsersBeans loginUser = (UsersBeans) session.getAttribute("loginUser");
		String userId = (loginUser != null) ? loginUser.getId() : "guest";

		Player p = (Player) session.getAttribute("playerData");
		if (p != null && loginUser != null) {
			p.setName(loginUser.getHn());
		}

		String choiceStr = request.getParameter("choice");
		int choice = (choiceStr != null && !choiceStr.isEmpty()) ? Integer.parseInt(choiceStr) : 1;

		Integer lastNum = (Integer) session.getAttribute("currentScenarioId");
		Integer lastPhase = (Integer) session.getAttribute("currentPhaseLevel");

		SayukiGameLogic logic = new SayukiGameLogic();

		// logicのprocessTurnを呼んで、次の会話データとポイント変動を取得
		ScenarioData nextData = logic.processTurn(choice, lastPhase, lastNum, s, p, userId);

		// 🌟【追加】後日談（おまけ）が最後まで終わった場合、セッションを汚さず即座にギャラリーへリダイレクト！
		if (nextData.getPhaseLevel() == 999) {
			response.sendRedirect("ArtServlet");
			return;
		}

		session.setAttribute("currentPhaseLevel", nextData.getPhaseLevel());
		session.setAttribute("currentScenarioId", nextData.getScenarioId());

		// 🌟【重要修正】
		// イントロ(0,0)・エンディング(Phase 6)・春夏冬イベント(90番台)・さらに後日談(100番台)の時はターンを進めない（完全時間停止）
		// これにより「続きを読む」を押してもカレンダーが進んでバグるのを永続ガード！
		if (!(lastPhase == 0 && lastNum == 0) && lastPhase != 6 && lastPhase < 90) {
			s.nextTurn();
		}

		session.setAttribute("sayukiData", s);

		// エンディングのチェック
		if (s.getCurrentTurn() > 52) {
			String endingType = logic.checkEnding(s);
			request.setAttribute("endingType", endingType);
			request.getRequestDispatcher("WEB-INF/jsp/game/ending.jsp").forward(request, response);
			return;
		}

		String displayImage = "sayuki_normal.png";
		String displayBg = "bg06819201440.jpg";
		String timeFilter = "day";

		if (nextData.getVisuals() != null) {
			timeFilter = nextData.getVisuals().getTimeFilter();
			displayBg = nextData.getVisuals().getBackgroundImage();
		}

		ScenarioData lastData = logic.getScenarioData(lastPhase, lastNum, p, s);
		if (lastData != null) {
			VisualBeans vb = null;
			if (choice == 1)
				vb = lastData.getRes1Visuals();
			else if (choice == 2)
				vb = lastData.getRes2Visuals();
			else if (choice == 3)
				vb = lastData.getRes3Visuals();

			if (vb != null) {
				if (vb.getCharacterImage() != null && !vb.getCharacterImage().isEmpty())
					displayImage = vb.getCharacterImage();
				if (vb.getBackgroundImage() != null && !vb.getBackgroundImage().isEmpty())
					displayBg = vb.getBackgroundImage();
				if (vb.getTimeFilter() != null)
					timeFilter = vb.getTimeFilter();
			}
		}

		if (!"guest".equals(userId)) {
			SayukiGameDAO dao = new SayukiGameDAO();
			List<Sayuki_Sakota> saveSlots = dao.getAllSlots(userId);
			request.setAttribute("saveSlots", saveSlots);
		}

		request.setAttribute("message", nextData.getMessage());
		request.setAttribute("choice1Text", nextData.getChoice1Text());
		request.setAttribute("choice2Text", nextData.getChoice2Text());
		request.setAttribute("choice3Text", nextData.getChoice3Text());
		request.setAttribute("calendarDate", logic.getCalendarDate(s.getCurrentTurn()));
		request.setAttribute("characterImage", displayImage);
		request.setAttribute("backgroundImage", displayBg);
		request.setAttribute("timeFilter", timeFilter);

		@SuppressWarnings("unchecked")
		List<String> backlog = (List<String>) session.getAttribute("backlog");
		if (backlog == null)
			backlog = new ArrayList<>();

		String lastMsg = (String) session.getAttribute("lastDisplayedMessage");
		if (lastMsg != null) {
			backlog.add(formatLogMessage(lastMsg, p.getName()));
		}

		String playerChoiceText = "";
		if (choice == 1)
			playerChoiceText = lastData.getChoice1Text();
		else if (choice == 2)
			playerChoiceText = lastData.getChoice2Text();
		else if (choice == 3)
			playerChoiceText = lastData.getChoice3Text();

		String playerLog = "<div class='log-entry player-log'>" +
				"<div class='log-name player-name'>" + p.getName() + "</div>" +
				"<div class='log-text'>" + playerChoiceText + "</div>" +
				"</div>";
		backlog.add(playerLog);

		session.setAttribute("lastDisplayedMessage", nextData.getMessage());
		request.setAttribute("currentTurnLogs", formatLogMessageAsList(nextData.getMessage(), p.getName()));

		while (backlog.size() > 50) {
			backlog.remove(0);
		}
		session.setAttribute("backlog", backlog);

		request.getRequestDispatcher("WEB-INF/jsp/game/sayuki_game.jsp").forward(request, response);
	}

	private List<String> formatLogMessageAsList(String rawMsg, String playerName) {
		List<String> list = new ArrayList<>();
		if (rawMsg == null || rawMsg.isEmpty())
			return list;

		String clean = rawMsg.replaceAll("\\[IMG:[^\\]]*\\]", "");
		String[] parts = clean.split("\\[NEXT\\]");

		for (String part : parts) {
			String name = "SYSTEM";
			String text = part;

			if (part.contains("[NAME:")) {
				int start = part.indexOf("[NAME:") + 6;
				int end = part.indexOf("]", start);
				if (end != -1) {
					name = part.substring(start, end).trim();
					text = part.substring(end + 1).trim();
				}
			}

			String displayName;
			String cssClass;

			if (name.equalsIgnoreCase("SAYUKI") || name.equals("サユキ")) {
				displayName = "SAYUKI";
				cssClass = "log-name sayuki-name";
			} else if (name.equalsIgnoreCase("PLAYER") || name.equals("Player") || name.equals(playerName)) {
				displayName = playerName;
				cssClass = "log-name player-name";
			} else {
				displayName = "SYSTEM";
				cssClass = "log-name sys-name";
			}

			String entry = "<div class='log-entry'>" +
					"<div class='" + cssClass + "'>" + displayName + "</div>" +
					"<div class='log-text'>" + text + "</div>" +
					"</div>";
			list.add(entry);
		}
		return list;
	}

	private String formatLogMessage(String rawMsg, String playerName) {
		StringBuilder sb = new StringBuilder();
		for (String s : formatLogMessageAsList(rawMsg, playerName)) {
			sb.append(s);
		}
		return sb.toString();
	}
}