package sayukiGame.servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import sayukiGame.model.beans.Sayuki_Sakota;
import sayukiGame.model.dao.SayukiGameDAO;
import userMS.model.beans.UsersBeans;

@WebServlet("/SaveGameServlet")
public class SaveGameServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

		// 1. セッションから必要なデータを取り出す
		UsersBeans loginUser = (UsersBeans) session.getAttribute("loginUser");
		Sayuki_Sakota s = (Sayuki_Sakota) session.getAttribute("sayukiData");

		Integer currentPhase = (Integer) session.getAttribute("currentPhaseLevel");
		Integer currentScenarioId = (Integer) session.getAttribute("currentScenarioId");

		// 💡 JSP（スロット選択画面）から送られてきた slotId を取得
		String slotIdStr = request.getParameter("slotId");
		int slotId = (slotIdStr != null) ? Integer.parseInt(slotIdStr) : 1;

		// ゲストユーザーやデータ欠損のチェック
		if (loginUser == null || "guest".equals(loginUser.getId()) || s == null || currentPhase == null
				|| currentScenarioId == null) {
			response.sendRedirect("MainServlet");
			return;
		}

		// 2. DAOを呼び出して、指定したスロットにセーブを実行！
		SayukiGameDAO dao = new SayukiGameDAO();
		// 💡 引数に slotId を追加
		boolean isSuccess = dao.saveGameData(loginUser.getId(), slotId, s, currentPhase, currentScenarioId);

		// 3. 結果に応じた処理
		if (isSuccess) {
			// セーブ成功時：今のスロット番号を更新してメイン画面へ
			session.setAttribute("currentSlotId", slotId);

			// 💡 お掃除（ゲームを終了して戻る場合）
			session.removeAttribute("sayukiData");
			session.removeAttribute("playerData");
			session.removeAttribute("currentPhaseLevel");
			session.removeAttribute("currentScenarioId");

			response.sendRedirect("MainServlet?saveSuccess=true");
		} else {
			// セーブ失敗時
			request.setAttribute("errorMsg", "スロット" + slotId + "へのセーブに失敗しました。");
			request.getRequestDispatcher("WEB-INF/jsp/game/sayuki_game.jsp").forward(request, response);
		}
	}
}