package sayukiGame.model.beans;

public class Sayuki_Sakota extends Character {

	private String name = "サユキ";
	//好感度、友好度 初期値0
	private int LovePoint = 0;
	private int LikePoint = 0;

	// ターン制限
	private int currentTurn = 1;

	// フラグ管理
	// イベントの二度見防止フラグ（デフォルトは false）
	private boolean springEventSeen = false;
	private boolean summerEventSeen = false;
	private boolean winterEventSeen = false;

	// === Getter / Setter ===
	// セーブとロード
	private int loadedPhase; // DBから読み込んだPhase保存用
	private int loadedScenarioId; // DBから読み込んだ会話ID保存用

	// LovePointの加算,上限100
	public void addLovePoint(int point) {

		this.setLovePoint(this.getLovePoint() + point);

		// 0以下にならない
		if (this.getLovePoint() <= 0)
			this.setLovePoint(0);

		// 100以上にならない
		if (this.getLovePoint() > 100)
			this.setLovePoint(100);

	}

	// LikePointの加算,上限100
	public void addLikePoint(int point) {
		this.setLikePoint(this.getLikePoint() + point);

		// 0以下にならない
		if (this.getLikePoint() <= 0)
			this.setLikePoint(0);

		// 100以上にならない
		if (this.getLikePoint() > 100)
			this.setLikePoint(100);
	}

	// イベント管理用
	private int eventScore = 0;

	// 名前のgetter,setter
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	// 好感度のgetter,setter
	public int getLovePoint() {
		return LovePoint;
	}

	public void setLovePoint(int lovePoint) {
		LovePoint = lovePoint;
	}

	// 友好度のgetter,setter
	public int getLikePoint() {
		return LikePoint;
	}

	public void setLikePoint(int likePoint) {
		LikePoint = likePoint;
	}

	// getter,setter

	public int getCurrentTurn() {
		return currentTurn;
	}

	public void setCurrentTurn(int currentTurn) {
		this.currentTurn = currentTurn;
	}

	public int getLoadedPhase() {
		return loadedPhase;
	}

	public void setLoadedPhase(int loadedPhase) {
		this.loadedPhase = loadedPhase;
	}

	public int getLoadedScenarioId() {
		return loadedScenarioId;
	}

	public void setLoadedScenarioId(int loadedScenarioId) {
		this.loadedScenarioId = loadedScenarioId;
	}

	public int getEventScore() {
		return eventScore;
	}

	public void setEventScore(int eventScore) {
		this.eventScore = eventScore;
	}

	// ターンを1進めるための便利メソッド
	public void nextTurn() {
		this.currentTurn++;
	}

	public boolean isSpringEventSeen() {
		return springEventSeen;
	}

	public void setSpringEventSeen(boolean springEventSeen) {
		this.springEventSeen = springEventSeen;
	}

	public boolean isSummerEventSeen() {
		return summerEventSeen;
	}

	public void setSummerEventSeen(boolean summerEventSeen) {
		this.summerEventSeen = summerEventSeen;
	}

	public boolean isWinterEventSeen() {
		return winterEventSeen;
	}

	public void setWinterEventSeen(boolean winterEventSeen) {
		this.winterEventSeen = winterEventSeen;
	}

}
