package sayukiGame.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import sayukiGame.model.beans.Sayuki_Sakota;

public class SayukiGameDAO {
	// データベース接続設定
	private final String JDBC_URL = "jdbc:mysql://localhost:3306/sayuki_page";
	private final String DB_USER = "root";
	private final String DB_PASS = "1234";

	/*
	 * 実績を保存・更新する
	 * エンディング到達時に Logic から呼び出されます
	 */
	public void updateClearStatus(String userId, String endingType) {
		String column = "";
		if ("True".equals(endingType))
			column = "true_cleared";
		else if ("Love".equals(endingType))
			column = "love_cleared";
		else if ("Like".equals(endingType))
			column = "like_cleared";
		else
			column = "bad_cleared";

		// 既にレコードがあればフラグを1に更新し、なければ新規作成するSQL
		String sql = "INSERT INTO clear_history (id, " + column + ") VALUES (?, 1) " +
				"ON DUPLICATE KEY UPDATE " + column + " = 1";

		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, userId);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 🔍 ユーザーが解放済みのコレクション（プロフィール項目など）の一覧を取得する
	public List<String> getUnlockedElements(String userId) {
		List<String> elements = new ArrayList<>();
		String sql = "SELECT element_key FROM unlock_collection WHERE user_id = ?";

		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, userId);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					elements.add(rs.getString("element_key"));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return elements;
	}

	/*
	 * プレイヤーのクリア履歴をすべて取得する
	 * ArtServlet からギャラリー表示判定のために呼び出されます
	 */
	public Map<String, Boolean> getClearHistory(String userId) {
		Map<String, Boolean> history = new HashMap<>();
		// 初期値（全て未クリア）を設定
		history.put("true_cleared", false);
		history.put("love_cleared", false);
		history.put("like_cleared", false);
		history.put("bad_cleared", false);

		String sql = "SELECT * FROM clear_history WHERE id = ?";
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, userId);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					history.put("true_cleared", rs.getInt("true_cleared") == 1);
					history.put("love_cleared", rs.getInt("love_cleared") == 1);
					history.put("like_cleared", rs.getInt("like_cleared") == 1);
					history.put("bad_cleared", rs.getInt("bad_cleared") == 1);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return history;
	}

	/**
	 * 💾 ゲームデータを保存する（スロットに上書き）
	 * 🌟【改善】並び順を「①キー ➔ ②時間・進行 ➔ ③パラメータ ➔ ④フラグ」に完全統一！
	 */
	public boolean saveGameData(String userId, int slotId, Sayuki_Sakota s, int currentPhase, int lastScenarioId) {
		boolean isSuccess = false;
		
		String sql = "INSERT INTO sayuki_save_data "
				+ "(USER_ID, SLOT_ID, CURRENT_TURN, CURRENT_PHASE, LAST_SCENARIO_ID, LOVE_POINT, LIKE_POINT, EVENT_SCORE, CLEARED_EVENTS) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) "
				+ "ON DUPLICATE KEY UPDATE "
				+ "CURRENT_TURN = VALUES(CURRENT_TURN), "
				+ "CURRENT_PHASE = VALUES(CURRENT_PHASE), "
				+ "LAST_SCENARIO_ID = VALUES(LAST_SCENARIO_ID), "
				+ "LOVE_POINT = VALUES(LOVE_POINT), "
				+ "LIKE_POINT = VALUES(LIKE_POINT), "
				+ "EVENT_SCORE = VALUES(EVENT_SCORE), "
				+ "CLEARED_EVENTS = VALUES(CLEARED_EVENTS)";

		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
				PreparedStatement pStmt = conn.prepareStatement(sql)) {

			// 1. 【キー情報】
			pStmt.setString(1, userId);
			pStmt.setInt(2, slotId);
			
			// 2. 【時間・タイムライン・進行管理】
			pStmt.setInt(3, s.getCurrentTurn());
			pStmt.setInt(4, currentPhase);
			pStmt.setInt(5, lastScenarioId);
			
			// 3. 【キャラクターのステータス・パラメータ】
			pStmt.setInt(6, s.getLovePoint());
			pStmt.setInt(7, s.getLikePoint());
			pStmt.setInt(8, s.getEventScore());

			// 4. 【既読・クリアフラグ】（カンマ区切り文字列に圧縮して1つのカラムへ保存）
			StringBuilder sb = new StringBuilder();
			if (s.isSpringEventSeen()) sb.append("SPRING,");
			if (s.isSummerEventSeen()) sb.append("SUMMER,");
			if (s.isWinterEventSeen()) sb.append("WINTER,");
			pStmt.setString(9, sb.toString());

			int result = pStmt.executeUpdate();
			if (result > 0)
				isSuccess = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isSuccess;
	}

	/**
	 * 📂 指定したスロットのデータを読み込む
	 * 🌟【改善】Java内のロード代入順も保存時と同じグループ順に整頓！
	 */
	public Sayuki_Sakota loadGameData(String userId, int slotId) {
		Sayuki_Sakota s = null;
		String sql = "SELECT * FROM sayuki_save_data WHERE USER_ID = ? AND SLOT_ID = ?";

		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
				PreparedStatement pStmt = conn.prepareStatement(sql)) {

			pStmt.setString(1, userId);
			pStmt.setInt(2, slotId);
			try (ResultSet rs = pStmt.executeQuery()) {
				if (rs.next()) {
					s = new Sayuki_Sakota();
					
					// 1. 【時間・タイムライン・進行管理】
					s.setCurrentTurn(rs.getInt("CURRENT_TURN"));
					s.setLoadedPhase(rs.getInt("CURRENT_PHASE"));
					s.setLoadedScenarioId(rs.getInt("LAST_SCENARIO_ID"));
					
					// 2. 【キャラクターのステータス・パラメータ】
					s.setLovePoint(rs.getInt("LOVE_POINT"));
					s.setLikePoint(rs.getInt("LIKE_POINT"));
					s.setEventScore(rs.getInt("EVENT_SCORE"));
					
					// 3. 【既読・クリアフラグ】（カンマ区切りの文字列から各フラグに解体・復元）
					String clearedEvents = rs.getString("CLEARED_EVENTS");
					if (clearedEvents != null) {
						s.setSpringEventSeen(clearedEvents.contains("SPRING"));
						s.setSummerEventSeen(clearedEvents.contains("SUMMER"));
						s.setWinterEventSeen(clearedEvents.contains("WINTER"));
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}
	
	/**
	 * 🔍 ユーザーの全3スロットのデータをリストで取得する
	 */
	public List<Sayuki_Sakota> getAllSlots(String userId) {
		List<Sayuki_Sakota> slots = new ArrayList<>();
		// スロット1〜3を順番にロードしてリストに詰める
		for (int i = 1; i <= 3; i++) {
			slots.add(this.loadGameData(userId, i)); 
		}
		return slots;
	}

	/**
	 * 🗑️ 指定したスロットのセーブデータを削除する
	 */
	public void deleteSaveSlot(String userId, int slotId) {
		String sql = "DELETE FROM sayuki_save_data WHERE user_id = ? AND slot_id = ?";
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, userId);
			ps.setInt(2, slotId);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 🔍 ユーザーが（どのスロットでもいいから）セーブデータを持っているか確認
	 * メインメニューの「CONTINUE」ボタンの表示判定に使用します
	 */
	public boolean checkSaveDataExists(String userId) {
		String sql = "SELECT COUNT(*) FROM sayuki_save_data WHERE USER_ID = ?";
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
				PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, userId);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					return rs.getInt(1) > 0;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
}