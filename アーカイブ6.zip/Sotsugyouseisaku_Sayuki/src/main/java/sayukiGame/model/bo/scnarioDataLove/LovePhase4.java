package sayukiGame.model.bo.scnarioDataLove;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;
import sayukiGame.model.bo.scnarioDataCommon.Phase4;

public class LovePhase4 extends Phase4 {

	@Override
	public ScenarioData getScenario(int num, String pName) {
		
		// 0〜8 が選ばれた場合は、親クラス（Common）の共通の日常会話をそのまま呼び出す
		if (num <= 8) {
			return super.getScenario(num, pName);
		}

		// 9〜14：Loveルート専用（理屈では抑えきれない好意と、壊したくない距離感）
		ScenarioData data = new ScenarioData();
		data.setPoolType("Love");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 

		switch (num) {
		case 9: // 【ケース9：重なる手と、解けない魔法】
			data.setVisuals(new VisualBeans("Sayuki_surprised.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]共有の本棚から、昨日二人で話していた画集を取り出そうとした瞬間、サユキの指先と俺の手が、昨日よりもずっと深く重なった。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「あ……っ」" +
				"[NEXT]" +
				"[NAME:NONE]反射的に手を引こうとした俺の手を、彼女の細い指が無意識に一瞬だけ、強く握り返した気がした。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……あ。……あの。……離して、ください。……心臓の音が、聞こえそうです……」"
			);
			data.setChoice1Text("あ、ごめん！ 意識しすぎた");
			data.setChoice2Text("（そのまま数秒間、じっと見つめ合う）");
			data.setChoice3Text("サユキさんの手、すごく熱いよ？");

			data.setRes1(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……別に、意識なんてしてません。……バカ。……さっさとその本、取ってください」" +
				"[NEXT]" +
				"[NAME:NONE]彼女はサッと顔を逸らしてしまった。気まずい空気が流れる。"
			);
			data.setC1Love(1); data.setC1Like(1); // 【停滞】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「っ……。……」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……もう。……そんな目で見ないでください。……作業、できなくなるじゃないですか……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は潤んだ瞳を揺らしながら、やっとの思いで手を離した。言葉以上の何かが通じ合った瞬間だった。"
			);
			data.setC2Love(5); data.setC2Like(0); // 【Love最大】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……排熱のせいです。PCが熱いから、体温が上がってるだけです。……余計なこと言わないでください」" +
				"[NEXT]" +
				"[NAME:NONE]冷たく言い返されたが、彼女の顔は耳の先まで真っ赤になっていた。照れ隠しの防壁を張らせてしまった。"
			);
			data.setC3Love(3); data.setC3Like(-1); // 【ツンデレ反応】
			break;

		case 10: // 【ケース10：微熱の正体と看病】
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]夕方。サユキが珍しくデスクでぐったりと突っ伏している。" +
				"[NEXT]" +
				"[NAME:PLAYER]「サユキさん、顔色が悪いよ。……少し熱があるんじゃないか？」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……大丈夫、です。……ただの、デバッグ疲れですから……」" +
				"[NEXT]" +
				"[NAME:NONE]俺が彼女の額に手を伸ばそうとすると、彼女は逃げるように身を引いた。"
			);
			data.setChoice1Text("無理は禁物だ。今日はもう帰りなよ");
			data.setChoice2Text("俺が冷たい飲み物、買ってくるよ");
			data.setChoice3Text("俺にうつしてもいいから、頼ってよ");

			data.setRes1(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……。そうですね。あなたの言う通りです。……。……おやすみなさい」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は寂しそうに荷物をまとめ、帰っていった。正論すぎて突き放したように聞こえたかもしれない。"
			);
			data.setC1Love(-2); data.setC1Like(2); // 【Like微増】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……。……。スポーツドリンクがいいです。……できれば、常温のやつ……」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……待ってますから。……早く、戻ってきてくださいね？」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は少しだけ心細そうに俺の服の裾を掴んだ。弱っている時の素直な甘えに心打たれた。"
			);
			data.setC2Love(4); data.setC2Like(2); // 【バランス正解】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！？ ……～～っ！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……バカ。……そんなこと言われたら、余計に熱が上がるじゃないですか……っ」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は顔を伏せて震えてしまった。激しく動揺させてしまったが、想いは確実に伝わったようだ。"
			);
			data.setC3Love(6); data.setC3Like(-2); // 【Love最大】
			data.setRes3Visuals(new VisualBeans("Sayuki_mesorasi.png", bgSunset, "cross_fade", "close_up", "sunset"));
			break;

		case 11: // 【ケース11：髪型の迷宮と本音】
			data.setVisuals(new VisualBeans("Sayuki_mesorasi.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]今日のサユキは、後ろ髪をサイドに寄せて結び、いつものパーカーを脱いで肩の露出が少ない落ち着いたブラウスを着ていた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……あの。今日、オーナーに会う予定があって……。……どう、ですか？」" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……いつもと、違いすぎますか？ あなたの……その、正直な感想を聞きたいんですけど……」"
			);
			data.setChoice1Text("大人の女性って感じで、すごく綺麗だよ");
			data.setChoice2Text("オーナーに失礼がない、いい格好だと思うよ");
			data.setChoice3Text("いつもの『戦闘服』の方がサユキさんらしいかな");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「き、綺麗……っ！？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……。……。……ありがとうございます。……あなたにそう言ってもらえるのが、一番、欲しかった言葉、かもしれません……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は耳まで真っ赤にして、ブラウスの袖をぎゅっと握った。一人の女性として最高の褒め言葉だったようだ。"
			);
			data.setC1Love(5); data.setC1Like(0); // 【Love最大】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……そう、ですね。管理人の代理として、相応しい格好であることは合理的です」" +
				"[NEXT]" +
				"[NAME:NONE]納得はしたようだが、どこか物足りなさそうな顔をして頷いた。"
			);
			data.setC2Love(1); data.setC2Like(4); // 【Like最大】

			data.setRes3(
				"[IMG:Sayuki_musu.png]" +
				"[NAME:SAYUKI]「……。……そうですか。つまり、今の私は私らしくないってことですね」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「せっかくオシャレしたつもりだったのに。……最悪です。鏡、見てきます」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の小さな勇気を否定してしまった。深く落ち込ませてしまったようだ。"
			);
			data.setC3Love(-4); data.setC3Like(-1); // 【大失敗】
			break;

		case 12: // 【ケース12：隠れた癖と、特別な観察眼】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]深夜のアトリエ。ふとサユキがモニターから視線を外し、隣の俺をじっと見ていた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……ねぇ、" + pName + "さん。……あなた、難しいバグを修正した時、無意識にペンを回す癖がありますよね」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……。そんな風に楽しそうに仕事をする人、私、初めて見ました」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……なんだか、そういうの見ていると。……私まで、描くのが楽しくなってくるんです。不思議、ですけど」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女は少し照れくさそうに、でもどこか嬉しそうに微笑んでいる）"
			);
			data.setChoice1Text("サユキさんの集中してる顔も、俺は好きだよ");
			data.setChoice2Text("そんなところまで見てたの？恥ずかしいな……");
			data.setChoice3Text("プロなら楽しんで仕事をするのは当然だよ");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！？ す、好きとか、そういう語彙を軽々しく使わないでください！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……。……。でも、まぁ。……見ててくれる人がいるなら、もう少しだけ、筆を動かしてみようかな……なんて」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は真っ赤になってペンを握り直した。お互いを高め合える、特別な存在になりつつある。"
			);
			data.setC1Love(5); data.setC1Like(2); // 【Love最大】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「っ！ べ、別に、観察してたわけじゃありません！ 視界の端に、嫌でも入ってくるだけです！」" +
				"[NEXT]" +
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……もういいです。今の話、完全に忘れてください。……バカ」" +
				"[NEXT]" +
				"[NAME:NONE]図星だったようで、彼女は猛烈な勢いで誤魔化した。からかいすぎたが、意識は強烈にさせている。"
			);
			data.setC2Love(4); data.setC2Like(-1); // 【Love特化】

			data.setRes3(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……そう、ですね。……ストイックというか、遊びがないというか。あなたらしいです」" +
				"[NEXT]" +
				"[NAME:NONE]納得はしたようだが、少しだけ寂しそうな顔をして画面に向き直ってしまった。もっと情緒のある返しを期待していたのかもしれない。"
			);
			data.setC3Love(0); data.setC3Like(4); // 【Like最大】
			break;

		case 13: // 【ケース13：無意識の依存と甘い休息】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]夕暮れ時。複雑な設計に悩んでいた俺の肩に、ふと柔らかな重みが乗った。" +
				"[NEXT]" +
				"[NAME:PLAYER]（……えっ？）" +
				"[NEXT]" +
				"[NAME:NONE]見ると、サユキが椅子を俺のすぐ隣まで寄せ、俺の肩に頭を預けてモニターを覗き込んでいた。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ここの構造、もう少しシンプルになりません？ ……。……あ。……すみません、つい……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は我に返ったように離れようとしたが、その動作はひどく名残惜しそうだった。"
			);
			data.setChoice1Text("（そのまま肩を貸してあげる）");
			data.setChoice2Text("近すぎて集中できないよ");
			data.setChoice3Text("サユキさんの髪、いい香りがするね");

			data.setRes1(
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……。……。……じゃあ、５分だけ。……５分だけ、貸してください。……落ち着くんです、あなたの隣……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は再び俺の肩に頭を預けた。静かな夕暮れのアトリエで、二人の心臓の音だけが共鳴していた。"
			);
			data.setC1Love(5); data.setC1Like(1); // 【Love最大】自然な密着

			data.setRes2(
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……っ！ す、すみません！ ……もう二度としませんから！」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は弾かれたように椅子を遠ざけ、部屋の隅まで行ってしまった。決定的な拒絶を感じさせてしまったようだ。"
			);
			data.setC2Love(-4); data.setC2Like(-2); // 【大失敗】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！！？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……。……変態。……エロプログラマー。……死ねばいいのに……っ」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は真っ赤になって怒り出したが、その手はしっかりと俺のジャケットを握りしめていた。"
			);
			data.setC3Love(5); data.setC3Like(-3); // 【Love最大・Like低下】
			break;

		case 14: // 【ケース14：かけがえのない『場所』の告白】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]夜。作業を終えたサユキが、片付けをしながら少し俯いて口を開いた。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「あの。" + pName + "さん。……。……私にとって、このオフィスは……ただの作業場だったんです」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「一人で静かに、誰にも邪魔されずに描ければそれでいい。そう思ってたんですけど……」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……今は、あなたが隣にいない静寂が、少しだけ……怖くなることがあるんです」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女はまっすぐ俺を見つめてきた。その瞳には、嘘偽りのない本心が宿っている）"
			);
			data.setChoice1Text("俺も同じだよ。サユキの隣が一番落ち着くんだ");
			data.setChoice2Text("これからも最高の仕事のパートナーでいよう");
			data.setChoice3Text("それって、俺がいないとダメってこと？");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！ ……ふふ。……はい」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……。……嬉しい、です。……これからも、ずっと。……私のわがまま、一番近くで聞いていてくださいね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は涙を浮かべたような、幸せそうな笑顔を見せた。二人の心は一つになった。"
			);
			data.setC1Love(6); data.setC1Like(3); // 【Loveルートの大正解】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……。そうですね。……これからも、お互いに高め合える関係でいたいですね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は寂しそうに微笑み、頷いた。好意は伝わったが、決定的な壁を越えることはできなかった。"
			);
			data.setC2Love(2); data.setC2Like(6); // 【Like最大・Love停滞】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！ ～～っ！」" +
				"[NEXT]" +
				"[IMG:Sayuki_scary_smile.png]" +
				"[NAME:SAYUKI]「……。……。ええ、そうですよ。……バカ。……一生、私のデバッグ作業に縛り付けてやりますからね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は真っ赤になって怒りながらも、どこか幸せそうに笑った。彼女なりの、最高の告白への返答だった。"
			);
			data.setC3Love(3); data.setC3Like(0); // 【Love大幅アップ】
			data.setRes3Visuals(new VisualBeans("Sayuki_scary_smile.png", bgNight, "cross_fade", "normal", "night"));
			break;

		default:
			return super.getScenario(0, pName);
		}
		return data;
	}
}