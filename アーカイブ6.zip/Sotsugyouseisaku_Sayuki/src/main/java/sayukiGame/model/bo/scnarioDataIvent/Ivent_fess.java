package sayukiGame.model.bo.scnarioDataIvent;

import sayukiGame.model.beans.Sayuki_Sakota;
import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;

public class Ivent_fess {

	public ScenarioData getScenario(int step, String pName, Sayuki_Sakota s) {
		ScenarioData data = new ScenarioData();
		data.setPoolType("Event");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 
		
		switch (step) {
		case 1: // 【起】待ち合わせと情景描写（服の描写を削除）
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"【🏮 夏の特別イベント：海辺の夏祭り】<br><br>" +
				"※イベントルール：あなたの選択肢によって、Love/Likeパラメータがリアルタイムに変動します。<br>" +
				"さらに最終ステージで合計スコアが高ければ、現在低い方のステータスにボーナスが加算されます！<br><br>" +
				"[NEXT]" +
				"[NAME:NONE]8月も終わりに近づき、茹だるような暑さも少しだけ和らいできた夕暮れ時。<br>" +
				"連日のマスターアップに向けた激務を労うため、俺はサユキさんを地元の大きな夏祭りに誘い出した。" +
				"[NEXT]" +
				"[NAME:NONE]神社の境内から漏れ聞こえるお囃子の音と、提灯の暖かな光。待ち合わせの鳥居前には、すでに大勢の人が行き交っている。" +
				"[NEXT]" +
				"[NAME:NONE]そんな人波を眺めていると、見慣れた彼女の姿がスッと目に飛び込んできた。<br>" +
				"PCの排熱音が響くいつものアトリエとは違う、喧騒と非日常の光の中に立つ彼女は、なんだか少しだけ新鮮に見えた。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……あ、" + pName + "さん。その……お待たせしました」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……何、ジロジロ見てるんですか。お祭りなんて行き慣れないから……人が多くて歩きにくいし……ちょっと、落ち着かないです」"
			);
			data.setChoice1Text("お祭りデートみたいでドキドキするよ（Love大幅アップ）"); 
			data.setChoice2Text("息抜きも大事だよ。今日は思いっきり楽しもう（Like大幅アップ）"); 
			data.setChoice3Text("やっぱ来るんじゃなかったね（Bad）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「デ、デートって……！ ～～っ、あなた、さらっと恥ずかしいこと言わないでくださいっ」" +
				"[NEXT]" +
				"[NAME:NONE]顔を真っ赤にして俯く彼女。リアルタイムでLoveとLikeがピコンと上昇した！"
			);
			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……。……そ、そうですか。なら、よかったです。行きましょうか」" +
				"[NEXT]" +
				"[NAME:NONE]少し照れくさそうに微笑み、彼女は俺の隣に並んで歩き出した。"
			);
			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……そうですか。せっかく時間作ったのに」" +
				"[NEXT]" +
				"[NAME:NONE]分かりやすくテンションを下げさせてしまった。"
			);

			// 🌟リアルタイム加算
			data.setC1Love(3); data.setC1Like(1);
			data.setC2Love(1); data.setC2Like(3);
			data.setC3Love(0); data.setC3Like(0);
			break;

		case 2: // 【承】屋台と非日常感
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(				
				"[NAME:NONE]立ち並ぶ屋台からは、焼きそばや綿飴の香ばしい香りが漂ってくる。<br>" +
				"普段はコーヒーの香りに包まれている俺たちにとって、この圧倒的な非日常感は良い刺激になっていた。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「あ……りんご飴。それに、水ヨーヨー……。ふふっ、なんだかUIのカラーパレットみたいに鮮やかですね」" +
				"[NEXT]" +
				"[NAME:NONE]お祭りでもクリエイターの癖が抜けない彼女の横顔を見ながら歩いていると、射的屋の前で彼女の足がピタリと止まった。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……あの景品の謎の生き物のぬいぐるみ、ちょっと敵キャラのモデリングの参考になりそう……！」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は真剣な眼差しでコルク銃を構えた。<br>" +
				"しかし、クリエイターとしての眼力とは裏腹に、放たれたコルクは惜しくも景品をかすめて外れてしまった。" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「ああっ、もうちょっとだったのに……！ マウスのエイムには自信があったんですけど……くやしい……っ」"
			);
			data.setChoice1Text("もう少し右を狙うといいよ（横からアドバイスする）（Love大幅アップ）"); 
			data.setChoice2Text("俺に任せて。絶対取ってやるよ（Like大幅アップ）"); 
			data.setChoice3Text("無駄遣いだよ、諦めて次に行こう（Bad）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「こ、こうですか……？ あ、当たりました！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:NONE]アドバイスの通りに撃つと見事に命中。至近距離から聞こえた俺の声に、彼女は少しだけ肩をすくめて照れくさそうに笑った。"
			);
			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「本当ですか！？ 相棒の意地、見せてくださいね！」" +
				"[NEXT]" +
				"[NAME:NONE]宣言通り景品を打ち落とすと、彼女は子供のように無邪気な笑顔を見せてくれた。"
			);
			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……分かってますよ。どうせ私のワガママですから」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:NONE]少し拗ねたように、彼女は足早に歩き出してしまった。"
			);

			data.setC1Love(3); data.setC1Like(1);
			data.setC2Love(1); data.setC2Like(3);
			data.setC3Love(0); data.setC3Like(0);
			break;

		case 3: // 【転】人混みと物理的な接近（下駄や浴衣の描写を削除）
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]夜の帳が完全に下り、遠くで花火大会の開始を告げるアナウンスが響いた。<br>" +
				"途端に、メイン会場へ向かう人の波が急激に激しさを増す。" +
				"[NEXT]" +
				"[NAME:NONE]押し寄せる波に逆らえず、二人の距離が強制的に縮まる。<br>" +
				"普段のアトリエでは絶対にありえないほどの距離感。彼女の髪から、微かに甘いシャンプーの香りがした。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「わっ……！？ きゅ、急に人が増えて……っ！ 押さないで……っ」" +
				"[NEXT]" +
				"[NAME:NONE]通行人の肩がぶつかり、慣れない人混みの中でサユキさんが大きくバランスを崩した。<br>" +
				"このままだと、完全に人波に飲まれ、はぐれてしまいそうだ。"
			);
			data.setChoice1Text("少し後ろに隠れてて（人波から庇う）（Love大幅アップ）"); 
			data.setChoice2Text("はぐれないように、俺の服の袖を掴んでて（Like大幅アップ）"); 
			data.setChoice3Text("ちゃんとはぐれないようについてきてよ（Bad）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「あ……すみません、助かります」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:NONE]彼女を人混みから守るように立つと、彼女は俺の背中越しに小さく安堵の息をついた。"
			);
			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「あ……はいっ。引っ張ってて、くださいね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は俺の服の袖を、はぐれないようにギュッと強く握りしめた。"
			);
			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「そんなこと言ったって、人が多くて……きゃっ！」" +
				"[NEXT]" +
				"[NAME:NONE]通行人にぶつかられ、少し痛そうに肩を押さえている。"
			);

			data.setC1Love(3); data.setC1Like(1);
			data.setC2Love(1); data.setC2Like(3);
			data.setC3Love(0); data.setC3Like(0);
			break;

		case 4: // 【結①】花火とクリエイターの苦悩
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]人混みをどうにか抜け出し、俺たちは少し小高い丘の上の静かな広場に出た。<br>" +
				"荒くなった呼吸を整えようとしたその瞬間――ドンッ！と、腹の底に響くような轟音と共に、夜空に大輪の花火が咲き誇った。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「わぁ……！ 綺麗……」" +
				"[NEXT]" +
				"[NAME:NONE]暗闇を彩る光が、彼女の横顔を鮮やかに照らし出す。<br>" +
				"瞳に花火を映しながら、彼女はどこか切なそうな、それでいて熱を帯びた声で呟いた。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも、少しだけ悔しいかも。<br>" +
				"花火のこの圧倒的な光の粒や、空気の震える感じ……。どれだけハイスペックなモニターでも、最先端のエンジンでも、今の私たちじゃ完全に再現できないから……」"
			);
			data.setChoice1Text("でも、今のサユキさんの笑顔もすごく綺麗だよ（Love大幅アップ）"); 
			data.setChoice2Text("俺たちのゲームなら、もっと感動を作れるよ（Like大幅アップ）"); 
			data.setChoice3Text("職業病だね。今はただ楽しもうよ（Bad）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！ だ、だからそういうこと、平気な顔して言わないでください……っ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:NONE]彼女は顔を赤くしてそっぽを向いたが、その表情は花火よりも輝いて見えた。"
			);
			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……！ ふふっ、大きく出ましたね。……でも、貴方となら作れる気がします」" +
				"[NEXT]" +
				"[NAME:NONE]花火の光に負けないくらい、彼女の笑顔は誇り高きクリエイターのものだった。"
			);
			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……そうですね。忘れてください」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:NONE]彼女は少し寂しそうに、無言で夜空を見つめ続けた。"
			);

			data.setC1Love(3); data.setC1Like(1);
			data.setC2Love(1); data.setC2Like(3);
			data.setC3Love(0); data.setC3Like(0);
			break;

		case 5: // 【結②】結果発表
			if (s.getEventScore() >= 24) {
				
				if (s.getLikePoint() > s.getLovePoint()) {
					// 👉 仕事仲間（Like）寄りだった場合：Loveを底上げ
					data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
					data.setMessage(						"[NAME:NONE]帰り道。祭りの熱気から少し離れた静かな夜道で、サユキさんが少し恥ずかしそうに俺の服の袖を引っ張った。" +
						"[NEXT]" +
						"[IMG:Sayuki_mesorasi.png]" +
						"[NAME:SAYUKI]「……あの、今日のこと、仕事仲間には内緒にしてくださいね。だって、これじゃ……まるで本当のデートみたいだったから……っ」" +
						"[NEXT]" +
						"[NAME:NONE]（夏祭りデートの大成功により、一人の異性としても強く意識し始めた！：Loveボーナス +5）"
					);
					s.addLovePoint(5); 
				} else {
					// 👉 恋愛（Love）寄りだった場合：Likeを底上げ
					data.setMessage(
						"[NAME:NONE]帰り道。夜風が涼しく吹き抜ける中、サユキさんが晴れやかな表情でこちらを振り返った。" +
						"[NEXT]" +
						"[IMG:Sayuki_nomal.png]" +
						"[NAME:SAYUKI]「あの、" + pName + "さん。私、今日で確信しました。貴方は私の最高の相棒で……世界で一番信頼できる人です」" +
						"[NEXT]" +
						"[NAME:NONE]（夏祭りのお出かけ成功により、二人の絆がかつてないほど強まった！：Likeボーナス +5）"
					);
					s.addLikePoint(5); 
				}

			} else {
				// ❌ スコア不足
				data.setMessage(
					"[NAME:NONE]帰り道。" +
					"[NEXT]" +
					"[IMG:Sayuki_dakara.png]" +
					"[NAME:SAYUKI]「今日はありがとうございました。……じゃあ、また明日。アトリエで」" +
					"[NEXT]" +
					"[NAME:NONE]サユキは軽く会釈をして、足早に帰ってしまった。少し距離の詰め方を間違えたかもしれない……。（ボーナスなし）"
				);
			}
			
			data.setChoice1Text("日常に戻る"); data.setChoice2Text("日常に戻る"); data.setChoice3Text("日常に戻る");
			data.setRes1(""); data.setRes2(""); data.setRes3("");
			break;
		}
		return data;
	}
}