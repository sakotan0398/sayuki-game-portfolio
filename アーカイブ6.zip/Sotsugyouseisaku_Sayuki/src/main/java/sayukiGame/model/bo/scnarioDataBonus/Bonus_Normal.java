package sayukiGame.model.bo.scnarioDataBonus;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;

public class Bonus_Normal {

	public ScenarioData getScenario(int step, String pName) {
		ScenarioData data = new ScenarioData();
		data.setPoolType("Bonus");

		// 後日談は選択肢なしの一本道で進める
		data.setChoice1Text("続きを読む ▼");
		data.setChoice2Text("続きを読む ▼");
		data.setChoice3Text("続きを読む ▼");
		data.setRes1(""); data.setRes2(""); data.setRes3("");

		String bgFes = "bg02919201440.jpg"; 
		String bgSunset = "bg064y19201440.jpg"; 

		switch (step) {
		case 0: // 【起】数年後のゲーム展示会-
			data.setVisuals(new VisualBeans("none", bgFes, "fade", "normal", "day"));
			data.setMessage(
				"【🍃 Normal End 後日談：もしもあの時、別の選択ができたなら】<br><br>" +
				"[NEXT]" +
				"[NAME:NONE]あのアトリエを引き払い、サユキに合鍵を返してから、数年の月日が流れていた。" +
				"[NEXT]" +
				"[NAME:NONE]俺は別の開発現場でエンジニアとしてのキャリアを積み、今日、国内最大級のインディーゲーム展示会の会場に足を運んでいた。" +
				"[NEXT]" +
				"[NAME:NONE]数千人の熱気とブースから響くゲーム音で行き交う人混みの中、一つの出展ブースの前に、異様なほど大きな人だかりができているのが見えた。"
			);
			break;

		case 1: // 【承】見覚えのあるアート
			data.setMessage(
				"[NAME:NONE]何気なくその人だかりの隙間から、試遊中のモニター画面を覗き込んだ瞬間——俺の心臓が、ドクンと大きく跳ね上がった。" +
				"[NEXT]" +
				"[NAME:NONE]モニターに映し出されていたのは、息を呑むほど繊細で、どこか頑固なまでに美しい色彩を放つ2Dグラフィック。" +
				"[NEXT]" +
				"[NAME:NONE]間違いない。世界中にどれほど絵描きがいようとも、この独特なライティングのセンスと線の引き方は……あのサユキのものだ。" +
				"[NEXT]" +
				"[NAME:PLAYER]（サユキさん……。一人で、新しいゲームを完成させたんだな……）"
			);
			break;

		case 2: // 【転1】よみがえる後悔
			data.setMessage(
				"[NAME:NONE]画面を見つめていると、胸の奥から苦しいほどの懐かしさと、言葉にならない切なさが一溢れ出してきた。" +
				"[NEXT]" +
				"[NAME:NONE]あのアトリエで過ごした1年間。俺たちはプロとして互いを認め合っていたはずなのに、どこか一歩を踏み出せないまま終わってしまった。" +
				"[NEXT]" +
				"[NAME:PLAYER]（もしあの時、もっと俺が彼女の心に踏み込んでいたら……別の選択ができていたなら、今も隣にいられたのだろうか……）" +
				"[NEXT]" +
				"[NAME:NONE]そんな叶わない仮定が頭をよぎったその時、ブースの奥から人々に頭を下げながら説明をする、少し大人びた服装の女性が現れた。"
			);
			break;

		case 3: // 【転2】視線の交差
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgFes, "cross_fade", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]サユキだった。髪を少し後ろでまとめ、以前よりも凛とした表情で、ファンやパブリッシャーに対応している。" +
				"[NEXT]" +
				"[NAME:NONE]俺は思わずその姿を見つめ、立ち尽くしてしまっていた。" +
				"[NEXT]" +
				"[NAME:NONE]すると、サユキがふと視線を感じたのか、大勢の来場者の中から正確に俺のいる方向へと顔を向けた。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「……あっ！？」" +
				"[NEXT]" +
				"[NAME:NONE]視線がカチリと交差した瞬間、彼女は大きく目を見開き、手に持っていたチラシを落としそうになるほど硬直した。"
			);
			break;

		case 4: // 【転3】夕暮れの静けさの中で
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgSunset, "fade", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]――展示会場の喧騒から遠く離れた、ビルとビルの間にある夕暮れの連絡通路。" +
				"[NEXT]" +
				"[NAME:NONE]オレンジ色の夕日が差し込む静かな場所に、俺とサユキは並んで立っていた。お互いに言葉を探すように、数秒の沈黙が流れる。" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png][NAME:SAYUKI]「……お久しぶり、です。" + pName + "さん」" +
				"[NEXT]" +
				"[NAME:PLAYER]「久しぶり、サユキさん。……ブース、すごい人気だったね。ゲーム、本当に素晴らしかったよ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……ありがとうございます。でも、あなたにそう言われるの、なんだかすごく……緊張しますね」"
			);
			break;

		case 5: // 【転4】サユキの隠していた本音
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgSunset, "cross_fade", "close_up", "sunset"));
			data.setMessage(
				"[IMG:Sayuki_anxiety.png][NAME:SAYUKI]「あの後……あなたが機材を持ってオフィスを出て行ってから、部屋が信じられないくらい広く感じて」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「床を見るたびに、私たちが最初に引いた『境界線のテープ』の跡が薄く残っていて。それを見るたびに、私、ずっと胸がチクチク痛かったんです」" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png][NAME:SAYUKI]「どうして私は、最後まであんなに頑固だったんだろう。どうして、ただの『技術顧問』と『開発代表』の防壁（ライン）を張ったまま、終わらせちゃったんだろうって……」"
			);
			break;

		case 6: // 【転5】もしもあの時、別の選択ができたなら
			data.setMessage(
				"[IMG:Sayuki_anxiety.png][NAME:SAYUKI]「……もし、あの1年間の中で、私がもっと素直にあなたを頼れていたら」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「もしあの時……私が、別の選択をすることができていたなら……」" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png][NAME:SAYUKI]「今日、あのブースのステージで、私と一緒に笑って並んでいたのは、あなただったんじゃないかって……何度も、何度も、巻き戻せない時間をコンパイルし直しては、後悔してたんです」" +
				"[NEXT]" +
				"[NAME:NONE]夕日に照らされた彼女の瞳から、一筋の涙がポロポロとこぼれ落ちた。ハイライトの消えたその表情は、あまりにも切なく、俺の胸を締め付けた。"
			);
			break;

		case 7: // 【結1】現在の肯定
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgSunset, "cross_fade", "normal", "sunset"));
			data.setMessage(
				"[NAME:PLAYER]「サユキさん……。俺も、同じことを考えない日はなかったよ」" +
				"[NEXT]" +
				"[NAME:PLAYER]「でも、俺たちの選択は決して間違いじゃなかった。俺がいなくても、サユキさんはこうして自分の力で世界に誇れる最高のゲームを作り上げたんだから。俺は、それが心の底から嬉しい」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「……あ……」" +
				"[NEXT]" +
				"[NAME:NONE]俺が優しく語りかけると、サユキは驚いたように顔を上げ、涙の溜まった瞳でこちらをじっと見つめた。その瞳に、ゆっくりと光（ハイライト）が戻ってくる。"
			);
			break;

		case 8: // 【結2】まだ見ぬ明日へのリビルド
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgSunset, "cross_fade", "close_up", "sunset"));
			data.setMessage(
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……本当に、あなたって人は。いつも私の都合のいい言い訳（バグ）を、そうやって完璧に論破しちゃうんですね……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は涙を指先でそっと拭い、数年ぶりに、あの頃の頑固で、でも愛おしいサユキらしい微笑みを見せてくれた。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「……ねぇ、" + pName + "さん。過去のソースコード（選択）はもう書き換えられません。……でも」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「私の次のプロジェクト……アトリエの隣のデスクは、まだ空席（ヌル）のままなんです。……もし、もう一度私と、新しいゲームの設計から、始めてくれませんか？」"
			);
			break;

		case 9: // 【終】ギャラリーへ戻る
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgSunset, "fade", "normal", "sunset"));
			data.setMessage(
				"[NAME:PLAYER]「喜んで。今度はどんな無理難題（仕様）でも、完璧にビルドして見せるよ」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「ふふ、言いましたね？ さあ、私たちのこれからの物語を、もう一度ここからリビルド（再構築）しましょう！」" +
				"[NEXT]" +
				"[NAME:NONE]一度は離れた二人の境界線（ライン）が、夕暮れの街で再びカチリと繋がり合う。<br>" +
				"過去のすれ違いを越えて、俺たちの本当の共同制作は、ここから新しく始まっていくのだ。" +
				"[NEXT]" +
				"[NAME:SYSTEM] (Normal End 後日談 - 完)"
			);

			// 最終ページはボタンのテキストを「ギャラリーへ戻る」に変える
			data.setChoice1Text("ギャラリーへ戻る");
			data.setChoice2Text("ギャラリーへ戻る");
			data.setChoice3Text("ギャラリーへ戻る");
			break;
		}

		return data;
	}
}