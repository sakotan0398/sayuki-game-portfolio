package sayukiGame.model.bo.scnarioDataCommon;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;

public class Phase4 {

	public ScenarioData getScenario(int num, String pName) {
		ScenarioData data = new ScenarioData();
		data.setPoolType("Common");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 
		
		switch (num) {
		case 0: // 【ケース0：阿吽の呼吸と無言の要求】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]作業中、サユキが自分のデスク周りをキョロキョロと見回している。" +
				"[NEXT]" +
				"[NAME:PLAYER]（液タブ用の替え芯を探してるんだな。さっき、俺のデスクの方に転がってきたやつだ）" +
				"[NEXT]" +
				"[NAME:NONE]俺は何も言わず、キーボードを叩きながら片手で芯をつまみ、彼女の視界に差し出した。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……あっ」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ふふ。エスパーですか？ ちょうど今、それがないと作業が止まるところだったんです」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女は嬉しそうに芯を受け取った。こんなやり取りが、最近とても自然になっている）"
			);
			data.setChoice1Text("サユキさんのことなら何でもお見通しだよ");
			data.setChoice2Text("仕事仲間の行動パターンを学習しただけだよ");
			data.setChoice3Text("自分の道具くらい自分で管理しなよ");

			data.setRes1(
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……もう。すぐにそうやって調子に乗るんですから」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……でも。……ありがとうございます」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は少し顔を赤らめつつも、信頼しきった表情で作業に戻った。悪い気はしていないようだ。"
			);
			data.setC1Love(3); data.setC1Like(1); // 【Love寄り】

			data.setRes2(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……可愛くない言い方ですね。素直に『気づいてあげたよ』って言えばいいのに」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……でも、優秀な学習機能ですね。これからも技術顧問として、しっかり私をサポートしてくださいね？」" +
				"[NEXT]" +
				"[NAME:NONE]軽口を叩き合える、心地よい時間が流れた。"
			);
			data.setC2Love(1); data.setC2Like(4); // 【Like特化】理屈っぽい返しが刺さる

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。そうですね。人に頼った私が馬鹿でした。……すみません、以後気をつけます」" +
				"[NEXT]" +
				"[NAME:NONE]せっかくの通じ合った空気が、一瞬で冷え込んでしまった。小言を言うような距離感ではない。"
			);
			data.setC3Love(-3); data.setC3Like(-2); // 【大失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_jitome.png", bgDay, "cross_fade", "close_up", "day"));
			break;

		case 1: // 【ケース1：深夜の微熱と自販機】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]深夜。サユキが大きなモニターの前で、ふうっと深いため息をついた。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……あ。……" + pName + "さん、まだ起きてたんですね。……少し、外の空気吸いませんか？」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女から休憩に誘ってくるなんて珍しい。相当疲れているのか、それとも……）"
			);
			data.setChoice1Text("たまには自販機で温かいコーヒーでも買おうか");
			data.setChoice2Text("俺はまだ仕事中だから、後にしよう");
			data.setChoice3Text("サユキさんと夜風に当たりたいと思ってた");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。嬉しい……。貴方が選んでくれるコーヒー、ハズレがないから好きなんです」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……行きましょうか」" +
				"[NEXT]" +
				"[NAME:NONE]二人で廊下の自販機へ向かい、温かい缶コーヒーを分け合いながら、静かな夜の時間を共有した。"
			);
			data.setC1Love(2); data.setC1Like(3); // 【Like寄り】仕事の延長線上での気遣い

			data.setRes2(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……。そう、ですね。……すみません、邪魔しました。……進めます」" +
				"[NEXT]" +
				"[NAME:NONE]彼女はひどく寂しそうな顔をして、モニターに向き直った。冷たくしすぎた。"
			);
			data.setC2Love(-3); data.setC2Like(-1); // 【失敗】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！ 急に何を……っ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも、私も。……貴方が隣にいると、安心、します。……少しだけ、ですよ」" +
				"[NEXT]" +
				"[NAME:NONE]素直な彼女の言葉に、こちらの方が照れてしまった。夜の魔力が、二人の距離を確実に狂わせている。"
			);
			data.setC3Love(5); data.setC3Like(0); // 【Love最大】
			data.setRes3Visuals(new VisualBeans("Sayuki_mesorasi.png", bgNight, "cross_fade", "normal", "night"));
			break;

		case 2: // 【ケース2：終わりの予感とやりたいこと】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:SAYUKI]「……" + pName + "さん。このゲームが完成して、あなたの間借り期間も終わったら……」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「少しだけ、やりたいことリストを作ってみたんです。……見ますか？」" +
				"[NEXT]" +
				"[NAME:NONE]彼女が気恥ずかしそうに差し出してきたスマホのメモ帳には、気になるガジェット展や、少し遠くのカフェの名前が箇条書きにされていた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（これは、オフィスを出た後の『プライベートの約束』を取り付けようとしている……？）"
			);
			data.setChoice1Text("まずは目の前の完成に集中しよう");
			data.setChoice2Text("全部叶えよう。サユキさんのゲームを無事にリリースして");
			data.setChoice3Text("サユキさんの行きたい場所、俺も興味あるな");

			data.setRes1(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……分かってますよ。……ただ、少し先の楽しみを作っておきたかっただけです」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は少しシュンとして画面を消してしまった。正論が常に正しいとは限らない。"
			);
			data.setC1Love(-2); data.setC1Like(1); // 【Love減・Like微増】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「全部……！ ふふ。欲張りですね」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……でも、貴方となら、全部楽しめる気がします。……絶対、終わらせますから……約束ですよ？」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は満面の笑みで頷いた。未来を共有できる喜びと、プロとしての目標が重なり合った。"
			);
			data.setC2Love(4); data.setC2Like(3); // 【True寄り・大正解】

			data.setRes3(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「本当ですか？ じゃあ、次はこの展示会に行きましょう！ 絶対ですよ？」" +
				"[NEXT]" +
				"[NAME:NONE]クリエイター仲間として、感性を磨く約束を交わした。少し仕事仲間感が強いが、良い関係だ。"
			);
			data.setC3Love(1); data.setC3Like(4); // 【Like寄り】
			break;

		case 3: // 【ケース3：作業中の心地よい沈黙】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]夕方のアトリエには、俺のタイピング音と、サユキのペンタブの擦れる音だけが規則正しく響いている。" +
				"[NEXT]" +
				"[NAME:PLAYER]（……すごく集中できる。お互いの存在がノイズにならず、むしろペースメーカーになっている）" +
				"[NEXT]" +
				"[NAME:NONE]ふと息をついてサユキの方を見ると、彼女もペンを止めてこちらを見ていた。視線が、静かに絡み合う。"
			);
			data.setChoice1Text("（黙って、穏やかに頷き合う）");
			data.setChoice2Text("（小さく微笑みかける）");
			data.setChoice3Text("何？ 俺の顔にバグでも付いてる？");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……。……ふふ」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……よし。続き、やりましょうか」" +
				"[NEXT]" +
				"[NAME:NONE]言葉はなくても、今の自分たちが最高に噛み合っていることが分かった。成熟したプロ同士の沈黙だ。"
			);
			data.setC1Love(1); data.setC1Like(5); // 【Like最大】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……あ。……えへへ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:NONE]俺が微笑むと、彼女は照れくさそうに笑い返し、少しだけ頬を赤くしてペンを動かし始めた。甘い余韻が残る。"
			);
			data.setC2Love(5); data.setC2Like(0); // 【Love最大】

			data.setRes3(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……別に。……なんでもないです。自意識過剰ですね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は慌てて目を逸らした。せっかくの心地よい沈黙とムードを、自ら壊してしまった。"
			);
			data.setC3Love(-2); data.setC3Like(-1); // 【失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_dakara.png", bgSunset, "cross_fade", "normal", "sunset"));
			break;

		case 4: // 【ケース4：魂のビジュアルと最終確認】
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:SAYUKI]「" + pName + "さん。ここ、貴方の率直な意見が聞きたくて。……貴方がダメだと言ったら、構図から描き直します」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は、不安と期待が入り交じった、心底信頼しきった瞳で、描き上げたばかりのメインビジュアルを見せてきた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女にとっての『絵』は命そのものだ。それに意見を求めるということは、俺を完全に同格のパートナーとして認めている証拠だ）"
			);
			data.setChoice1Text("サユキさんの情熱、完璧に表現されてるよ");
			data.setChoice2Text("俺のプログラムもあるんだ、絶対に最高のものになる");
			data.setChoice3Text("ちょっとイメージと違うかも…");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……！ ありがとうございます。……よかった」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「貴方にそう言ってもらえるのが、今、一番ホッとします」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は安堵の深い溜息をつき、愛おしそうにモニターを見つめた。彼女の精神的な支柱になれている。"
			);
			data.setC1Love(5); data.setC1Like(2); // 【Love寄り】絶対的な肯定

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ふふ。言うようになりましたね、技術顧問さん」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「最高の相棒にそう言われたら、自信持てます！ さあ、私の絵に命を吹き込んでください！」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は気合を入れ直し、力強く笑った。クリエイターとしての最強の絆だ。"
			);
			data.setC2Love(2); data.setC2Like(5); // 【Like寄り】互いの技術の相乗効果

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。……どこがどう違うんですか。具体的な代替案も出せないなら、無責任なこと言わないでください」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は深く傷つき、同時に俺への信頼を無くしたようにレイヤーを閉じてしまった。"
			);
			data.setC3Love(-4); data.setC3Like(-4); // 【大失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_jitome.png", bgDay, "cross_fade", "close_up", "day"));
			break;
			
		case 5: // 【ケース5：突然の雨と狭い軒下】
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]サユキさんに連れられ周辺機器の買い出しの帰り道。突然のゲリラ豪雨に降られ、俺たちは慌てて狭いビルの軒下に駆け込んだ。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……最悪です。天気予報、晴れだったのに……っ」" +
				"[NEXT]" +
				"[NAME:PLAYER]（雨宿りをするには狭すぎるスペースだ。俺の肩と彼女の肩が、触れ合うほど密着している）" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……あの。……近いです。……それに、少し寒いです……」"
			);
			data.setChoice1Text("俺の上着、貸すよ。機材は俺が守るから");
			data.setChoice2Text("濡れて風邪引くよ。タクシー呼ぼうか");
			data.setChoice3Text("サユキさんと密着できて、雨も悪くないな");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「えっ……でも、それじゃあなたが……」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……。……ありがとうございます。流石、技術顧問ですね。……少しだけ、温かいです」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は俺の上着をぎゅっと握りしめた。トラブル時の的確な対応が、彼女の信頼をさらに深めた。"
			);
			data.setC1Love(1); data.setC1Like(4); // 【Like特化】頼れる男

			data.setRes2(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……。そうですね。……それが一番合理的です」" +
				"[NEXT]" +
				"[NAME:NONE]正論だが、どこか味気ない反応をされてしまった。雨の日の情緒は完全に消え去った。"
			);
			data.setC2Love(-1); data.setC2Like(1); // 【停滞】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！？ な、なな、何を言ってるんですか！？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……バカ。……セクハラで訴えますよ……っ。……でも……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は顔を背けたが、その耳は真っ赤に染まり、俺から離れようとはしなかった。"
			);
			data.setC3Love(5); data.setC3Like(-1); // 【Love最大】
			data.setRes3Visuals(new VisualBeans("Sayuki_mesorasi.png", bgSunset, "cross_fade", "close_up", "sunset"));
			break;

		case 6: // 【ケース6：共通の敵（バグ）への共闘】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]サユキのゲームで原因不明のフリーズバグが頻発し、二人とも疲労困憊の状態だ。" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……くっ。……まだ、終われません。……」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……" + pName + "さん、あなたの仕事は終わってるのに、ごめんなさい。……でも、もう一度だけ一緒にログを見てもらえますか？」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女がここまで弱音を吐いて頼ってくるのは珍しい。相当追い詰められている）"
			);
			data.setChoice1Text("サユキさんが一緒なら、いくらでも付き合うよ");
			data.setChoice2Text("当たり前だろ、技術顧問を頼ったからには直してやる");
			data.setChoice3Text("今日はもう限界だ。明日やろう");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……そういう甘い言葉は、バグを直してからにしてくださいっ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも。……ありがとうございます。貴方のその余裕に、いつも救われてます」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は優しい眼差しで微笑み、再び画面に向かった。"
			);
			data.setC1Love(4); data.setC1Like(1); // 【Love寄り】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「！ はい、お願いします！ 絶対に今日中にこのバグを倒しましょう、相棒！」" +
				"[NEXT]" +
				"[NAME:NONE]最高の戦友としての熱い連帯感が生まれた。絶対に直してやらなければ。"
			);
			data.setC2Love(1); data.setC2Like(5); // 【Like最大】

			data.setRes3(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……。……そうですね。……お疲れ様でした。あとは私一人でやります」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は寂しそうにログ画面に向き直った。絆が少し揺らいだ気がする。"
			);
			data.setC3Love(-3); data.setC3Like(-3); // 【大失敗】
			break;

		case 7: // 【ケース7：ささやかな差し入れと言い訳】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]コンビニに行った際、サユキが昨日『食べたい』と呟いていた限定の新作アイスを買ってきた。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「えっ……これ。私が昨日探してたやつ……！ 覚えててくれたんですか？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……あ、いえ。別にどうしても食べたかったわけじゃないですけど。……でも、買ってきてくれたなら、食べます」"
			);
			data.setChoice1Text("糖分補給して、効率上げてもらわないとね");
			data.setChoice2Text("俺も食べたかったから、半分こしようか");
			data.setChoice3Text("溶けちゃうから早く食べなよ");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……完全に餌付けされてる気分ですけど。……あなたのそういう合理的なところ、嫌いじゃないです」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……いただきます。……んっ、美味しい……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は嬉しそうに、でも少し遠慮がちにアイスを口に運んだ。良い気晴らしになったようだ。"
			);
			data.setC1Love(1); data.setC1Like(4); // 【Like寄り】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！ は、半分こって……！ スプーン一つしかないんですよ！？」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……か、間接キスとか、そういう破廉恥な真似は断固拒否します！ 食べたかったなら自分で買ってきてください！」" +
				"[NEXT]" +
				"[NAME:NONE]冗談のつもりだったが、彼女は真っ赤になって怒り出し、急いでアイスを独り占めしてしまった。"
			);
			data.setC2Love(4); data.setC2Like(-1); // 【Love最大】意識させて動揺を誘う

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……分かってますよ。……。……いただきます」" +
				"[NEXT]" +
				"[NAME:NONE]少し不満そうな顔をして、一人で食べ始めてしまった。少しムードに欠けたようだ。"
			);
			data.setC3Love(-1); data.setC3Like(0); // 【停滞】
			data.setRes3Visuals(new VisualBeans("Sayuki_jitome.png", bgDay, "cross_fade", "close_up", "day"));
			break;

		case 8: // 【ケース8：無防備な寝顔と上着】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]ふと隣を見ると、サユキが液タブに突っ伏したまま、静かな寝息を立てて眠りに落ちていた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（……限界だったんだな。無防備な寝顔は、普段の強気な彼女からは想像もつかないほど幼く見える）" +
				"[NEXT]" +
				"[NAME:PLAYER]（深夜のオフィスは冷える。……どうするべきか）"
			);
			data.setChoice1Text("（俺のジャケットを、そっと肩に掛ける）");
			data.setChoice2Text("（風邪を引く前に、声をかけて起こす）");
			data.setChoice3Text("（起こさないよう、静かに自分の作業を続ける）");

			data.setRes1(
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……んっ……」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……あったか、い……。……" + pName + "さん……ばか……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女はジャケットに顔を埋め、夢うつつに微笑んだ。俺への無意識の甘えが漏れ出ている。"
			);
			data.setC1Love(5); data.setC1Like(1); // 【Love最大】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……はっ！？ す、すみません！ 私、いつの間に……っ！」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……っ、寝顔、見ましたか！？ ……最悪です、もうお嫁に行けません……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は飛び起きて激しく動揺している。もう少し寝かせてあげても良かったかもしれない。"
			);
			data.setC2Love(-1); data.setC2Like(0); // 【失敗】

			data.setRes3(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……。……ん……。あ、おはよう、ございます……」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……ずっと、静かに作業しててくれたんですね。……起こさないでくれて、ありがとうございます」" +
				"[NEXT]" +
				"[NAME:NONE]しばらくして目が覚めた彼女は、タイピング音を抑えていた俺の配慮に気づき、安心したように微笑んだ。"
			);
			data.setC3Love(1); data.setC3Like(4); // 【Like寄り】
			break;

		default:
			return getScenario(0, pName);
		}
		return data;
	}
}