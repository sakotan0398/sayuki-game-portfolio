package sayukiGame.model.bo.scnarioDataCommon;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;

public class Phase5 {

	public ScenarioData getScenario(int num, String pName) {
		ScenarioData data = new ScenarioData();
		data.setPoolType("Common");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 
		
		switch (num) {
		case 0: // 【ケース0：静寂の熱狂（大一番の作業）】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]深夜のアトリエ。聞こえるのは、サユキの激しいペンさばきの音と、俺がコードを叩くキーボードの音だけだ。" +
				"[NEXT]" +
				"[NAME:PLAYER]（サユキさんのゲームの、一番重要なシーンの組み込み作業。……彼女の横顔には凄まじい気迫が漂っている）" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……あと少し。あと数枚描き上げれば、私の『最高』が完成します」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……" + pName + "さん。疲れましたか？ 嫌なら先に寝てもいいんですよ。これは私の戦いですから」"
			);
			data.setChoice1Text("サユキさんが描くなら、俺もコードを書くよ");
			data.setChoice2Text("俺がいないとバグが取れないだろ？");
			data.setChoice3Text("無理だ。今日はもう寝よう");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……あなたって、本当に頑固ですね」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……でも。隣に誰かいるだけで、こんなに筆が軽くなるなんて……思いませんでした。最後まで、付き合ってもらいますよ」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は不敵に微笑み、再びモニターに向き直った。心地よい共犯関係が、二人の作業速度を加速させる。"
			);
			data.setC1Love(3); data.setC1Like(4); // 【True寄り・大正解】

			data.setRes2(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……ふん。相変わらず自信満々ですね、技術顧問さん」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……まぁ、その通りですけど。あなたのロジックがないと、私の絵はただの絵のままです。……感謝、してますよ」" +
				"[NEXT]" +
				"[NAME:NONE]憎まれ口を叩きつつも、彼女は俺の技術を心から認めていた。Likeが大きく上昇する。"
			);
			data.setC2Love(1); data.setC2Like(5); // 【Like特化】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……今の私に、そんな余裕があると思いますか？ プロなら、止めるより背中を押してください」" +
				"[NEXT]" +
				"[NAME:NONE]彼女を怒らせてしまった。極限状態のクリエイターに、今の正論は毒でしかない。"
			);
			data.setC2Love(-2); data.setC2Like(-3); // 【失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_jitome.png", bgNight, "cross_fade", "close_up", "night"));
			break;

		case 1: // 【ケース1：全体像が見えたことによる不安】
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]夕暮れ。組み上がってきたゲームの全体像をテストプレイ中、サユキが突然ピタリと手を止めた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……ねぇ、" + pName + "さん」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……私のゲーム、本当に面白くなると思いますか？ 私の描いたこの世界は、誰かに届くんでしょうか……」" +
				"[NEXT]" +
				"[NAME:PLAYER]（形になってきたからこそ、彼女の中にプレッシャーが押し寄せてきているようだ）"
			);
			data.setChoice1Text("俺が保証する。最高に面白いよ");
			data.setChoice2Text("俺の技術サポートを疑ってるの？");
			data.setChoice3Text("出してみないと誰にも分からないよ");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……！ ……」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……あなたにそう言われるのが、一番……その、安心します。……ありがとうございます。私、信じてみます」" +
				"[NEXT]" +
				"[NAME:NONE]力強い言葉に、彼女の瞳に光が戻った。彼女にとって、俺はもう誰よりも信頼できる評価者なのだ。"
			);
			data.setC1Love(5); data.setC1Like(2); // 【Love最大】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ふふっ。相変わらず図々しいですね、あなたは」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「でも、確かに。あなたの最強のロジックが乗ってるんですものね。面白くないはずがありません」" +
				"[NEXT]" +
				"[NAME:NONE]冗談で彼女の緊張を解すことができた。プロ同士の、厚い信頼を感じる。"
			);
			data.setC2Love(2); data.setC2Like(4); // 【Like寄り】

			data.setRes3(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……。そんなこと、分かってます。私は、ただ……。……もういいです、忘れてください」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は再び殻に閉じこもってしまった。今の彼女が求めていたのは、現実ではなく『光』だった。"
			);
			data.setC3Love(-3); data.setC3Like(-1); // 【失敗】
			break;

		case 2: // 【ケース2：廊下の自販機、冷えた缶コーヒー】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]深夜、二人で廊下の自販機までコーヒーを買いに行った。" +
				"[NEXT]" +
				"[NAME:NONE]冷えた廊下に、ガタンという重い音が響く。サユキは受け取り口から缶を取り出すと、それを頬に当てた。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……冷たくて、気持ちいい。……頭が、煮えてたみたいです」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……もし、" + pName + "さんがこのオフィスに来ていなかったら……私は、とっくに一人で潰れていたかもしれません」"
			);
			data.setChoice1Text("俺も、サユキさんがいたから頑張れたんだ");
			data.setChoice2Text("俺をここに呼んだオーナーに感謝だね");
			data.setChoice3Text("そろそろ自炊とかも考えなよ？");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……ずるいです、そういうことさらっと言うの」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……。……私も、あなたが隣にいてくれて……よかったです。……。……さ、冷めないうちに作業戻りましょう」" +
				"[NEXT]" +
				"[NAME:NONE]薄暗い廊下で、彼女の顔が微かに赤らんでいるのが分かった。想いはもう、言葉にしなくても伝わりつつある。"
			);
			data.setC1Love(5); data.setC1Like(3); // 【True最大】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ふふ。そうですね。あの人の気まぐれに、初めて感謝するかもしれません」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「最高の『当たり』を引き当てた気分です」" +
				"[NEXT]" +
				"[NAME:NONE]和やかな雰囲気で、同居人としての絆を確認し合えた。"
			);
			data.setC2Love(1); data.setC2Like(4); // 【Like寄り】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。情緒の欠片もないですね、あなたは。……冷めました。一人で帰ります」" +
				"[NEXT]" +
				"[NAME:NONE]せっかくの告白に近い弱音を台無しにしてしまった。彼女の機嫌は氷点下まで逆戻りした。"
			);
			data.setC3Love(-4); data.setC3Like(-2); // 【失敗】
			break;

		case 3: // 【ケース3：心地よすぎる時間の不安】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]お互いに数時間の仮眠を取ることにした。サユキはソファー、俺は自分の椅子に深く体を預ける。" +
				"[NEXT]" +
				"[NAME:NONE]……ふと目が覚めると、サユキがソファーから起き上がり、俺のデスクの横に立っていた。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「あ……っ。お、起こしちゃいましたか？」" +
				"[NEXT]" +
				"[NAME:PLAYER]「いや、ちょうど目が覚めたところだよ。どうかした？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……いえ。あなたの寝顔を見ていたら……。なんだか、この毎日が心地よすぎて、夢みたいで……」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……いつか、ふっと消えてしまうんじゃないかって、変な不安になっちゃって」"
			);
			data.setChoice1Text("（黙って彼女の手を握る）");
			data.setChoice2Text("消えないよ。まだまだ作るものは山積みだろ？");
			data.setChoice3Text("幽霊じゃないんだから、消えないって");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「っ…………！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……。……温かい。……。……ずるい人。……もう少しだけ、このままでいさせてください……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の不安を溶かすように、俺は静かに手を握り続けた。もはや言葉は不要だった。"
			);
			data.setC1Love(6); data.setC1Like(0); // 【Love最大】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ふふ。そうでしたね。まだ、あなたにやってもらいたいデバッグ、山積みですから」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「勝手に消えるなんて、許可しませんよ。……さ、リブート完了です。続き、やりましょう！」" +
				"[NEXT]" +
				"[NAME:NONE]プロとしての絆を再確認し、彼女は元気に笑った。最高の仕事仲間だ。"
			);
			data.setC2Love(1); data.setC2Like(5); // 【Like最大】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……デリカシーの欠片もないですね。少しでも感傷的になった私が馬鹿でした」" +
				"[NEXT]" +
				"[NAME:NONE]冷たく突き放してしまった。彼女の繊細な心境を汲み取れなかった。"
			);
			data.setC3Love(-3); data.setC3Like(-1);
			break;

		case 4: // 【ケース4：栄養補給と、不器用な気遣い】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]作業が佳境に入り、まともな食事もとっていない俺のデスクに、サユキが無言でゼリー飲料と栄養剤を置いた。" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……勘違いしないでください。あなたが栄養失調で倒れたら、私のゲームのデバッグが止まって困るからです」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……これ、私が昨日買いすぎた予備の余りですから。……食べなさいよ」"
			);
			data.setChoice1Text("ありがとう。一段落したら、美味しい店連れて行くよ");
			data.setChoice2Text("流石管理人さん、リソース管理が完璧だね");
			data.setChoice3Text("ゼリーより、肉が食べたいな");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！？ お、お返しなんていりません！ ……。……でも、まぁ、美味しいお店、には興味ありますけど……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は照れながらも、嬉しそうに頷いた。先の約束が、互いの原動力になる。"
			);
			data.setC1Love(4); data.setC1Like(2); // 【Love寄り】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「当然です。クリエイターもエンジニアも、体が資本のリソースなんですから」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……あなたも、自分の管理くらいしっかりしてくださいね。私がいないとダメなんですから」" +
				"[NEXT]" +
				"[NAME:NONE]プロとしての気遣いを認められ、彼女はどこか誇らしげだった。"
			);
			data.setC2Love(1); data.setC2Like(4); // 【Like寄り】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……強欲ですね。じゃあ今すぐ返してください。全部自分で飲みますから」" +
				"[NEXT]" +
				"[NAME:NONE]せっかくの好意を台無しにしてしまった。彼女の優しさを軽く扱いすぎた。"
			);
			data.setC3Love(-3); data.setC3Like(-2);
			break;

		case 5: // 【ケース5：無言の紙飛行機（極限状態の絆）】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]午前4時。連日の徹夜に近い作業で、お互いに口を開く気力すらなくなっていた、その時。" +
				"[NEXT]" +
				"[NAME:NONE]……ふわりと、不恰好な紙飛行機が俺のキーボードの上に落ちてきた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（サユキさんの方を見ると、彼女はモニターで顔を隠すように俯いている）" +
				"[NEXT]" +
				"[NAME:NONE]紙飛行機を開くと、震えるような手書きの文字で『あと少し。……死なないでくださいね、相棒』と書かれていた。"
			);
			data.setChoice1Text("『そっちこそ』と書いて投げ返す");
			data.setChoice2Text("『サユキさんのためなら』と書いて投げ返す");
			data.setChoice3Text("「ゴミを投げないで」と口に出して言う");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:NONE]俺が投げ返した紙を見たサユキは、小さく吹き出した後、大切そうにその紙をポケットにしまった。" +
				"[NEXT]" +
				"[NAME:NONE]極限状態の疲労の中、声に出さない励まし合いが、最後の気力を振り絞らせてくれる。"
			);
			data.setC1Love(2); data.setC1Like(5); // 【Like最大】最高の相棒

			data.setRes2(
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:NONE]俺が投げ返した紙を見たサユキは、ビクッと肩を震わせ、耳まで真っ赤にしてこちらを睨みつけてきた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……っ。……バカ。……重すぎます……」" +
				"[NEXT]" +
				"[NAME:NONE]声に出さずに口パクで文句を言われたが、彼女の表情はどこか嬉しそうだった。"
			);
			data.setC2Love(5); data.setC2Like(1); // 【Love最大】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。……最低」" +
				"[NEXT]" +
				"[NAME:NONE]氷のように冷たい声が響いた。せっかくの彼女の不器用な気遣いを、最悪の形で踏みにじってしまった。"
			);
			data.setC3Love(-5); data.setC3Like(-5); // 【大失敗】取り返しがつかない
			data.setRes3Visuals(new VisualBeans("Sayuki_jitome.png", bgNight, "cross_fade", "close_up", "night"));
			break;

		case 6: // 【ケース6：スタッフロールの特等席】
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]ある日のテストプレイ。エンディング画面まで到達し、スタッフロールが流れ始めた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（……ん？ 今、俺の名前が……）" +
				"[NEXT]" +
				"[NAME:NONE]『Technical Advisor : " + pName + "』。そこには、俺の名前がしっかりと刻まれていた。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……勝手に入れました。……文句、ありますか？」"
			);
			data.setChoice1Text("光栄だよ。最高のポジションだ");
			data.setChoice2Text("俺の特等席だね。すごく嬉しい");
			data.setChoice3Text("もっと目立つ場所に書いてよ");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……当然です。あなたの技術がなければ、ここまで来れませんでしたから」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……いつもサポートしてくれて……ありがとうございます」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は誇らしげに胸を張った。お互いのプロフェッショナルとしての仕事が結実しつつある瞬間だ。"
			);
			data.setC1Love(1); data.setC1Like(4); // 【Like寄り】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……特等席って。……」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも、そうですね。……私の作品に、あなたの名前が刻まれてるの……悪くないです」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は顔を赤らめ、スクロールしていく俺の名前を愛おしそうに見つめていた。"
			);
			data.setC2Love(4); data.setC2Like(2); // 【Love寄り】

			data.setRes3(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……は？ どこまで強欲なんですか。私の作品ですよ？ 消してやろうかな」" +
				"[NEXT]" +
				"[NAME:NONE]呆れられてしまった。素直に感謝を伝えるべきだった。"
			);
			data.setC3Love(-2); data.setC3Like(-2); // 【失敗】
			break;

		case 7: // 【ケース7：一段落と機材の整理】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]大きな機能の実装がひと段落つき、俺はデスクに広げっぱなしだった機材や参考書を整理し始めていた。" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……何、してるんですか」" +
				"[NEXT]" +
				"[NAME:NONE]俺が片付ける様子を、サユキがひどく不機嫌そうな、不安そうな目で睨みつけていた。"
			);
			data.setChoice1Text("一段落したから、少し整理しようと思って");
			data.setChoice2Text("……もう少し、広げたままでもいいかな？");
			data.setChoice3Text("そろそろ俺の手伝いも不要でしょ");

			data.setRes1(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……そうですか。合理的ですね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は冷たく言い捨て、画面に向き直った。少しドライすぎたかもしれない。"
			);
			data.setC1Love(-1); data.setC1Like(1); // 【Like微増・Love減】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……はい」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……まだ、バグが出るかもしれませんから。……あなたの機材がないと、困るんです。……だから、そのままにしておいてください」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は言い訳を並べながら、俺が片付けるのを引き止めた。片付けられる＝手伝いが終わる、という焦りがあったようだ。"
			);
			data.setC2Love(5); data.setC2Like(2); // 【Love最大】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。そうですか。じゃあさっさと全部片付けてください」" +
				"[NEXT]" +
				"[NAME:NONE]完全に怒らせてしまった。彼女の繊細な心を逆撫でしてしまった。"
			);
			data.setC3Love(-3); data.setC3Like(-2); // 【失敗】
			break;

		case 8: // 【ケース8：大きなマイルストーンの達成】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]朝6時。……ついに、ゲームの根幹となる一番重いシステムの統合が完了した。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……終わっ、た……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は脱力して椅子に深くもたれかかり、窓の外の白み始めた空を見つめた。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……" + pName + "さん。……これで、一番大きな山は越えられましたね」"
			);
			data.setChoice1Text("最高のシステムになったね。お疲れ様");
			data.setChoice2Text("俺が手伝う大仕事も、これで一段落だね");
			data.setChoice3Text("これで心置きなく寝られるな");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……はい。……本当に、ありがとうございました。あなたのおかげです」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:NONE]彼女は清々しい笑顔を向けた。一つの大きな仕事を成し遂げた、プロとしての完全な達成感だ。"
			);
			data.setC1Love(1); data.setC1Like(5); // 【Like最大】プロの締めくくり

			data.setRes2(
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……っ。……」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……そう、ですね。……でも。……私は、もう少しだけ、あなたの助けが……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は言葉を詰まらせ、俺の服の袖を弱々しく掴んだ。朝焼けの中、二人の関係は確実な変化を見せている。"
			);
			data.setC2Love(5); data.setC2Like(0); // 【Love最大】切なさを引き出す

			data.setRes3(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……情緒がないですね。……まあいいです、お疲れ様でした」" +
				"[NEXT]" +
				"[NAME:NONE]感動の瞬間を台無しにしてしまった。彼女は呆れたように目を閉じた。"
			);
			data.setC3Love(-2); data.setC3Like(-1); // 【失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_dakara.png", bgNight, "cross_fade", "normal", "night"));
			break;

		default:
		}
		return data;
	}
}