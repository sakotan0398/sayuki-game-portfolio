package sayukiGame.model.bo.scnarioDataTrue;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;
import sayukiGame.model.bo.scnarioDataCommon.Phase4;

public class TruePhase4 extends Phase4 {

	@Override
	public ScenarioData getScenario(int num, String pName) {
		
		// 0〜8 が選ばれた場合は、親クラス（Common）の共通の日常会話を呼び出す
		if (num <= 8) {
			return super.getScenario(num, pName);
		}

		// 9〜14：Trueルート専用（プロとしての絶対的信頼と、隠しきれない独占欲の葛藤）
		ScenarioData data = new ScenarioData();
		data.setPoolType("True");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 
		
		switch (num) {
		case 9: // 【ケース9：限界を超えたシンクロ】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]作業中、俺のタイピングの手がピタリと止まった。少し思考を整理したかったのだ。" +
				"[NEXT]" +
				"[NAME:NONE]すると、全くこちらを見ていなかったはずのサユキが、スッと微糖のコーヒーを俺のデスクに置いた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（……俺も無言で、彼女のペンの動きが止まった瞬間に、いつも彼女が使っている目薬を差し出す）" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……あ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……私たち。ちょっと気持ち悪いくらい、息が合ってますね。……背中に目でも付いてるんですか？」"
			);
			data.setChoice1Text("作業効率が最高だね。助かるよ");
			data.setChoice2Text("俺の思考、読まないでよ");
			data.setChoice3Text("……ずっと、このままでいたいな");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ええ。お互いの思考の波長が同期してるみたいで。……悪くないです」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は満足げにコーヒーを飲み、作業に戻った。最強のバディとしての関係だ。"
			);
			data.setC1Love(1); data.setC1Like(4); // 【Like特化】

			data.setRes2(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……せっかく気を利かせてあげたのに。気持ち悪いならもうしません」" +
				"[NEXT]" +
				"[NAME:NONE]冗談のつもりだったが、彼女をムッとさせてしまった。"
			);
			data.setC2Love(-2); data.setC2Like(-2); // 【失敗】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……バカ。……そういうのは、仕事が全部終わってから言ってください……っ」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は顔を真っ赤にして、目薬で顔を隠した。仕事のパートナーを超えた、特別な感情が溢れ出ている。"
			);
			data.setC3Love(5); data.setC3Like(4); // 【True最大】
			break;

		case 10: // 【ケース10：作品への介在と、独占欲】
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]サユキが、外部ツールを使った画像の一括処理に苦戦し、頭を抱えていた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女の手作業を減らすために、俺が裏でこっそり組んでいた専用の自動化スクリプト。……渡すなら今か）" +
				"[NEXT]" +
				"[NAME:NONE]俺がそのスクリプトを彼女のPCに転送し、使い方を教えると、数時間かかるはずだった作業が数秒で終わってしまった。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……えっ。……これ、わざわざ私のために、組んでくれてたんですか……？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……私の作品なのに。……あなたがいなきゃ、私のしたい表現が完成しないなんて。……ずるいです」"
			);
			data.setChoice1Text("ツールは自由に使ってよ。役に立ってよかった");
			data.setChoice2Text("俺がずっと、サユキさんを技術で支えるよ");
			data.setChoice3Text("二人で、一つの作品を作ってるみたいだね");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……はい。ありがとうございます。これなら、もっと描くことに集中できます」" +
				"[NEXT]" +
				"[NAME:NONE]彼女はスクリプトのコードを興味深そうに眺めている。技術的なサポートとしては完璧だ。"
			);
			data.setC1Love(1); data.setC1Like(4); // 【Like特化】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……ずっとって。……あ、あなたが勝手に支えたいなら、止めはしませんけど……っ」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は分かりやすく動揺し、顔を赤らめた。恋愛的なアプローチとしては成功だ。"
			);
			data.setC2Love(4); data.setC2Like(1); // 【Love特化】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……そう、ですね。私の絵と、あなたのコード。……もう、私一人だけの作品じゃないのかも、しれません」" +
				"[NEXT]" +
				"[NAME:NONE]彼女はとても優しく、愛おしそうにモニターを撫でた。クリエイターとしての魂が交わった瞬間だった。"
			);
			data.setC3Love(4); data.setC3Like(5); // 【True最大】作品の共有
			data.setRes3Visuals(new VisualBeans("Sayuki_nomal.png", bgNight, "cross_fade", "normal", "night"));
			break;

		case 11: // 【ケース11：一つの折り畳み傘と距離】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]買い出しの帰り道。突然の雨に降られたが、持っていたのは俺の小さな折り畳み傘だけだった。" +
				"[NEXT]" +
				"[NAME:PLAYER]（サユキさんが濡れないように、なるべく彼女の方へ傘を傾けて歩く）" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……" + pName + "さん。……右肩、濡れてますよ。もっと、こっちに入ってください」" +
				"[NEXT]" +
				"[NAME:NONE]彼女が俺の腕を軽く引き寄せた。雨音のせいで、二人の距離が普段よりもずっと近い。"
			);
			data.setChoice1Text("サユキさんが濡れないなら、俺はいいよ");
			data.setChoice2Text("これ以上近づいたら、歩きにくいよ");
			data.setChoice3Text("……もう少しだけ、ゆっくり歩こうか");

			data.setRes1(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……バカ。あなたが風邪を引いたら、私のゲームの開発が遅れるじゃないですか。……ほら、もっと寄って」" +
				"[NEXT]" +
				"[NAME:NONE]理屈を並べながらも、彼女は俺の腕にギュッと身を寄せた。体温が伝わってくる。"
			);
			data.setC1Love(5); data.setC1Like(0); // 【Love最大】

			data.setRes2(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。そうですか。じゃあ私が濡れて帰りますから、あなたは一人でさしててください」" +
				"[NEXT]" +
				"[NAME:NONE]彼女を怒らせてしまった。せっかくの雨のムードが台無しだ。"
			);
			data.setC2Love(-3); data.setC2Like(-2); // 【大失敗】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……雨、降ってるのにですか？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……。……変な人。……でも。……まあ、いいですよ。……少しだけなら」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の顔は雨空の下でも分かるほど赤かった。一つの傘の下、俺たちは足並みを揃えてゆっくりと歩いた。"
			);
			data.setC3Love(5); data.setC3Like(4); // 【True最大】
			data.setRes3Visuals(new VisualBeans("Sayuki_mesorasi.png", bgSunset, "cross_fade", "close_up", "sunset"));
			break;

		case 12: // 【ケース12：消えた境界線の確認】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]俺のデスクとサユキのデスク。かつては明確に分かれていたはずの二人の領域は、今や機材や資料が入り乱れ、完全に混ざり合っている。" +
				"[NEXT]" +
				"[NAME:NONE]資料を取ろうとして手が触れ合っても、もうお互いに驚いて手を引くようなことはなくなっていた。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……ねぇ。" + pName + "さん」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……私たちが初めて会った日みたいに。テープで境界線、引き直しますか？」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女は少し悪戯っぽく、それでいてこちらの本心を試すような瞳で俺を見ていた）"
			);
			data.setChoice1Text("もういらないでしょ。今のままでいい");
			data.setChoice2Text("そうだね、少し散らかってきたし整理しよう");
			data.setChoice3Text("引いてもいいよ。でも、俺は越えるけどね");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……そう、ですね。いちいち領域を気にしてたら、作業効率が落ちますから。合理的です」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は満足そうに頷いた。仕事仲間としての完全な信頼の証だ。"
			);
			data.setC1Love(2); data.setC1Like(4); // 【Like寄り】

			data.setRes2(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……。……そうですね。整理整頓は基本です」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は明らかに少し傷ついた顔をして、自分の資料を引き寄せた。試されていたのに、間違えたようだ。"
			);
			data.setC2Love(-4); data.setC2Like(-1); // 【失敗】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！ ～～っ！」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……バカ。……ルールを破る宣言をする人間と、契約なんて結べません。……線なんか、引きませんよ」" +
				"[NEXT]" +
				"[NAME:NONE]顔を真っ赤にして怒ったが、その表情には隠しきれない喜びが滲んでいた。心の境界線は、とうに消え去っている。"
			);
			data.setC3Love(5); data.setC3Like(3); // 【True最大】
			break;

		case 13: // 【ケース13：徹夜明けの静寂と、肩の微睡み】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]空が白み始めた朝焼けのアトリエ。数日に及んだ重いデバッグ作業が、ようやく全て完了した。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……終わっ、た……」" +
				"[NEXT]" +
				"[NAME:NONE]サユキが椅子にもたれかかり、深く息を吐く。……と、彼女のキャスター付きの椅子が、ゆっくりとこちらへ滑ってきた。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……ねぇ。" + pName + "さん」" +
				"[NEXT]" +
				"[NAME:NONE]コツン、と。彼女が『自分から』、俺の肩に頭を預けてきた。シャンプーの甘い香りと、温かい体温が伝わってくる。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……５分だけ。このまま、充電させてください……」"
			);
			data.setChoice1Text("お疲れ様。よく頑張ったね");
			data.setChoice2Text("５分と言わず、ずっとこのままでもいいよ");
			data.setChoice3Text("（何も言わず、少しだけ頭を傾けて寄り添う）");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……はい。あなたが一緒に戦ってくれたおかげです……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は目を閉じたまま、穏やかな声で呟いた。戦友としての確かな絆を感じる。"
			);
			data.setC1Love(2); data.setC1Like(5); // 【Like最大】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……バカ。そんなこと言って、私が本気にしたらどうするんですか……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の肩が微かに震えた。疲労のせいか、それとも感情の高ぶりのせいか。"
			);
			data.setC2Love(5); data.setC2Like(1); // 【Love最大】

			data.setRes3(
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……んっ……」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……あったかい。……あなたの体温、すごく、安心します……」" +
				"[NEXT]" +
				"[NAME:NONE]余計な言葉はいらなかった。朝焼けの光の中、二人の呼吸の音だけが、静かに重なり合っていた。"
			);
			data.setC3Love(5); data.setC3Like(5); // 【True最大】言葉のない究極の肯定
			break;

		case 14: // 【ケース14：ノイズのない世界と、無言の引き留め】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]深夜のアトリエ。俺が自分の案件を終え、PCをシャットダウンして立ち上がろうとした時のこと。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……もう、終わったんですか？」" +
				"[NEXT]" +
				"[NAME:PLAYER]「ああ、今日の分はキリがいいからね。おやすみ」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……。……あの。もう少しだけ、そこにいてくれませんか」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……あなたのキーボードの音がないと、静かすぎて……集中できないんです」" +
				"[NEXT]" +
				"[NAME:PLAYER]（かつて『騒音』と呼んでいた俺のタイピング音を、彼女は今、不器用な引き留めの口実にしている）"
			);
			data.setChoice1Text("分かった。じゃあ明日の分のコードでも組むよ");
			data.setChoice2Text("俺がいないと寂しいんだね");
			data.setChoice3Text("疲れてるみたいだし、サユキさんも休んだら？");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！ ……いいんですか？」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ありがとうございます。……もう少しだけ、この音、聞かせてください」" +
				"[NEXT]" +
				"[NAME:NONE]俺が再び席に座りキーボードを叩き始めると、彼女は深く安心したように息を吐き、ペンを走らせ始めた。静かな夜に、二人の作業音だけが心地よく重なり合う。"
			);
			data.setC1Love(5); data.setC1Like(5); // 【True最大】言葉を超えた安心感の提供

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！ さ、寂しくなんかないです！ ただの環境BGMの話をしてるんです！」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……もういいです。さっさと寝てください。……バカ」" +
				"[NEXT]" +
				"[NAME:NONE]真っ赤になって怒られてしまったが、彼女の視線は俺の背中を名残惜しそうに追っていた。"
			);
			data.setC2Love(4); data.setC2Like(0); // 【Love寄り】照れ隠しを発動させる

			data.setRes3(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……そう、ですね。……少し、効率が落ちてきてる気がします」" +
				"[NEXT]" +
				"[NAME:NONE]彼女も素直にPCの電源を落とした。プロとしては正しい判断だが、少しだけ寂しそうな横顔だった。"
			);
			data.setC3Love(1); data.setC3Like(3); // 【Like寄り】実務的な判断
			data.setRes3Visuals(new VisualBeans("Sayuki_nomal.png", bgNight, "cross_fade", "normal", "night"));
			break;

		default:
			return super.getScenario(0, pName);
		}
		return data;
	}
}