package sayukiGame.model.bo.scnarioDataBonus;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;

public class Bonus_True {

	public ScenarioData getScenario(int step, String pName) {
		ScenarioData data = new ScenarioData();
		data.setPoolType("Bonus");

		// 後日談は選択肢なしの一本道で進める
		data.setChoice1Text("続きを読む ▼");
		data.setChoice2Text("続きを読む ▼");
		data.setChoice3Text("続きを読む ▼");
		data.setRes1(""); data.setRes2(""); data.setRes3("");

		String bgOffice = "bg011n19201440.jpg"; 
		String bgOfficeSunset = "bg011n19201440.jpg";

		switch (step) {
		case 0: // 【起】新しいオフィスと成功
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgOffice, "fade", "normal", "day"));
			data.setMessage(
				"【👑 True End 後日談：境界線のない特等席】<br><br>" +
				"[NEXT]" +
				"[NAME:NONE]都内の一等地に構えた、真新しいオフィス。<br>" +
				"俺とサユキが立ち上げたインディーゲームスタジオは、初タイトルの爆発的な大ヒットにより、今や業界の注目の的となっていた。" +
				"[NEXT]" +
				"[NAME:NONE]広い社長室の奥。デュアルモニターが並ぶ高級なデスクで、サユキは今日も真剣な眼差しでペンタブを走らせている。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「……うーん、ここのライティング、もう少しパーティクルを散らした方がエモいですかね？ どう思います、" + pName + "さん」" +
				"[NEXT]" +
				"[NAME:PLAYER]「処理落ちしない範囲ならいけると思う。あとで俺の方でレンダリングの最適化コードを組んでおくよ」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「さすが私の専属エンジニア。頼りにしてます」"
			);
			break;

		case 1: // 【承】社長とエンジニアのじゃれ合い
			data.setMessage(
				"[NAME:NONE]俺は立ち上がり、給湯室で淹れたばかりのコーヒーが入ったマグカップを彼女のデスクに置いた。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「あ……ありがとうございます。ふぅ……」" +
				"[NEXT]" +
				"[NAME:NONE]サユキはペンを置き、コーヒーの香りを深く吸い込んで、ふにゃっと表情を緩ませた。" +
				"[NEXT]" +
				"[NAME:PLAYER]「お疲れ様、サユキ社長」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png][NAME:SAYUKI]「もう、二人きりの時に『社長』って呼んでからかうの、やめてくださいってば！ 私は絵を描くことしかできないんですから」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「あなたが隣で、世界一のコードを書いてくれないと……うちの会社、明日にはバグだらけで倒産しちゃいますよ」"
			);
			break;

		case 2: // 【転1】物理的な甘え
			data.setVisuals(new VisualBeans("Sayuki_mesorasi.png", bgOffice, "cross_fade", "close_up", "day"));
			data.setMessage(
				"[NAME:NONE]サユキはキャスター付きの椅子をカラカラと滑らせて俺の隣まで来ると、俺の腕に自分の腕を回し、肩にコツンと頭を預けてきた。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「……こうやって、あなたの体温を感じて充電するのが、一番手っ取り早いんです。……えへへ」" +
				"[NEXT]" +
				"[NAME:PLAYER]「社長室でこんなことしてるって、他の社員にバレたらどうするんだよ」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png][NAME:SAYUKI]「別にいいじゃないですか。私たちが公私ともにパートナーだって、会社のみんなも知ってるんですから」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「それに……バレたって、私は一向に構いませんけど。……あなたは、嫌、ですか？」" +
				"[NEXT]" +
				"[NAME:NONE]上目遣いで覗き込んでくる彼女の瞳には、昔のようなツンケンした防壁は欠片も残っていない。"
			);
			break;

		case 3: // 【転2】境界線のテープの思い出
			data.setMessage(
				"[NAME:PLAYER]「嫌なわけないだろ。ただ、昔のサユキを思い出すと、信じられないくらい甘えん坊になったなって思って」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「っ！ ～～～っ、そ、それは……！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……昔は、すみませんでした。あの狭かったオフィスで、絶対に踏み越えちゃいけない『境界線のテープ』なんて引いて……」" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png][NAME:SAYUKI]「あの頃は、怖かったんです。誰かと一緒に作って、自分の作品が自分のものじゃなくなっちゃう気がして。……傷つくのが、怖くて」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「でも、あなたがその線を、無理やりじゃなく……本当に少しずつ、優しく溶かしてくれたから」"
			);
			break;

		case 4: // 【転3】今の素直な気持ち
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgOfficeSunset, "fade", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]窓の外の空が、少しずつオレンジ色に染まり始めていた。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「……いつの間にか、あなたのキーボードを叩くタイピング音が、私にとってのメトロノームになってました」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「今じゃもう……あなたの隣じゃないと、まともに息もできないくらい、依存しちゃってます。……責任、とってくださいね？」" +
				"[NEXT]" +
				"[NAME:PLAYER]「とっくに取ってるよ。あのエンディングの日に、一生の専属になるって約束しただろ」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「っ！ だ、だからそういうこと、涼しい顔で言わないでください……っ、顔、熱い……っ」"
			);
			break;

		case 5: // 【転4】ブラインドを下ろして
			data.setVisuals(new VisualBeans("Sayuki_mesorasi.png", bgOfficeSunset, "cross_fade", "close_up", "sunset"));
			data.setMessage(
				"[NAME:NONE]顔を真っ赤にした彼女は、突然立ち上がると、社長室のガラス張りのブラインドをシャッと下ろした。" +
				"[NEXT]" +
				"[NAME:PLAYER]「サユキ？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……うるさい。ちょっと、黙っててください」" +
				"[NEXT]" +
				"[NAME:NONE]振り返った彼女は、俺の首に腕を回すと、そのまま俺の膝の上にコロンと座り込んできた。"
			);
			break;

		case 6: // 【結1】特等席でのキス
			data.setMessage(
				"[NAME:NONE]夕日に照らされた彼女の顔が、ゆっくりと近づいてくる。" +
				"[NEXT]" +
				"[NAME:NONE]そして――ちゅ、と。触れるだけの、柔らかくて甘いキスを落とした。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……これは、いつも完璧なコードを書いてくれるお礼、です。……」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「……あの頃の境界線は、もうどこにもありません。だから……」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……もう一回、しても……いい、ですか？」"
			);
			break;

		case 7: // 【結2】深い愛の確認
			data.setMessage(
				"[NAME:NONE]俺が静かに頷くと、彼女は嬉しそうに微笑み、今度はさっきよりも少しだけ長く、深いキスをした。" +
				"[NEXT]" +
				"[NAME:NONE]コーヒーのほろ苦い香りと、彼女の甘いシャンプーの匂いが混ざり合う。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「……えへへ。……" + pName + "さん、大好きです。世界中の誰よりも」" +
				"[NEXT]" +
				"[NAME:PLAYER]「俺もだよ。これからもよろしくな、サユキ」"
			);
			break;

		case 8: // 【結3】未来へ向けて
			data.setMessage(
				"[IMG:Sayuki_dakara.png][NAME:SAYUKI]「はいっ！ ……でも、イチャイチャするのはここまでです。まだ今日のタスク、終わってませんからね！」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は俺の膝から降りると、パチンと両頬を叩いて気合を入れ直し、再び自分のデスクへと向かった。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「これからもずっと、この世界で一番の『特等席（あなたの隣）』は、私だけのものですからね」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「さあ、相棒！ 私たちの次のゲームで、また世界を驚かせてやりましょう！」"
			);
			break;

		case 9: // 【終】ギャラリーへ戻る
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgOfficeSunset, "fade", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]二人のクリエイターが描く物語は、まだ始まったばかりだ。<br>" +
				"境界線のないこの場所で、俺たちはこれからも最高のゲームを作り続けていく。" +
				"[NEXT]" +
				"[NAME:SYSTEM]（True End 後日談 - 完）"
			);
			
			// 🌟 最終ページはボタンのテキストを変える
			data.setChoice1Text("ギャラリーへ戻る");
			data.setChoice2Text("ギャラリーへ戻る");
			data.setChoice3Text("ギャラリーへ戻る");
			break;
		}

		return data;
	}
}