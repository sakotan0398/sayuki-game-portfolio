package sayukiGame.model.bo.scnarioDataLike;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;
import sayukiGame.model.bo.scnarioDataCommon.Phase3;

public class LikePhase3 extends Phase3 {

	@Override
	public ScenarioData getScenario(int num, String pName) {
		
		// 0〜8 が選ばれた場合は、親クラス（Common）の共通の日常会話をそのまま呼び出す
		if (num <= 8) {
			return super.getScenario(num, pName);
		}

		// 9〜14：Likeルート専用（有能な助っ人・技術顧問としての信頼）
		ScenarioData data = new ScenarioData();
		data.setPoolType("Like");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 
		switch (num) {
		case 9: // 【ケース9：徹夜明けの手伝い】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]朝日が差し込むオフィス。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……エンター、ッターン！！」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……よしっ！ 動いた！ エラー、全部吐き出さなくなりました！」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……" + pName + "さん、私の作品のデバッグに夜通し付き合ってもらって、すみません。助かりました」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女の顔には疲労よりも達成感が勝っている。手伝った甲斐があった）"
			);
			data.setChoice1Text("やっとか……限界だ、寝る");
			data.setChoice2Text("（無言で軽く拳を突き出す）");
			data.setChoice3Text("お疲れ様！（ポンッと肩を叩く）");

			data.setRes1(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……あ、そうですよね。本業があるのに無茶させちゃって……。……お疲れ様でした」" +
				"[NEXT]" +
				"[NAME:NONE]手伝った恩は売れたが、少し申し訳なさそうにさせてしまった。"
			);
			data.setC1Love(0); data.setC1Like(-1);

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！ ふふっ、はい」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:NONE]コツン、と彼女は自分の拳をこちらの拳に軽く当てた。有能な助っ人としてのささやかな絆を感じた。"
			);
			data.setC2Love(1); data.setC2Like(4); // 【Like特化】過度なスキンシップを避けるのが正解

			data.setRes3(
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「っ！？ ……あ、ありがとうございます。その、" + pName + "さんも、お疲れ様でした……」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:NONE]肩に触れると、彼女はビクッとして体を引いた。徹夜のノリとはいえ、不用意なスキンシップは警戒されるようだ。"
			);
			data.setC3Love(2); data.setC3Like(-2); // 【Loveは上がるがLikeは下がる】
			data.setRes3Visuals(new VisualBeans("Sayuki_mesorasi.png", bgDay, "cross_fade", "normal", "day"));
			break;

		case 10: // 【ケース10：アイデアの壁打ち相手】
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]サユキが頭を抱えながら、画面と睨めっこしている。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……うーん。このメニュー画面の遷移、どうしてもテンポが悪い……。ユーザー体験として致命的です」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女はデザインの天才だが、システム的な導線の構築に苦戦しているようだ）" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「あの、" + pName + "さん。プログラマーの視点から見て、この導線どう思いますか？」"
			);
			data.setChoice1Text("悩んでる顔も可愛いね");
			data.setChoice2Text("俺は自分の仕事で忙しいから");
			data.setChoice3Text("ロジックの観点から仕様を整理しようか");

			data.setRes1(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……は？ 今、本気で悩んでるんですけど。ふざけないでください」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「可愛いとかそういう評価は求めてません。役に立たないなら黙っててください」" +
				"[NEXT]" +
				"[NAME:NONE]クリエイターとしての真剣な相談を茶化したことで、激しく軽蔑されてしまった。"
			);
			data.setC1Love(-2); data.setC1Like(-4); // 【大失敗】

			data.setRes2(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……まぁ、そうですよね。あなたの本業じゃないですし。邪魔してすみませんでした」" +
				"[NEXT]" +
				"[NAME:NONE]突き放したことで、彼女は一人で抱え込んでしまった。"
			);
			data.setC2Love(-1); data.setC2Like(-2);

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「！ はい、お願いします！ プログラマー視点からの『実現可能性』と『最適解』が欲しかったんです」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:NONE]ホワイトボードに図式を書き出しながら意見を交わすと、彼女は「なるほど……参考になります」と熱心にメモを取っていた。"
			);
			data.setC3Love(0); data.setC3Like(4); // 【Like最大】最高の相談相手
			data.setRes3Visuals(new VisualBeans("Sayuki_nomal.png", bgSunset, "cross_fade", "normal", "sunset"));
			break;

		case 11: // 【ケース11：一部手伝いの依頼】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]深夜、サユキがUSBメモリを握りしめたまま、俺のデスクの横に立っていた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……あの。" + pName + "さん」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「私の作ってるゲームの、この当たり判定の処理……どうしても重くて。少しだけ、コード見てもらえませんか」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「もちろん、タダでとは言いません。今度お昼、奢りますから」"
			);
			data.setChoice1Text("最高のコードに直すよ");
			data.setChoice2Text("サユキさんのためなら喜んで");
			data.setChoice3Text("昼飯一回じゃ割に合わないな");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……！」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……大きく出ましたね。でも、プロの腕前、期待してますよ」" +
				"[NEXT]" +
				"[NAME:NONE]少し挑発的な笑顔を見せた。頼りになる助っ人として、きっちり結果を出さなければ。"
			);
			data.setC1Love(1); data.setC1Like(4); // 【Like最大】プロとしての請負
			data.setRes1Visuals(new VisualBeans("Sayuki_nomal.png", bgNight, "cross_fade", "normal", "night"));

			data.setRes2(
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「なっ……！？ 私のためって……別にそういうんじゃなくて、単なる技術的な外注というか……」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……変な恩着せがましさは不要です。あくまでビジネスライクにお願いします」" +
				"[NEXT]" +
				"[NAME:NONE]下心を見せたことで警戒されてしまった。素直に技術の話をすべきだった。"
			);
			data.setC2Love(2); data.setC2Like(-2); // 【Loveは上がるがLikeは下がる】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……強欲ですね。じゃあもういいです、自分でなんとかします」" +
				"[NEXT]" +
				"[NAME:NONE]呆れられてしまった。せっかく彼女から頼ってくれたチャンスを逃した。"
			);
			data.setC3Love(0); data.setC3Like(-2);
			data.setRes3Visuals(new VisualBeans("Sayuki_jitome.png", bgNight, "cross_fade", "close_up", "night"));
			break;

		case 12: // 【ケース12：圧倒的な技術への感嘆】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]俺が自分のフリーランスの仕事で、複雑なバックエンドのバグを高速で修正していた時のこと。" +
				"[NEXT]" +
				"[NAME:NONE]エンターキーを叩き、無事にシステムが復旧すると、サユキが信じられないものを見る目でこちらを見ていた。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……" + pName + "さんって、本当にすごいですよね」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「あんなエラーの羅列、私には呪文にしか見えないのに……数分で原因を特定して直すなんて」"
			);
			data.setChoice1Text("プロでフリーならこれくらい当然だよ");
			data.setChoice2Text("サユキさんの絵と俺のコードなら、もしかしたらすごいものが作れそうだね");
			data.setChoice3Text("俺もサユキさんの絵にはいつも見惚れてるよ");

			data.setRes1(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……そうですか。素直に褒めた私がバカみたいですね。その驕りがいつか命取りになりますよ」" +
				"[NEXT]" +
				"[NAME:NONE]謙虚さが足りなかったようだ。少し空気が冷めた。"
			);
			data.setC1Love(-1); data.setC1Like(-2);

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……。そうですね。あなたの技術力は本物です」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……いつか、私の企画にメインプログラマーとして巻き込んじゃおうかな」" +
				"[NEXT]" +
				"[NAME:NONE]冗談めかしてはいるが、クリエイターとして最大限の評価をもらえたようだ。"
			);
			data.setC2Love(1); data.setC2Like(4); // 【Like最大】クリエイター同士のリスペクト

			data.setRes3(
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「み、見惚れるって……大袈裟ですよ。……それに今はあなたのコードの話をしてたのに」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は照れ隠しのように髪を弄った。好意は伝わったが、技術へのリスペクトの応酬にはならなかった。"
			);
			data.setC3Love(3); data.setC3Like(-1); // 【Love寄り】
			data.setRes3Visuals(new VisualBeans("Sayuki_mesorasi.png", bgDay, "cross_fade", "normal", "day"));
			break;

		case 13: // 【ケース13：コーヒーで乾杯】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]お互いの仕事のキリがついた夜。休憩がてら、自販機で買ってきた缶コーヒーを二人で開けた。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「今日は二人とも、かなり進捗ありましたね。……乾杯、します？」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女の方から、自分の缶をこちらに差し出してきた。少し機嫌が良いらしい）"
			);
			data.setChoice1Text("サユキさんの魅力に乾杯");
			data.setChoice2Text("早く飲んで残りの作業やろう");
			data.setChoice3Text("お互いの最高の進捗に乾杯");

			data.setRes1(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……はぁ。貴方って、たまに本当に痛いですよね。頭冷やしてください」" +
				"[NEXT]" +
				"[NAME:NONE]呆れられ、彼女は自分の缶を引っ込めてしまった。ムードを履き違えた。"
			);
			data.setC1Love(1); data.setC1Like(-3); // 【大失敗】

			data.setRes2(
				"[IMG:Sayuki_musu.png]" +
				"[NAME:SAYUKI]「……せっかくの気分転換なのに。余裕がない人は嫌われますよ」" +
				"[NEXT]" +
				"[NAME:NONE]一人で缶を開け、不満そうに一口飲んで作業に戻ってしまった。"
			);
			data.setC2Love(-1); data.setC2Like(-2);

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！ ふふ。はいっ」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「カチンッ、と小気味良い音を立てて缶をぶつける。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「明日からも、分からないところがあったらよろしくお願いしますね、" + pName + "さん」" +
				"[NEXT]" +
				"[NAME:NONE]穏やかな夜のオフィスで、確かな連帯感を共有できた。"
			);
			data.setC3Love(1); data.setC3Like(4); // 【Like最大】頼りになる同居人
			data.setRes3Visuals(new VisualBeans("Sayuki_nomal.png", bgNight, "cross_fade", "normal", "night"));
			break;

		case 14: // 【ケース14：「優秀な技術顧問」の称号】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]サユキがふとモニターから目を離し、柔らかい表情でこちらを見た。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……最初は、私の領域にズカズカ踏み込んでくる迷惑な居候だと思ってたのに」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「まさか、ここまで技術的に頼りになるなんて思いませんでした」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「今ではすっかり、私の『優秀な技術顧問』気取りですね。" + pName + "さん」" +
				"[NEXT]" +
				"[NAME:PLAYER]（『技術顧問』……。出会った頃の警戒心を思えば、とんでもない昇格だ）"
			);
			data.setChoice1Text("いつでも頼ってよ。いい顧問になるから");
			data.setChoice2Text("顧問じゃなくて、彼氏とかどう？");
			data.setChoice3Text("顧問料、高くつくよ？(冗談めいて笑いかける)");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……ふふ。なら、これからも無茶なバグ修正、投げつけますからね」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:NONE]彼女のイタズラっぽい笑顔に、こちらも全力で応えることを誓った。同居人として、そして技術者として確固たる地位を築いた瞬間だ。"
			);
			data.setC1Love(1); data.setC1Like(5); // 【Likeルートの大正解】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。じょ、冗談言わないでください。……せっかく真面目に話してたのに……っ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:NONE]彼女は顔を真っ赤にして口ごもった。仕事の関係に恋愛を持ち込んだため、呆れられたが意識はされたようだ。"
			);
			data.setC2Love(5); data.setC2Like(-2); // 【Loveへの強烈なフラグ】Likeルートとしては不正解
			data.setRes2Visuals(new VisualBeans("Sayuki_mesorasi.png", bgDay, "cross_fade", "normal", "day"));

			data.setRes3(
				"[IMG:Sayuki_scary_smile.png]" +
				"[NAME:SAYUKI]「……ははっ！分かりました。いつか私が売れた時にお支払いしていきますね。出世払いってことで」" +
				"[NEXT]" +
				"[NAME:NONE]冗談が伝わったのか、笑ってくれたようだ。きっと彼女ならその日も近いだろうな"
			);
			data.setC3Love(2); data.setC3Like(3); // 【バランス】
			data.setRes3Visuals(new VisualBeans("Sayuki_scary_smile.png", bgDay, "cross_fade", "close_up", "day"));
			break;

		default:
			return super.getScenario(0, pName);
		}
		return data;
	}
}