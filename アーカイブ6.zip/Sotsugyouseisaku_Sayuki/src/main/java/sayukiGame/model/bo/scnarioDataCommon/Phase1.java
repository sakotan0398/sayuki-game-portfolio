package sayukiGame.model.bo.scnarioDataCommon;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;

public class Phase1 {

	public ScenarioData getScenario(int num, String pName) {
		ScenarioData data = new ScenarioData();
		data.setPoolType("Common");

		// 💡 背景画像（オフィス風）
		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 

		switch (num) {
		case 0: // 【ケース0：打鍵音とテリトリー】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
					"[NAME:NONE]静まり返ったオフィスに、カタカタという俺のタイピング音だけが響いている。" +
					"[NEXT]" +
					"[NAME:PLAYER]（環境を変えたくてここを間借りしたけど、管理人のサユキさんはずっと不機嫌そうだな……）" +
					"[NEXT]" +
					"[NAME:NONE]ターンッ！と、無意識のうちにエンターキーを強めに叩いてしまった、その時。" +
					"[NEXT]" +
					"[IMG:Sayuki_dakara.png]" +
					"[NAME:SAYUKI]「……あの。" + pName + "さん」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「さっきから打鍵音が異常にうるさいんですけど。ここはコワーキングスペースじゃありません。配慮してもらえませんか」");
			
			data.setChoice1Text("ごめんなさい。気を付けます");
			data.setChoice2Text("静音キーボードに変えようかな");
			data.setChoice3Text("わざとさらにターンッ！と叩く");

			data.setRes1(
					"[IMG:Sayuki_musu.png]" +
					"[NAME:SAYUKI]「……素直で結構です。そもそも、オーナーの紹介じゃなかったら絶対に入れてませんからね」" +
					"[NEXT]" +
					"[NAME:NONE]彼女は小さくため息をつき、再び自分のモニターへと向き直った。");
			data.setC1Love(0);
			data.setC1Like(2);
			data.setRes1Visuals(new VisualBeans("Sayuki_focus.png", bgDay, "cross_fade", "normal", "day"));

			data.setRes2(
					"[IMG:Sayuki_nomal.png]" +
					"[NAME:SAYUKI]「……静音性のキーボードなら、私が使っているメーカーの赤軸モデルがおすすめです」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「リンク、後でチャットに貼っておきますから。……これ以上私の集中を削がないでください」" +
					"[NEXT]" +
					"[NAME:NONE]文句を言いつつも、仕事道具の話になると少しだけ口が滑らかになるらしい。");
			data.setC2Love(2);
			data.setC2Like(3); 
			data.setRes2Visuals(new VisualBeans("Sayuki_nomal.png", bgDay, "cross_fade", "normal", "day"));

			data.setRes3(
					"[IMG:Sayuki_dakara_syomen_mouth_open.png]" +
					"[NAME:SAYUKI]「ちょっと、わざと今エンターの音大きくしましたよね！？」" +
					"[NEXT]" +
					"[IMG:Sayuki_jitome.png]" +
					"[NAME:SAYUKI]「……はぁ。人の聖域に上がり込んできて、その態度ですか……」" +
					"[NEXT]" +
					"[NAME:NONE]彼女はあからさまに不機嫌そうな顔でこちらを睨みつけている。完全に空気が凍りついてしまった……。");
			data.setC3Love(-1);
			data.setC3Like(-2);
			data.setRes3Visuals(new VisualBeans("Sayuki_jitome.png", bgDay, "cross_fade", "close_up", "day"));
			break;

		case 1: // 【ケース1：イラストの覗き見】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
					"[NAME:NONE]夕暮れ時。サユキのペンタブレットを走らせる音が、心地よいリズムを刻んでいる。" +
					"[NEXT]" +
					"[NAME:PLAYER]（すごい集中力だ……。一体どんなイラストを描いているんだろう？）" +
					"[NEXT]" +
					"[NAME:NONE]気になった俺は、作業中の彼女の背後からそっとモニターを覗き込んだ。" +
					"[NEXT]" +
					"[IMG:Sayuki_anxiety.png]" +
					"[NAME:SAYUKI]「っ！？ ……ちょっと！」" +
					"[NEXT]" +
					"[NAME:NONE]気配に気づいた彼女は素早くペンを止め、隠すようにウィンドウを最小化した。" +
					"[NEXT]" +
					"[IMG:Sayuki_dakara.png]" +
					"[NAME:SAYUKI]「……背後に立たれると気が散るんですけど。完成前のラフを見られるのも好きじゃありません」");
			
			data.setChoice1Text("ごめんなさい、邪魔する気はなくて…");
			data.setChoice2Text("すごく綺麗だったから、つい見惚れてた");
			data.setChoice3Text("減るもんじゃないし、いいじゃん");

			data.setRes1(
					"[IMG:Sayuki_dakara_syomen.png]" +
					"[NAME:SAYUKI]「邪魔する気がないなら、自分の席から動かないでください。……クリエイターならそのくらいの常識、分かりますよね？」" +
					"[NEXT]" +
					"[NAME:NONE]正論で殴られ、ぐうの音も出ない。彼女のパーソナルスペースは想像以上に狭いようだ。");
			data.setC1Love(1);
			data.setC1Like(2);
			data.setRes1Visuals(new VisualBeans("Sayuki_focus.png", bgSunset, "cross_fade", "normal", "sunset"));

			data.setRes2(
					"[IMG:Sayuki_surprised.png]" +
					"[NAME:SAYUKI]「……え。……っ、あ……」" +
					"[NEXT]" +
					"[IMG:Sayuki_mesorasi.png]" +
					"[NAME:SAYUKI]「……まだ、色塗りも終わってない段階ですから。そんな風に言われるようなクオリティじゃ……」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「……と、とりあえず！ 今は自分の作業に戻ってください！」" +
					"[NEXT]" +
					"[NAME:NONE]少しだけ頬を赤くした彼女は、あからさまに目を逸らして作業に戻ってしまった。");
			data.setC2Love(3);
			data.setC2Like(2);
			data.setRes2Visuals(new VisualBeans("Sayuki_mesorasi.png", bgSunset, "cross_fade", "normal", "sunset"));

			data.setRes3(
					"[IMG:Sayuki_scary_smile.png]" +
					"[NAME:SAYUKI]「……そういう問題じゃありません。私の精神が削り取られるんです」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「これ以上無神経な態度をとるなら、オーナーに言って追い出しますよ」" +
					"[NEXT]" +
					"[NAME:NONE]サユキの冷ややかな笑顔に、背筋が凍る思いがした……。");
			data.setC3Love(-2);
			data.setC3Like(-2);
			data.setRes3Visuals(new VisualBeans("Sayuki_scary_smile.png", bgSunset, "cross_fade", "close_up", "sunset"));
			break;

		case 2: // 【ケース2：コーヒーの差し入れ】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
					"[NAME:NONE]夜も更けてきたが、サユキは一向に休憩を取る気配がない。" +
					"[NEXT]" +
					"[NAME:PLAYER]（いくらなんでも根詰めすぎだ。少し休憩を促してみるか）" +
					"[NEXT]" +
					"[NAME:NONE]俺は共有のキッチンでコーヒーを2つ淹れ、彼女のデスクへと向かった。" +
					"[NEXT]" +
					"[NAME:PLAYER]「サユキさん、少し休憩しませんか？ コーヒー淹れましたよ」" +
					"[NEXT]" +
					"[IMG:Sayuki_dakara.png]" +
					"[NAME:SAYUKI]「……頼んだ覚えはありませんけど」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「今はキリが悪いんです。冷める前に、ご自分で2杯とも飲んだらどうですか？」");
			
			data.setChoice1Text("そう言わずに、気分転換も大事だよ");
			data.setChoice2Text("机の隅に置いておくから、後で飲んでね");
			data.setChoice3Text("じゃあ、ありがたく俺が2杯飲むね");

			data.setRes1(
					"[IMG:Sayuki_jitome.png]" +
					"[NAME:SAYUKI]「私のペースは私が一番よく分かっています。余計なお世話です」" +
					"[NEXT]" +
					"[NAME:NONE]冷たくあしらわれてしまった。まだ彼女との距離感は遠いようだ……。");
			data.setC1Love(1);
			data.setC1Like(-1);
			data.setRes1Visuals(new VisualBeans("Sayuki_focus.png", bgNight, "cross_fade", "normal", "night"));

			data.setRes2(
					"[IMG:Sayuki_nomal.png]" +
					"[NAME:SAYUKI]「…………」" +
					"[NEXT]" +
					"[NAME:NONE]サユキは何も答えなかったが、数十分後、机の隅にあったマグカップは静かに空になっていた。" +
					"[NEXT]" +
					"[NAME:PLAYER]（……強情だけど、悪い子じゃないんだよな）");
			data.setC2Love(2);
			data.setC2Like(3); 
			data.setRes2Visuals(new VisualBeans("Sayuki_nomal.png", bgNight, "cross_fade", "normal", "night"));

			data.setRes3(
					"[IMG:Sayuki_surprised.png]" +
					"[NAME:SAYUKI]「……えっ。あ、本当に飲むんですか？」" +
					"[NEXT]" +
					"[IMG:Sayuki_musu.png]" +
					"[NAME:SAYUKI]「……別にいいですけど。カフェインの過剰摂取で倒れないでくださいね」" +
					"[NEXT]" +
					"[NAME:NONE]少しだけ不満げな顔をされた。もしかして、本当は飲みたかったのだろうか？");
			data.setC3Love(2); 
			data.setC3Like(1);
			data.setRes3Visuals(new VisualBeans("Sayuki_musu.png", bgNight, "cross_fade", "normal", "night"));
			break;

		case 3: // 🌟【新ケース3：管理人の縄張り】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
					"[NAME:NONE]作業中、喉が渇いたのでオフィスの共有冷蔵庫を開けた。" +
					"[NEXT]" +
					"[NAME:PLAYER]「あれ、俺の買っておいたお茶がないな……」" +
					"[NEXT]" +
					"[IMG:Sayuki_dakara_syomen.png]" +
					"[NAME:SAYUKI]「ああ、それなら一番下の段に移動させましたよ」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「上の段は私のスペースです。いくらオーナーの紹介とはいえ、勝手に私のテリトリーを侵食しないでください」" +
					"[NEXT]" +
					"[NAME:PLAYER]（……このオフィス、どんだけ私物化してたんだ？）");

			data.setChoice1Text("ごめん、次から気を付けるよ");
			data.setChoice2Text("俺も家賃払ってるんだけどな……");
			data.setChoice3Text("じゃあ、真ん中の段は共有ってことで！");

			data.setRes1(
					"[IMG:Sayuki_musu.png]" +
					"[NAME:SAYUKI]「……分かればいいんです。ここは私が管理を任されているんですから」" +
					"[NEXT]" +
					"[NAME:NONE]少し得意げに言い残し、彼女はドリップコーヒーを淹れ始めた。");
			data.setC1Love(1);
			data.setC1Like(2);
			data.setRes1Visuals(new VisualBeans("Sayuki_musu.png", bgDay, "cross_fade", "normal", "day"));

			data.setRes2(
					"[IMG:Sayuki_jitome.png]" +
					"[NAME:SAYUKI]「家賃を払えば何でも許されるわけじゃありません。ここは元々、私のプライベート空間だったんです」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「……はぁ、本当に調子が狂います……」" +
					"[NEXT]" +
					"[NAME:NONE]彼女は恨めしそうにこちらを睨みつけてきた。");
			data.setC2Love(-1);
			data.setC2Like(-2);
			data.setRes2Visuals(new VisualBeans("Sayuki_jitome.png", bgDay, "cross_fade", "close_up", "day"));

			data.setRes3(
					"[IMG:Sayuki_surprised.png]" +
					"[NAME:SAYUKI]「は？ なんで勝手にルール作ってるんですか」" +
					"[NEXT]" +
					"[IMG:Sayuki_dakara.png]" +
					"[NAME:SAYUKI]「……まぁ、真ん中くらいなら譲ってあげなくもないですけど。綺麗に使ってくださいね」" +
					"[NEXT]" +
					"[NAME:NONE]少しムッとしつつも、妥協案をあっさり受け入れてくれた。");
			data.setC3Love(2);
			data.setC3Like(2);
			data.setRes3Visuals(new VisualBeans("Sayuki_dakara.png", bgDay, "cross_fade", "normal", "day"));
			break;

		case 4: // 🌟【新ケース4：初心者の意地とバグ】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
					"[NAME:NONE]サユキの席から、さっきから何度も深いため息が聞こえてくる。" +
					"[NEXT]" +
					"[NAME:PLAYER]（画面に赤い文字がいっぱい出てるな……。コンパイルエラーで詰まってるみたいだ）" +
					"[NEXT]" +
					"[NAME:PLAYER]「サユキさん、どうかした？ もしエラーで詰まってるなら、少し見ようか？」" +
					"[NEXT]" +
					"[IMG:Sayuki_dakara_syomen_mouth_open.png]" +
					"[NAME:SAYUKI]「っ！ み、見ないでください！」" +
					"[NEXT]" +
					"[IMG:Sayuki_anxiety.png]" +
					"[NAME:SAYUKI]「プロのエンジニアに、こんな……こんな初心者みたいなコード見られるなんて、屈辱以外の何物でもありません」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「エラーログくらい読めます。自分で直せますから、放っておいてください」");

			data.setChoice1Text("そう？じゃあ頑張ってね");
			data.setChoice2Text("俺も最初はそうだったよ。一緒に見よう");
			data.setChoice3Text("強がっても時間が無駄になるだけだよ");

			data.setRes1(
					"[IMG:Sayuki_musu.png]" +
					"[NAME:SAYUKI]「……はい。頑張ります」" +
					"[NEXT]" +
					"[NAME:NONE]彼女はギリッと唇を噛み、再びエラー画面と睨み合いを始めた。" +
					"[NEXT]" +
					"[NAME:PLAYER]（……意地っ張りだな。でも、今はそっとしておくのが正解か）");
			data.setC1Love(1);
			data.setC1Like(2); 
			data.setRes1Visuals(new VisualBeans("Sayuki_musu.png", bgSunset, "cross_fade", "normal", "sunset"));

			data.setRes2(
					"[IMG:Sayuki_surprised.png]" +
					"[NAME:SAYUKI]「……プロの" + pName + "さんでも、ですか？」" +
					"[NEXT]" +
					"[IMG:Sayuki_mesorasi.png]" +
					"[NAME:SAYUKI]「……っ。……じゃあ、その。……nullポインタ例外って、どうやって追えばいいんですか……？」" +
					"[NEXT]" +
					"[NAME:NONE]ほんの少しだけ、彼女が助けを求めてくれた。プログラマーとしての信頼を少し得られたようだ。");
			data.setC2Love(2);
			data.setC2Like(3); 
			data.setRes2Visuals(new VisualBeans("Sayuki_mesorasi.png", bgSunset, "cross_fade", "normal", "sunset"));

			data.setRes3(
					"[IMG:Sayuki_scary_smile.png]" +
					"[NAME:SAYUKI]「……っ！ あなたに私の何が分かるんですか！」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「上から目線でアドバイスした気にならないでください。本当に鬱陶しいです」" +
					"[NEXT]" +
					"[NAME:NONE]完全に地雷を踏んでしまった。正論は時として、相手の心を頑なに閉ざしてしまう……。");
			data.setC3Love(-2);
			data.setC3Like(-2);
			data.setRes3Visuals(new VisualBeans("Sayuki_scary_smile.png", bgSunset, "cross_fade", "close_up", "sunset"));
			break;
		case 5: // 【ケース5：戦闘服の合理性とこだわり】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
					"[NAME:PLAYER]（サユキさんの格好、何度見ても個性的だよな……。ダボっとしたオーバーサイズのジャケットに、大きく露出した肩）" +
					"[NEXT]" +
					"[NAME:PLAYER]（このオフィスだからいいものの、少し気になってしまう）" +
					"[NEXT]" +
					"[NAME:PLAYER]「サユキさん、前から思ってたんだけど、その服……」" +
					"[NEXT]" +
					"[IMG:Sayuki_dakara.png]" +
					"[NAME:SAYUKI]「……何ですか。私の服装に文句でもあるんですか？」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「言っておきますけど、あなたが入ってくる前はここは私だけの部屋だったんです。私がどんな服で作業しようが私の勝手でしょう」");

			data.setChoice1Text("いや、肩が出てるから寒くないのかなって");
			data.setChoice2Text("絵を描くのに、袖とか邪魔にならないの？");
			data.setChoice3Text("いや、すごく個性的で似合ってると思う");

			data.setRes1(
					"[IMG:Sayuki_dakara_syomen.png]" +
					"[NAME:SAYUKI]「……PCの排熱で室温が上がるんですから、上半身の熱を逃がすために肩を出しているんです。むしろ合理的ですよね？」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「冷えないように下半身は温めてますし。素人のあなたに空調対策を心配される筋合いはありません」" +
					"[NEXT]" +
					"[NAME:PLAYER]（なるほど、理屈っぽいけど一応ちゃんと考えてるんだな……）");
			data.setC1Love(0);
			data.setC1Like(2); // 合理性を理解したのでLike微増
			data.setRes1Visuals(new VisualBeans("Sayuki_dakara_syomen.png", bgDay, "cross_fade", "normal", "day"));

			data.setRes2(
					"[IMG:Sayuki_musu.png]" +
					"[NAME:SAYUKI]「逆です。肩周りに布の抵抗がないから、液タブで大きなストロークを描く時に一番腕の可動域が広いんです」" +
					"[NEXT]" +
					"[IMG:Sayuki_nomal.png]" +
					"[NAME:SAYUKI]「……それに、こういうテック系のデザインが好きなので。私のモチベーションを極限まで上げる『戦闘服』なんです」" +
					"[NEXT]" +
					"[NAME:PLAYER]（機能美と本人の好みを両立してるのか。プロのこだわりだな）");
			data.setC2Love(2); 
			data.setC2Like(3); // クリエイターとしてのこだわりに触れたのでLike高め
			data.setRes2Visuals(new VisualBeans("Sayuki_nomal.png", bgDay, "cross_fade", "normal", "day"));

			data.setRes3(
					"[IMG:Sayuki_jitome.png]" +
					"[NAME:SAYUKI]「……ジロジロ見ながらそんなこと言われると、ただのセクハラにしか聞こえません」" +
					"[NEXT]" +
					"[IMG:Sayuki_scary_smile.png]" +
					"[NAME:SAYUKI]「オーナーに言って、出入り禁止にしますよ？」" +
					"[NEXT]" +
					"[NAME:PLAYER]（完全に警戒された……。これ以上触れるのはやめよう）");
			data.setC3Love(-2); // 下心があると判定されてマイナス
			data.setC3Like(-2);
			data.setRes3Visuals(new VisualBeans("Sayuki_scary_smile.png", bgDay, "cross_fade", "close_up", "day"));
			break;

		case 6: // 【ケース6：朝の低血圧ゾンビ】
			data.setVisuals(new VisualBeans("Sayuki_mesorasi.png", bgDay, "none", "normal", "day"));
			data.setMessage(
					"[NAME:NONE]朝10時。オフィスに出社すると、サユキが既にデスクに座っていた。" +
					"[NEXT]" +
					"[NAME:PLAYER]「おはよう、サユキさん。早いね」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「…………」" +
					"[NEXT]" +
					"[NAME:NONE]返事がない。覗き込むと、彼女はジャケットを頭からすっぽり被り、半目で画面を虚無のように見つめていた。" +
					"[NEXT]" +
					"[NAME:PLAYER]（……もしかして、寝てる？ いや、目は開いてるけど……）");

			data.setChoice1Text("おーい、生きてる？（顔を覗き込む）");
			data.setChoice2Text("そっとしておき、自分の作業を始める");
			data.setChoice3Text("熱いコーヒーでも淹れようか？");

			data.setRes1(
					"[IMG:Sayuki_jitome.png]" +
					"[NAME:SAYUKI]「……近いです。パーソナルスペースを侵さないでください」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「……今、私の脳内CPUのクロック数は２％しか出てないんです。話しかけないで……」" +
					"[NEXT]" +
					"[NAME:NONE]かすれ声で文句を言われた。どうやら極度の低血圧で、朝は使い物にならないらしい。");
			data.setC1Love(2); 
			data.setC1Like(-1);
			data.setRes1Visuals(new VisualBeans("Sayuki_jitome.png", bgDay, "cross_fade", "close_up", "day"));

			data.setRes2(
					"[IMG:Sayuki_focus.png]" +
					"[NAME:NONE]俺は足音を忍ばせ、自分の席に着いた。" +
					"[NEXT]" +
					"[NAME:NONE]それから１時間ほど、オフィスには彼女の規則正しい寝息だけが響いていた……。");
			data.setC2Love(1);
			data.setC2Like(2); // ペースを乱さなかったのでLike微増
			data.setRes2Visuals(new VisualBeans("Sayuki_focus.png", bgDay, "cross_fade", "normal", "day"));

			data.setRes3(
					"[IMG:Sayuki_surprised.png]" +
					"[NAME:SAYUKI]「……っ！ コー……ヒー……？」" +
					"[NEXT]" +
					"[IMG:Sayuki_nomal.png]" +
					"[NAME:SAYUKI]「……ブラックで。泥水くらい濃いやつをお願いします……」" +
					"[NEXT]" +
					"[NAME:PLAYER]（どんだけカフェインに依存してるんだよ……）");
			data.setC3Love(2);
			data.setC3Like(3); // エンジニア的気遣いとしてLike上昇
			data.setRes3Visuals(new VisualBeans("Sayuki_nomal.png", bgDay, "cross_fade", "normal", "day"));
			break;

		case 7: // 【ケース7：昼食のデリバリーと偏食】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
					"[NAME:NONE]昼過ぎ。オフィスのインターホンが鳴り、サユキが頼んでいたデリバリーが届いた。" +
					"[NEXT]" +
					"[NAME:PLAYER]（ずっと作業してたし、さぞかし美味いものでも食べるんだろうな……）" +
					"[NEXT]" +
					"[NAME:NONE]そう思って横目で見ると、彼女のデスクにはエナジードリンクと、パサパサのサンドイッチが置かれていた。" +
					"[NEXT]" +
					"[NAME:SAYUKI]「……チッ。サンドイッチにトマト抜いてって書いたのに、入ってるじゃないですか」" +
					"[NEXT]" +
					"[NAME:NONE]彼女は割り箸を使い、親の仇のようにトマトをつまみ出している。");

			data.setChoice1Text("トマト嫌いなの？ 健康にいいのに");
			data.setChoice2Text("俺の買ってきたサラダチキン、食べる？");
			data.setChoice3Text("見なかったことにして作業を続ける");

			data.setRes1(
					"[IMG:Sayuki_anxiety.png]" +
					"[NAME:SAYUKI]「健康とかどうでもいいんです。あのグチャッとした食感、見るだけで作業効率が落ちます」" +
					"[NEXT]" +
					"[IMG:Sayuki_dakara.png]" +
					"[NAME:SAYUKI]「大体、私の食事にいちいち口を出さないでください。母親ですか？」" +
					"[NEXT]" +
					"[NAME:NONE]余計な口出しをしてしまったようだ。機嫌を損ねてしまった。");
			data.setC1Love(-1);
			data.setC1Like(-1);
			data.setRes1Visuals(new VisualBeans("Sayuki_dakara.png", bgDay, "cross_fade", "normal", "day"));

			data.setRes2(
					"[IMG:Sayuki_surprised.png]" +
					"[NAME:SAYUKI]「え……。いや、他人の施しを受けるなんて……」" +
					"[NEXT]" +
					"[IMG:Sayuki_mesorasi.png]" +
					"[NAME:SAYUKI]「……トマト、入ってないですよね？ ……じゃあ、その……お言葉に甘えて」" +
					"[NEXT]" +
					"[NAME:PLAYER]（本当にトマトが無理なんだな。少しだけ素直なところが見れた）");
			data.setC2Love(3); // 素直に助けられたのでLove上昇
			data.setC2Like(1);
			data.setRes2Visuals(new VisualBeans("Sayuki_mesorasi.png", bgDay, "cross_fade", "normal", "day"));

			data.setRes3(
					"[IMG:Sayuki_focus.png]" +
					"[NAME:NONE]下手に口出しして怒られるのも面倒だ。俺は自分のキーボードに向き直った。" +
					"[NEXT]" +
					"[NAME:NONE]しばらく、隣からトマトを隔離するカサカサという音だけが響いていた。");
			data.setC3Love(0);
			data.setC3Like(0);
			data.setRes3Visuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			break;

		case 8: // 【ケース8：オタクの裏垢フリック】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
					"[NAME:NONE]深夜のオフィス。ふと見ると、サユキが猛烈な勢いでスマホをフリックしている。" +
					"[NEXT]" +
					"[NAME:PLAYER]（すごいタイピング速度だ……仕事の連絡か？）" +
					"[NEXT]" +
					"[NAME:NONE]珍しく少し楽しそうな顔をしている気がして、俺は軽く声をかけてみた。" +
					"[NEXT]" +
					"[NAME:PLAYER]「何見てるの？ 楽しそうだけど」" +
					"[NEXT]" +
					"[IMG:Sayuki_anxiety.png]" +
					"[NAME:SAYUKI]「っっ！？」" +
					"[NEXT]" +
					"[NAME:NONE]ビクッと肩を震わせた彼女は、スマホを裏返して机に叩きつけるように置いた。");

			data.setChoice1Text("えっ、ごめん。驚かせるつもりは…");
			data.setChoice2Text("さては彼氏とLINE？");
			data.setChoice3Text("……かわいい女の子とかゲーム、好きなの？");

			data.setRes1(
					"[IMG:Sayuki_dakara.png]" +
					"[NAME:SAYUKI]「……心臓が止まるかと思いました。急に背後から話しかけないでください」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「ただの……情報収集です。デザインに向けた、重要なリサーチです」" +
					"[NEXT]" +
					"[NAME:PLAYER]（絶対に嘘だ……目が泳ぎまくっている）");
			data.setC1Love(0);
			data.setC1Like(0);
			data.setRes1Visuals(new VisualBeans("Sayuki_dakara.png", bgNight, "cross_fade", "normal", "night"));

			data.setRes2(
					"[IMG:Sayuki_scary_smile.png]" +
					"[NAME:SAYUKI]「……は？ 私が？ 彼氏？」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「そんな無駄なタスクにリソースを割くわけないでしょう。……少しは頭を使って喋ってください」" +
					"[NEXT]" +
					"[NAME:NONE]地雷を踏んでしまったようだ。氷点下の視線が突き刺さる。");
			data.setC2Love(-1);
			data.setC2Like(-2);
			data.setRes2Visuals(new VisualBeans("Sayuki_scary_smile.png", bgNight, "cross_fade", "close_up", "night"));

			data.setRes3(
					"[IMG:Sayuki_surprised.png]" +
					"[NAME:SAYUKI]「なっ！？ 見たんですか！？ 私の裏垢……じゃなくて！」" +
					"[NEXT]" +
					"[IMG:Sayuki_mesorasi.png]" +
					"[NAME:SAYUKI]「……ち、違います！ ただの……資料探しをしていて……」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「……とにかく！ あなたには関係ありません！ ほら、さっさと作業に戻って！」" +
					"[NEXT]" +
					"[NAME:NONE]耳まで赤くして怒られた。触れてはいけない秘密だったらしい。");
			data.setC3Love(2); // 動揺を引き出したのでLove微増
			data.setC3Like(-1); // しかしプライバシーに踏み込んだのでLike低下
			data.setRes3Visuals(new VisualBeans("Sayuki_mesorasi.png", bgNight, "cross_fade", "normal", "night"));
			break;

		case 9: // 【ケース9：境界線とエアダスター】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
					"[NAME:PLAYER]（コンセントが足りないな……。サユキさんのデスクの方の電源、１つ空いてるか？）" +
					"[NEXT]" +
					"[NAME:NONE]俺は椅子を転がし、彼女のデスクの境界線を少しだけ越えて電源ケーブルを伸ばした。" +
					"[NEXT]" +
					"[NAME:SAYUKI]「…………シューーーーーッ」" +
					"[NEXT]" +
					"[NAME:PLAYER]「うわっ、冷たっ！？」" +
					"[NEXT]" +
					"[IMG:Sayuki_jitome.png]" +
					"[NAME:NONE]見ると、サユキがキーボード掃除用の『エアダスター』を俺の腕に向けて噴射していた。");

			data.setChoice1Text("な、何するんだよ！");
			data.setChoice2Text("ごめん、電源を借りたくて");
			data.setChoice3Text("……もう一回かけてみて");

			data.setRes1(
					"[IMG:Sayuki_dakara.png]" +
					"[NAME:SAYUKI]「私のテリトリーに無断で侵入した害虫を駆除しただけですけど」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「これ以上踏み込むなら、次はエアダスターを逆さにして液化ガスを吹き付けますよ」" +
					"[NEXT]" +
					"[NAME:PLAYER]（冗談に聞こえない……。このオフィスの縄張り意識、強すぎるだろ）");
			data.setC1Love(0);
			data.setC1Like(0);
			data.setRes1Visuals(new VisualBeans("Sayuki_dakara.png", bgDay, "cross_fade", "normal", "day"));

			data.setRes2(
					"[IMG:Sayuki_musu.png]" +
					"[NAME:SAYUKI]「……なら、最初からそう言ってください。勝手に領域に手を入れてくるから威嚇したんです」" +
					"[NEXT]" +
					"[NAME:NONE]彼女は渋々といった様子で、電源タップをこちらに蹴り飛ばしてきた。" +
					"[NEXT]" +
					"[NAME:PLAYER]（扱いは雑だが、貸してはくれるんだな……）");
			data.setC2Love(1);
			data.setC2Like(1);
			data.setRes2Visuals(new VisualBeans("Sayuki_musu.png", bgDay, "cross_fade", "normal", "day"));

			data.setRes3(
					"[IMG:Sayuki_scary_smile.png]" +
					"[NAME:SAYUKI]「……あなた、そっちの趣味があるんですか？ 気持ち悪いです」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「次に領域侵犯したら、電源ケーブルであなたの首を絞めますね」" +
					"[NEXT]" +
					"[NAME:NONE]凍りつくような冷たい声だった。冗談が通じる相手ではないらしい。");
			data.setC3Love(-3);
			data.setC3Like(-3);
			data.setRes3Visuals(new VisualBeans("Sayuki_scary_smile.png", bgDay, "cross_fade", "close_up", "day"));
			break;
		}

		return data;
	}
}