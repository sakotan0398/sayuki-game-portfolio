package sayukiGame.model.bo.scnarioDataLove;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;
import sayukiGame.model.bo.scnarioDataCommon.Phase3;

public class LovePhase3 extends Phase3 {

	@Override
	public ScenarioData getScenario(int num, String pName) {
		
		// 0〜8 が選ばれた場合は、親クラス（Common）の共通の日常会話をそのまま呼び出す
		if (num <= 8) {
			return super.getScenario(num, pName);
		}

		// 9〜14：Loveルート専用（意識し始めているが、まだ素直になりきれない距離感）
		ScenarioData data = new ScenarioData();
		data.setPoolType("Love");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 
		
		switch (num) {
		case 9: // 【ケース9：重なる手と言い訳】
			data.setVisuals(new VisualBeans("Sayuki_surprised.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]静かな午後。共有スペースに無造作に置かれたUIデザインの参考書を取ろうと手を伸ばした瞬間、同じ本に伸びてきたサユキの手と、偶然にも重なってしまった。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「あっ……」" +
				"[NEXT]" +
				"[NAME:NONE]お互いに驚いて、ピタリと動きが止まる。ほんの一瞬だったが、彼女の白く細い指先から、微かな体温と戸惑いが伝わってきた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（どうするべきか。ここで変に意識しすぎるのも不自然だが……）"
			);
			data.setChoice1Text("あ、ごめん。邪魔した？（サッと下がる）");
			data.setChoice2Text("（黙って彼女が手を引くのを待つ）");
			data.setChoice3Text("ごめん、先使っていいよ（紳士的に譲る）");

			data.setRes1(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……邪魔って。別に、触られたから嫌だとか、そういうわけじゃ……」" +
				"[NEXT]" +
				"[NAME:NONE]過剰に気を使われ、まるでバイ菌のように避けられたと感じたのか、彼女は少し傷ついたような顔をしてサッと手を引っ込めてしまった。"
			);
			data.setC1Love(-1); data.setC1Like(0); // 【失敗】距離を取りすぎた

			data.setRes2(
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……っ。……あの、いつまで触ってるんですか……。これじゃ資料、取れないんですけど……」" +
				"[NEXT]" +
				"[NAME:NONE]文句を言いながらも、彼女自身もすぐに手を引こうとはしなかった。気まずいような、それでいてどこか甘い熱を帯びた視線が、静かに絡み合う。"
			);
			data.setC2Love(4); data.setC2Like(-1); // 【Love最大】少し強引な間を持たせるのが正解

			data.setRes3(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「あ……はい。ありがとうございます。調べたい箇所を確認したら、すぐに返しますから」" +
				"[NEXT]" +
				"[NAME:NONE]少しだけ気まずい空気が流れたが、彼女は小さく会釈をして資料を引き寄せた。無難だが、少し距離を感じるやり取りだった。"
			);
			data.setC3Love(1); data.setC3Like(2); // 【Like寄り】
			break;

		case 10: // 【ケース10：見つめる視線と無自覚な好意】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]自分の仕事に没頭していた時。ふと、横からチクチクとした視線を感じて顔を向けると、サユキがサブモニターを見るふりをしこちらをじっと見つめていた。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！？ ち、違います！ 今のはその……ボーッとしてただけで！ 別にあなたを見てたわけじゃありません！」" +
				"[NEXT]" +
				"[NAME:PLAYER]（完全にバッチリ目が合ったのに、ペンを落としそうなほどの勢いで誤魔化し始めたな……）"
			);
			data.setChoice1Text("俺の顔、なんか付いてる？");
			data.setChoice2Text("目が疲れてるなら少し休んだら？");
			data.setChoice3Text("気が散るからジロジロ見ないでよ");

			data.setRes1(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「付いてないですっ！ ただ……その、バカみたいな顔して真剣にコード書いてるなぁって、少しだけ観察してただけで……っ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……だから、変な勘違いしないでくださいね。完全に作業の邪魔ですから」" +
				"[NEXT]" +
				"[NAME:NONE]めちゃくちゃな言い訳をしながら、彼女は耳まで赤くして大きなモニターの裏に隠れてしまった。動揺する姿がいじらしい。"
			);
			data.setC1Love(5); data.setC1Like(-1); // 【Love最大】照れ隠しのツンを引き出す

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……はい。少し、明るいモニターから目を離したかっただけです。心配ありがとうございます」" +
				"[NEXT]" +
				"[NAME:NONE]こちらの実務的な気遣いに、彼女はホッとしたように目頭を揉んだ。甘い空気はどこかへ流れていってしまった。"
			);
			data.setC2Love(1); data.setC2Like(3); // 【Like寄り】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……自意識過剰ですね。ええ、もう二度と見ませんから、一生その真っ黒な画面と睨めっこしててください」" +
				"[NEXT]" +
				"[NAME:NONE]彼女はシュンとして画面に向き直り、勢いよくタイピングを始めた。完全に心を閉ざしてしまったようだ。"
			);
			data.setC3Love(-3); data.setC3Like(-2); // 【大失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_jitome.png", bgSunset, "cross_fade", "close_up", "sunset"));
			break;

		case 11: // 【ケース11：些細な変化と乙女心】
			data.setVisuals(new VisualBeans("Sayuki_mesorasi.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]今日のサユキは、いつもの特徴的な髪型ではなく、髪を少し後ろで緩く縛り、うなじが見える大人っぽい雰囲気だった。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……あの。今日、ちょっと気分を変えてみたんですけど……変じゃ、ないですか？」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は少し落ち着かない様子で、後ろで縛った髪の毛先を指で弄っている。わざわざ俺に意見を求めてくるなんて、出会った頃には考えられないことだ。"
			);
			data.setChoice1Text("気分転換は大事だね。作業効率上がりそう");
			data.setChoice2Text("いつもの髪型の方が気合入るんじゃない？");
			data.setChoice3Text("すごく似合ってる。いつもより可愛いと思う");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……そうですね。気合を入れ直すためです。それ以外に理由なんてありませんから」" +
				"[NEXT]" +
				"[NAME:NONE]仕事優先の無難な返しに、彼女は少しだけ残念そうな顔をして頷いた。期待していた答えとは違ったらしい。"
			);
			data.setC1Love(1); data.setC1Like(2);

			data.setRes2(
				"[IMG:Sayuki_musu.png]" +
				"[NAME:SAYUKI]「……そうですか。せっかく少し早起きしてセットしたのに……。別にあなたの好みなんて聞いてませんけど」" +
				"[NEXT]" +
				"[NAME:NONE]分かりやすく落ち込ませてしまった。せっかくの彼女の小さな努力を無下にしてしまったようだ。"
			);
			data.setC2Love(-3); data.setC2Like(0); // 【失敗】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「か、可愛いって……っ！ 仕事場でそういうこと、軽々しく言わないでください！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも。……お世辞でも、その……。……勘違いしないでくださいね、別にあなたに見せるために変えたわけじゃないですから」" +
				"[NEXT]" +
				"[NAME:NONE]口では怒りながらも、彼女は嬉しそうにこぼれた髪を耳にかけた。完全にデレているのが隠しきれていない。"
			);
			data.setC3Love(5); data.setC3Like(0); // 【Love最大】
			break;

		case 12: // 【ケース12：間借り契約と少し先の未来】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]夜の静寂の中、キーボードを叩く音だけが響いていたアトリエで、不意にサユキが口を開いた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……あなたがここを間借りする契約って、確か1年でしたよね」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……それが終わったら、あなたはまた別のオフィスに行くんですか？ ……それとも、また自宅に戻るんですか？」" +
				"[NEXT]" +
				"[NAME:NONE]モニターから目を逸らしたまま呟くその声は、どこか心細げで、微かな寂しさを帯びているように聞こえた。"
			);
			data.setChoice1Text("延長しようかな。サユキさんが寂しがるし");
			data.setChoice2Text("オンラインで技術サポートは続けるよ");
			data.setChoice3Text("そうだね。まあそういう働き方だから");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「さ、寂しくなんかないです！ 自惚れないでください！」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……ただ、あなたがいなくなると、デバッグ作業が遅れて非効率的になるから……。……だから、居てくれた方が、少しだけ助かりますけど……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は顔を逸らしながら、必死に『仕事上のメリット』を盾にして引き止めてきた。素直になれないその不器用さが、たまらなく愛おしい。"
			);
			data.setC1Love(5); data.setC1Like(1); // 【Love最大】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……まあ、そうですね。優秀な技術顧問を完全に失うのは痛手ですから。それが一番合理的です」" +
				"[NEXT]" +
				"[NAME:NONE]少しだけ寂しそうだったが、仕事仲間としての現実的な繋がりを確認し合えたことで、彼女も納得したようだ。"
			);
			data.setC2Love(1); data.setC2Like(4); // 【Like寄り】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……あなたって、本当にドライですよね。別に、どうでもいいですけど。ただの同居人ですし」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は唇を強く噛み締め、無理に強がってみせた。少し冷たすぎたかもしれない。"
			);
			data.setC3Love(-3); data.setC3Like(-1);
			break;

		case 13: // 【ケース13：無防備な距離感と意識】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:SAYUKI]「" + pName + "さん、ここのUIの挙動、アニメーションが少し重いでしょうか……？」" +
				"[NEXT]" +
				"[NAME:NONE]画面のプレビューを見せるため、サユキがキャスター付きの椅子ごとすり寄ってきた。少し身を乗り出せば、肩が触れ合いそうなほどの距離だ。" +
				"[NEXT]" +
				"[NAME:PLAYER]（本人は画面のことで頭がいっぱいで気づいていないようだが……ほのかに甘いシャンプーの香りが鼻腔をくすぐり、思わず意識してしまう）"
			);
			data.setChoice1Text("近すぎるよ。離れないと見えにくい");
			data.setChoice2Text("（無言で、少しだけ彼女の方へ顔を寄せる）");
			data.setChoice3Text("挙動は重くないけど、画像の容量が大きいね");

			data.setRes1(
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……っ、すみません。パーソナルスペース、踏み越えましたね……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女はハッとして、弾かれたように慌てて椅子を遠ざけた。拒絶されたと感じて、深く傷ついてしまったようだ。"
			);
			data.setC1Love(-2); data.setC1Like(-1); // 【失敗】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！？ あ、あの、近、いです……っ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……な、何考えてるんですか。……バカ。……私じゃなくて、ちゃんとコード、見てくださいよ……」" +
				"[NEXT]" +
				"[NAME:NONE]こちらの意図的な距離の詰めに気づいたのか、彼女は肩をビクッと震わせ、顔を真っ赤にして固まってしまった。潤んだ瞳がこちらを責めるように見上げている。"
			);
			data.setC2Love(5); data.setC2Like(0); // 【Love最大】意識させる

			data.setRes3(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「本当ですか？ よかった……！ じゃあ、画像は後で圧縮ツールにかけて調整してみますね！」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は問題が解決したことで嬉しそうに微笑み、距離が近いことには全く気づかないまま元の席へ戻っていった。"
			);
			data.setC3Love(1); data.setC3Like(3); // 【Like寄り】
			break;

		case 14: // 【ケース14：仕事仲間へのほんの少しの嫉妬】
			data.setVisuals(new VisualBeans("Sayuki_jitome.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]作業の合間、スマホにフリーランスの仕事仲間（女性）から『この前の案件助かりました！また飲みに行きましょう笑』とメッセージが届いた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（気さくな人だな、と思わず画面を見てクスッと笑ってしまった、その時）" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……なんなんですか。随分と楽しそうですね、そのメッセージ」" +
				"[NEXT]" +
				"[NAME:NONE]サユキがジト目でこちらのスマホの画面を睨みつけている。まるで自分のテリトリーを脅かされた猫のように、非常に不機嫌そうだ。"
			);
			data.setChoice1Text("ただのクライアントからの業務連絡だよ");
			data.setChoice2Text("サユキさんには関係ないでしょ");
			data.setChoice3Text("なんで？ もしかしてヤキモチ焼いてる？");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「ふーん……。まあ、仕事のやり取りならいいですけど。ここは遊び場じゃないので、私語は慎んでくださいね」" +
				"[NEXT]" +
				"[NAME:NONE]納得はしたようだが、まだ少し疑っているような目をしている。とりあえず嵐は過ぎ去ったようだ。"
			);
			data.setC1Love(1); data.setC1Like(2);

			data.setRes2(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……っ。そうですね、私には関係ないです。仕事の邪魔してすみませんでした」" +
				"[NEXT]" +
				"[NAME:NONE]声のトーンが急激に下がり、完全にそっぽを向かれてしまった。かなり根に持たれそうだ。"
			);
			data.setC2Love(-3); data.setC2Like(-2);

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！！ や、ヤキモチなんて焼いてませんっ！ 自意識過剰のバグでも発生してるんですか！？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「ただ、仕事中に他の女の人からの連絡でニヤニヤしてるのが不気味だっただけで……！ もう、知りません！」" +
				"[NEXT]" +
				"[NAME:NONE]図星を突かれたのか、彼女はムキになって早口で否定したが、手元のペンは完全に止まり、耳の先まで真っ赤に染まっていた。"
			);
			data.setC3Love(4); data.setC3Like(-1); // 【Love最大】嫉妬からの照れ隠し
			data.setRes3Visuals(new VisualBeans("Sayuki_mesorasi.png", bgDay, "cross_fade", "close_up", "day"));
			break;

		default:
			return super.getScenario(0, pName);
		}
		return data;
	}
}