package sayukiGame.model.bo.scnarioDataIvent;

import sayukiGame.model.beans.Sayuki_Sakota;
import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;

public class Ivent_Spring {

	public ScenarioData getScenario(int step, String pName, Sayuki_Sakota s) {
		ScenarioData data = new ScenarioData();
		data.setPoolType("Event");
		
		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 

		switch (step) {
		case 1: // 【起】待ち合わせと情景描写
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(				
				"【🌸 春 特別イベント：桜舞う木の下で】<br><br>" +
				"※イベントルール：あなたの選択肢によって、Love/Likeパラメータがリアルタイムに変動します。<br>" +
				"さらに最終ステージで合計スコアが高ければ、現在低い方のステータスにボーナスが加算されます！<br><br>" +
				"[NEXT]" +
				"[NAME:NONE]4月中旬。アトリエに籠もりきりの日々に区切りをつけるため、俺とサユキさんは新しい参考書とUI用の機材を買いに、少し離れた街まで出かけていた。" +
				"[NEXT]" +
				"[NAME:NONE]両手いっぱいの荷物を抱え、アトリエへの帰り道にある大きな公園を通りかかると、頭上には満開の桜がこれでもかと咲き誇っていた。<br>" +
				"心地いい春風が吹くたび、ピンク色の花びらが雪のように舞い踊る。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……はぁ。ちょっと歩き疲れました。少し、あのベンチで休憩していきませんか？」" +
				"[NEXT]" +
				"[NAME:NONE]いつもは作業着のサユキさんだが、今日は春らしい薄手のカーディガンを羽織っている。風に揺れる髪を耳にかけながら、彼女は桜を見上げた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……綺麗ですね。アトリエの窓から見るのとは、全然違います。……誘ってくれて、ちょっとだけ感謝してます」"
			);
			data.setChoice1Text("サユキさんと一緒なら、買い出しも楽しいよ（Love大幅アップ）");
			data.setChoice2Text("これでさらに開発の効率がグッと上がるね（Like大幅アップ）");
			data.setChoice3Text("荷物が重いから、早く休まずに帰ろう（Bad）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「な、何言ってるんですか……っ！？ べ、別にこれはただの機材の買い出し、つまり仕事の一環です！ 変な意味で捉えないでくださいっ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも、その……あなたにそう言われるの、不快じゃ……ない、です。……うぅ、今のナシ！ 忘れてください！」" +
				"[NEXT]" +
				"[NAME:NONE]限界まで顔を真っ赤にしてドリンクの缶で顔を隠す彼女。不器用な照れ方が最高に可愛かった。"
			);
			
			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「ふふ、そうですね！ 新しい機材のスペックなら、UIのレンダリング速度も1.5倍は早くなるはずです」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「この満開の桜並木を見て、新しい演出のカラーパレットのインスピレーションも湧きました。アトリエに戻ったら、すぐに画面設計のロジックに組み込みましょう！」" +
				"[NEXT]" +
				"[NAME:NONE]お互いのクリエイター精神が刺激され、仕事の最高の相棒としての熱い連帯感が胸に宿った。"
			);
			
			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。そうですね。あなたに無理やり荷物を持たせて、立ち止まらせて悪かったです」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「私のワガママでした。休憩は終わりです。さっさとアトリエに戻って作業を再開しましょう」" +
				"[NEXT]" +
				"[NAME:NONE]サユキさんはスッと冷たい表情に戻り、ベンチから立ち上がってしまった。距離を遠ざけてしまったようだ。"
			);

			data.setC1Love(3); data.setC1Like(1);
			data.setC2Love(1); data.setC2Like(3);
			data.setC3Love(0); data.setC3Like(0);
			break;

		case 2: // 【承】髪についた桜の花びら
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]ベンチの荷物を整理し、自販機で買った冷たい飲み物を手渡すと、サユキさんはふぅと小さく息を吐いて喉を潤した。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「ぷはっ……生き返りました。……あ、そんなに見つめてどうしたんですか？ 私の顔に何か付いてます？」" +
				"[NEXT]" +
				"[NAME:NONE]見ると、さっきの風で舞った桜の花びらが、彼女の艶やかな黒髪のてっぺんにちょこんと乗っかっていた。<br>" +
				"本人は全く気付いていないようで、不思議そうにこちらを覗き込んでいる。"
			);
			data.setChoice1Text("（無言で頭に手を伸ばし、花びらを取ってあげる）（Love大幅アップ）");
			data.setChoice2Text("サユキさん、頭に可愛い桜の髪飾りが付いてるよ（Like大幅アップ）");
			data.setChoice3Text("頭にゴミが付いてるよ、みっともないな（Bad）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「っ！？ ……あ……」" +
				"[NEXT]" +
				"[NAME:NONE]不意に顔が近づき、俺の指先が彼女の髪に触れた瞬間、サユキさんは借りてきた猫のように完全に硬直してしまった。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……あ、あの、距離が近いです……っ。心臓に悪いから、触る時は、ちゃんと言ってください……バカ」" +
				"[NEXT]" +
				"[NAME:NONE]俺の手のひらの上の花びらを見ると、彼女は耳まで真っ赤にして俯き、長いまつ毛をパチパチと揺らしていた。"
			);
			
			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「か、髪飾り……っ！？ 私がそんなファンシーなもの付けるわけないでしょ……！」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……って、あ、これ、桜の花びらですか。ふふ、からかわないでください。でも、画面のデバッグばかりの毎日に、こういう『自然のオブジェクト』が交ざるのも……まあ、悪くない変化ですね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は自分の頭をちょこちょこと触りながら、いたずらが成功したかのように嬉しそうに微笑んだ。"
			);
			
			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……ゴミって何ですか、ゴミって。風情のない人ですね」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「これは散った桜の花びらです！ バグとゴミしか頭にないんですか？ あなたって本当に、たまに冷酷なコンパイラみたいになりますよね」" +
				"[NEXT]" +
				"[NAME:NONE]ムキになって怒らせてしまった。彼女はプイと横を向いて、ストローをきつく噛み締めている。"
			);

			data.setC1Love(3); data.setC1Like(1);
			data.setC2Love(1); data.setC2Like(3);
			data.setC3Love(0); data.setC3Like(0);
			break;

		case 3: // 【転】二人のこれまでとサユキの本音
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]花びらが舞い散る中、サユキさんは缶を両手で包み込みながら、ぽつりぽつりと語り始めた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……私、あなたをこのアトリエに呼ぶ前は、ずっと一人で画面に向かってたんです。<br>" +
				"自分の描いた絵が本当に面白いのか、バグだらけで動かなくなるんじゃないかって、毎晩不安で」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「でも、今は……隣の席から、あなたのキーボードを叩く音が聞こえるだけで、なんだかすごく、安心して作業に集中できるんです」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……これって、クリエイターとして、あなたを信頼しすぎちゃってる証拠なんでしょうか」"
			);
			data.setChoice1Text("クリエイターとしてだけじゃなく、もっと頼ってよ（Love大幅アップ）");
			data.setChoice2Text("俺も同じだよ。サユキがいるからコードが書ける（Like大幅アップ）");
			data.setChoice3Text("依存はよくないね。もっと自立した方がいいよ（Bad）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「ク、クリエイターとしてだけじゃなく、って……。それ以上に頼ったら、私……私じゃない何か別のバグを踏んじゃいそうです」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも。……本当に、どうしても仕様が分からなくて、泣きたくなった時は。……その時は、ちょっとだけ、女の子として……甘えても、いいですか？」" +
				"[NEXT]" +
				"[NAME:NONE]消え入りそうな声で呟く彼女の潤んだ瞳には、明らかな信頼以上の特別な感情が灯っていた。"
			);
			
			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「あなたも、同じ……ですか」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「ふふ、私たちのフロントエンドとバックエンドみたいに、お互いがなくてはならないミドルウェアになってるみたいですね。私たちの設計、バグなしの完璧なアーキテクチャですよ」" +
				"[NEXT]" +
				"[NAME:NONE]お互いの技術と存在価値を認め合う。クリエイターとしての魂が、これ以上ない深さでカチリと共鳴し合った。"
			);
			
			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……依存、ですか。正論ですね。耳が痛いです」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「プロとして、少し馴れ合いが過ぎました。今の発言はメモリから完全に消去（ガベージコレクション）してください。戻ります」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は冷たい表情の防壁を完璧に張り直してしまった。本音を言ってくれた彼女の心をシャットダウンさせてしまったようだ。"
			);

			data.setC1Love(3); data.setC1Like(1);
			data.setC2Love(1); data.setC2Like(3);
			data.setC3Love(0); data.setC3Like(0);
			break;

		case 4: // 【結①】夕暮れの肌寒さとアトリエへの帰還
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]気が付けば太陽は西の空へ傾き、公園の桜並木はオレンジ色の夕暮れに染まっていた。<br>" +
				"それと同時に、春特有の冷たい夜風が吹き抜け、桜の絨毯を激しく揺らす。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「くしゅんっ……！ ……ふぅ、急に冷え込んできましたね」" +
				"[NEXT]" +
				"[NAME:NONE]サユキちゃんは微かに肩を震わせ、カーディガンをきゅっと体に引き寄せた。<br>" +
				"アトリエまではまだ少し距離がある。風邪をひかせては大変だ。"
			);
			data.setChoice1Text("（自分の上着を脱いで、サユキの肩にかけてあげる）（Love大幅アップ）");
			data.setChoice2Text("寒くなってきたし、アトリエに戻って温かいココアでも飲もう（Like大幅アップ）");
			data.setChoice3Text("クリエイターは体が資本だから、気合で耐えてね（Bad）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「えっ、あ……！？ ちょ、ちょっと、何するんですか！ これじゃあなたが寒いでしょ！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも、すごく、温かいです。……。……じゃあ、アトリエに着くまで、お借りしますね。……なんだか、あなたの匂いがして、落ち着きます……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は俺の上着の襟元にふにゃっと顔を埋め、嬉しそうに小さな歩幅で隣を歩いた。距離が急接近したのを感じた。"
			);
			
			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「ココア、いいですね！ あなたがアトリエの給湯室で淹れてくれるココア、比率が絶妙で大好きなんです」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「早く戻って体を温めましょう。温まったら、さっき買った資料を広げて、エンドロールの実装ロジックを詰めちゃいましょう！」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は寒さを忘れたように元気な笑顔になり、俺と荷物を半分ずつ持ち直して、楽しげに歩き出した。"
			);
			
			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「気合、ですか……。あなた、デバッグのスパルタだけじゃなくて、私生活のマネジメントまでブラック企業なんですね」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「もういいです、あなたを待っていたら凍結エラーを起こします！ 先に走って帰りますから！」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は完全に怒ってしまい、夜風の中を一人でたたたっと走って帰ってしまった。完全にやらかした。"
			);

			data.setC1Love(3); data.setC1Like(1);
			data.setC2Love(1); data.setC2Like(3);
			data.setC3Love(0); data.setC3Like(0);
			break;

		case 5: // 【結②】結果発表
			if (s.getEventScore() >= 24) {
				if (s.getLikePoint() > s.getLovePoint()) {
					data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
					data.setMessage(					
						"[NAME:NONE]アトリエの玄関前。上着を返してくれる際、サユキちゃんが俺のシャツの袖をぎゅっと掴んで、上目遣いに呟いた。" +
						"[NEXT]" +
						"[IMG:Sayuki_mesorasi.png]" +
						"[NAME:SAYUKI]「……あの。これからは、仕事の話や参考書の買い出しの用事がない時でも……」" +
						"[NEXT]" +
						"[IMG:Sayuki_mesorasi.png]" +
						"[NAME:SAYUKI]「たまには、今日みたいに一緒に外の空気を吸いに……私を外へ、連れ出してくれますか……？」" +
						"[NEXT]" +
						"[NAME:NONE]（お出かけの大成功により、ただの仕事の相棒としてだけでなく、一人の異性としてもあなたのことを強く意識し始めた！：Loveボーナス +5）"
					);
					s.addLovePoint(5);
				} else {
					data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
					data.setMessage(						
						"[NAME:NONE]アトリエに戻り、温かいココアで乾杯した時、サユキちゃんが晴れやかな表情でこちらを真っ直ぐに見つめてきた。" +
						"[NEXT]" +
						"[IMG:Sayuki_nomal.png]" +
						"[NAME:SAYUKI]「" + pName + "さん。私、あなたと組めて本当に良かったです」" +
						"[NEXT]" +
						"[IMG:Sayuki_nomal.png]" +
						"[NAME:SAYUKI]「あなたが私のためにコードを書いてくれるから、私は世界一のゲームが描ける。これからも私の隣で、その腕を存分に振るってくださいね、相棒」" +
						"[NEXT]" +
						"[NAME:NONE]（お出かけの大成功により、お互いの技術と人間性を認め合い、プロとしての絶対の絆が確立された！：Likeボーナス +5）"
					);
					s.addLikePoint(5);
				}
			} else {
				data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
				data.setMessage(
					"[NAME:NONE]アトリエへの帰り道。" +
					"[NEXT]" +
					"[IMG:Sayuki_dakara.png]" +
					"[NAME:SAYUKI]「……すっかり遅くなっちゃいましたね。明日からはまた遅れを取り戻すために、お互い作業に集中しましょう」" +
					"[NEXT]" +
					"[NAME:NONE]サユキちゃんはいつもの淡々とした仕事の態度に戻ってしまった。せっかくの春のお出かけだったが、少し距離を遠ざけてしまったかもしれない……。（ボーナスなし）"
				);
			}
			
			data.setChoice1Text("日常に戻る"); data.setChoice2Text("日常に戻る"); data.setChoice3Text("日常に戻る");
			data.setRes1(""); data.setRes2(""); data.setRes3("");
			break;
		}
		return data;
	}
}