package sayukiGame.model.bo.scnarioDataLike;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;
import sayukiGame.model.bo.scnarioDataCommon.Phase4;

public class LikePhase4 extends Phase4 {

	@Override
	public ScenarioData getScenario(int num, String pName) {
		
		// 0〜8 が選ばれた場合は、親クラス（Common）の共通の日常会話をそのまま呼び出す
		if (num <= 8) {
			return super.getScenario(num, pName);
		}

		// 9〜14：Likeルート専用（代えのきかない絶対的な仕事のパートナー）
		ScenarioData data = new ScenarioData();
		data.setPoolType("Like");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 
		
		switch (num) {
		case 9: // 【ケース9：主人公のピンチと意外な助っ人】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]深夜。俺は自分の仕事で、急遽発生した大量の画像リサイズと加工処理に追われ、頭を抱えていた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（くそっ、プログラムで一括処理できない特殊なトリミング指定ばかりだ……。これじゃ徹夜しても終わらないぞ）" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……うるさいです。さっきから舌打ちとため息がBGMになってますよ」" +
				"[NEXT]" +
				"[NAME:NONE]サユキが自分の作業の手を止め、椅子を回してこちらを見ていた。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……画像の加工なら、私が持ってるPhotoshopのマクロとスクリプトを組み合わせれば、手作業の10倍の速度で終わりますけど。……やりますか？」"
			);
			data.setChoice1Text("バッチ処理でなんとかするから大丈夫");
			data.setChoice2Text("じゃあ、少しだけ甘えようかな");
			data.setChoice3Text("ありがとう。この恩は必ず技術で返すよ");

			data.setRes1(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……変な意地を張って納期を落としたら、プロ失格ですよ。勝手にしてください」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は呆れたように自分の画面に向き直った。助け舟を無下にしてしまった。"
			);
			data.setC1Love(-1); data.setC1Like(-3); // 【失敗】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……甘えるって。別にあなたを助けたいわけじゃなくて、あなたの放つ負のオーラが私の作業に悪影響だから……」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:NONE]文句を言いながらも、彼女は手早く俺のデータを自分の環境に移行し、あっという間に処理を終わらせてくれた。"
			);
			data.setC2Love(4); data.setC2Like(0); // 【Love寄り】

			data.setRes3(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ええ、そうしてください。ギブアンドテイクです。私のゲームのサーバー構築、タダでやってもらいますからね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は不敵に笑い、プロのツールであっという間に俺の仕事を片付けてくれた。最高のビジネスパートナーだ。"
			);
			data.setC3Love(1); data.setC3Like(5); // 【Like最大】プロとしての貸し借り
			break;

		case 10: // 【ケース10：プロフェッショナルの衝突】
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]サユキのゲームの仕様について、俺たちはお互いの画面を見せ合いながら激しく意見を衝突させていた。" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……ですから！ このアニメーションを削ったら、UIの爽快感が完全に死にます！ 絶対に譲れません！」" +
				"[NEXT]" +
				"[NAME:PLAYER]「でも、今のアーキテクチャでそれを実装すると、メモリを食いすぎて古い端末でクラッシュするんだ。エンジニアとしてそれは見過ごせない」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「っ……。じゃあ、どうしろって言うんですか……」"
			);
			data.setChoice1Text("俺が折れるよ。サユキさんの絵が最優先だ");
			data.setChoice2Text("アニメーションの軽量化ライブラリを探そう");
			data.setChoice3Text("いや、システム的に無理なものは無理だ");

			data.setRes1(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……は？ なんでそこで折れるんですか。クラッシュするなら意味ないじゃないですか」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「私が求めているのはご機嫌取りじゃなくて、技術的な解決策です。失望させないでください」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は冷たい目で俺を睨んだ。プロとしての意見のぶつかり合いから逃げてはいけなかった。"
			);
			data.setC1Love(1); data.setC1Like(-4); // 【大失敗】プロの放棄

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……軽量化、ですか。……画質とフレームレートは維持できますか？」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……分かりました。あなたがそこまで言うなら、そのライブラリの検証、一緒にやります」" +
				"[NEXT]" +
				"[NAME:NONE]お互いの妥協点ではなく『高み』を目指す解決策を提示したことで、彼女の信頼はさらに強固なものになった。"
			);
			data.setC2Love(1); data.setC2Like(5); // 【Like最大】

			data.setRes3(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……。あなたの技術力がその程度なら、もう結構です」" +
				"[NEXT]" +
				"[NAME:NONE]突き放したことで、彼女は完全に心を閉ざしてしまった。"
			);
			data.setC3Love(-3); data.setC3Like(-3); // 【失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_dakara.png", bgDay, "cross_fade", "close_up", "day"));
			break;

		case 11: // 【ケース11：限界突破の深夜作業】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]時刻は午前3時。二人とも別々の案件の締め切りに追われ、限界に近い状態でキーボードを叩いている。" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……っ。……目が、霞んできました……。でも、今日中にコンパイルを通さないと……」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女の顔色は明らかに悪い。だが、ここで変に同情するのは彼女のプライドを傷つける気がする）"
			);
			data.setChoice1Text("無理しないで。少し肩でも揉もうか？");
			data.setChoice2Text("よし、二人で朝まで倒れるまでやろう");
			data.setChoice3Text("俺が簡単な作業代わるから、少し寝なよ");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！ セクハラですか！？ こんな極限状態で何を考えてるんですか！」" +
				"[NEXT]" +
				"[NAME:NONE]激しく拒絶された。ただでさえ余裕がない時に、恋愛的なアプローチは完全に逆効果だった。"
			);
			data.setC1Love(-2); data.setC1Like(-4); // 【大失敗】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ふふっ。望むところです。あなたが倒れるのが先か、私が倒れるのが先か、勝負ですね」" +
				"[NEXT]" +
				"[NAME:NONE]限界の極地で、お互いに不敵な笑みを交わす。クリエイター同士の、狂気にも似た連帯感がそこにあった。"
			);
			data.setC2Love(1); data.setC2Like(5); // 【Like最大】戦友としての限界突破

			data.setRes3(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……私の仕事を奪わないでください。それに、あなたの案件も終わってないでしょう？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも、心配してくれたのは……ありがとうございます」" +
				"[NEXT]" +
				"[NAME:NONE]少しだけ空気が和らいだが、プロとしては甘やかすべきではなかったようだ。"
			);
			data.setC3Love(3); data.setC3Like(-1); // 【Love寄り】
			break;

		case 12: // 【ケース12：代えのきかない存在】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]サユキが、過去に外注のプログラマーに依頼したという古いゲームのソースコードを見ながら、ため息をついた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……ひどいスパゲティコード。変数名も適当だし、これでよく動いてましたね」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「これを見た後だと、" + pName + "さんが書くコードがいかにきれいで、無駄がないか痛感します」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女は他人の技術を滅多に褒めない。これは最大の賛辞だ）"
			);
			data.setChoice1Text("もっと褒めていいよ。気分がいい");
			data.setChoice2Text("俺もサユキさんのデザインが一番好きだよ");
			data.setChoice3Text("その評価に応えられるよう、これからも精進するよ");

			data.setRes1(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……調子に乗らないでください。あくまで『過去のひどいコードと比較してマシ』だと言っただけです」" +
				"[NEXT]" +
				"[NAME:NONE]ジト目で睨まれた。素直に受け取っておけばよかった。"
			);
			data.setC1Love(-1); data.setC1Like(-1); // 【失敗】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！ き、急に何を……っ。今はコードの話をしてるんです！」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は顔を赤くして視線を逸らした。好意は伝わったが、技術者としての会話は終わってしまった。"
			);
			data.setC2Love(4); data.setC2Like(-1); // 【Love寄り】

			data.setRes3(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ええ。期待していますよ、私の『専属』技術顧問さん」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は満足げに微笑んだ。お互いの実力を認め合い、高め合える最強の関係だ。"
			);
			data.setC3Love(2); data.setC3Like(5); // 【Like最大】
			break;

		case 13: // 【ケース13：完璧なルーティン】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]夕暮れ時。俺が疲れて目頭を揉んでいると、視界の端からスッと『微糖の缶コーヒー』が差し出された。" +
				"[NEXT]" +
				"[NAME:PLAYER]（……俺がいつも、この時間帯に淹れるのが面倒な時に飲むやつだ）" +
				"[NEXT]" +
				"[NAME:NONE]俺も無言で、彼女が夕方に必ず欲しがる『タブレット用のクリーニングクロス』をデスクの端に置いた。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……」" +
				"[NEXT]" +
				"[NAME:PLAYER]「……」"
			);
			data.setChoice1Text("言葉はいらないね");
			data.setChoice2Text("なんだか、長年連れ添った夫婦みたいだね");
			data.setChoice3Text("たまには違うコーヒーも飲みたいな");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ええ。お互いの生態系を完全に学習した結果の、最も合理的なリソース交換です」" +
				"[NEXT]" +
				"[NAME:NONE]言葉を交わさずとも、缶コーヒーを開ける音とクロスで画面を拭く音が、静かなアトリエに心地よく響いた。"
			);
			data.setC1Love(2); data.setC1Like(5); // 【Like最大】阿吽の呼吸

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「ふうふっ……！？ ～～っ！ ば、バカなこと言わないでください！ 気持ち悪いです！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……もう、明日からブラックコーヒー買ってきてやりますからね……っ」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は耳まで真っ赤にして怒った。プロとしての美しい沈黙を、自らぶち壊してしまった。"
			);
			data.setC2Love(5); data.setC2Like(-3); // 【Love最大・Like激減】

			data.setRes3(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……そうですか。じゃあ、明日からは自分で買いに行ってください」" +
				"[NEXT]" +
				"[NAME:NONE]せっかくの気遣いを無下にしてしまった。最悪の空気だ。"
			);
			data.setC3Love(-3); data.setC3Like(-3); // 【大失敗】
			break;

		case 14: // 【ケース14：専属顧問契約の打診】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]夜。サユキが自分の企画書を見ながら、少し言いにくそうに口を開いた。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……あの。" + pName + "さん」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「あなたの今のフリーランスの案件、もしこれから少し余裕ができたらでいいんですけど……」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「正式に、私の『専属技術顧問』として契約を結んでくれませんか。……もちろん、業務委託費は相場以上で払いますから」" +
				"[NEXT]" +
				"[NAME:PLAYER]（お金を払ってでも、俺を自分のプロジェクトに引き込みたいということか。クリエイターからの最大の評価だ）"
			);
			data.setChoice1Text("喜んで。最高のゲーム、一緒に完成させよう");
			data.setChoice2Text("お金はいらないよ。サユキさんと一緒にいたいから");
			data.setChoice3Text("悪いけど、俺は自分の仕事だけに集中したい");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！ ……はいっ！」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「覚悟してくださいね。プロの報酬に見合うだけの、過酷なタスクをバンバン投げつけますから」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は本当に嬉しそうに、不敵な笑みを浮かべた。互いの才能を認め合った、最強のパートナーの誕生だ。"
			);
			data.setC1Love(2); data.setC1Like(6); // 【Likeルートの大正解】次フェーズへの確定フラグ

			data.setRes2(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……そういう中途半端な同情はプロとして不快です。技術には対価を払うのが当然でしょう？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……まぁ、一緒にいたいと言ってくれたこと自体は、その……評価してあげなくもないですけど」" +
				"[NEXT]" +
				"[NAME:NONE]プロとしての提案を恋愛感情で返したため、呆れられてしまったが、彼女の顔は少し赤かった。"
			);
			data.setC2Love(6); data.setC2Like(-2); // 【Loveへの強烈なフラグ】Likeルートとしては不正解

			data.setRes3(
				"[IMG:Sayuki_scary_smile.png]" +
				"[NAME:SAYUKI]「……そうですか。分かりました。私にはあなたの時間を奪う権利はありませんから」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の声から一切の感情が消え失せた。完全にビジネス上の関係すらも断ち切ってしまったようだ。"
			);
			data.setC3Love(-5); data.setC3Like(-5); // 【致命的失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_scary_smile.png", bgNight, "cross_fade", "close_up", "night"));
			break;

		default:
			return super.getScenario(0, pName);
		}
		return data;
	}
}