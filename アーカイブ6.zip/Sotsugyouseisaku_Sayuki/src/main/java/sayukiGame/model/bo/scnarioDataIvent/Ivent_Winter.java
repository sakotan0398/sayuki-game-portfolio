package sayukiGame.model.bo.scnarioDataIvent;

import sayukiGame.model.beans.Sayuki_Sakota;
import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;

public class Ivent_Winter {

	public ScenarioData getScenario(int step, String pName, Sayuki_Sakota s) {
		ScenarioData data = new ScenarioData();
		data.setPoolType("Event");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 
		
		switch (step) {
		case 1: // 【起】冬の街角とイルミネーション
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(	
				"【⛄ 冬の特別イベント：聖夜のイルミネーション】<br><br>" +
				"※イベントルール：あなたの選択肢によって、Love/Likeパラメータがリアルタイムに変動します。<br>" +
				"さらに最終ステージで合計スコアが高ければ、現在低い方のステータスにボーナスが加算されます！<br><br>" +
				"[NEXT]" +
				"[NAME:NONE]12月下旬。マスターアップ目前の緊迫した時期だが、お互いのリフレッシュも兼ねて、俺とサユキさんは夜の街へ息抜きに出ていた。" +
				"[NEXT]" +
				"[NAME:NONE]吐く息は白く、凍えるような寒さだが、大通りの街路樹はどこまでも続く黄金色のイルミネーションで彩られ、道行く人々を暖かく照らしている。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……わぁ。すごい……。画面越しのパーティクルエフェクトじゃなくて、本物の光の粒みたい……」" +
				"[NEXT]" +
				"[NAME:NONE]厚手のコートに身を包み、マフラーに顔を半分埋めたサユキちゃんが、キラキラと輝く瞳で光のトンネルを見上げていた。"
			);
			data.setChoice1Text("イルミネーションより、今のサユキの方が綺麗だよ（Love大幅アップ）");
			data.setChoice2Text("この光の表現、エンディングの演出に活かせそうだね（Like大幅アップ）");
			data.setChoice3Text("寒いし人も多いから、早く通り抜けよう（Bad）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！？ ～～～っ！！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……マフラー巻いてきてよかったです。今の私の顔、絶対、バグみたいに真っ赤になってるはずだから……バカ」" +
				"[NEXT]" +
				"[NAME:NONE]マフラー越しでも分かるほど顔を赤らめ、彼女は俺の袖をきゅっと掴んだ。"
			);
			
			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……！ ふふ、さすがです。私も今、同じことを考えてました」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「この温かみのあるオレンジ色のパラメータ、絶対忘れないように脳に焼き付けて帰りますからね、相棒」" +
				"[NEXT]" +
				"[NAME:NONE]寒空の下でも、二人のクリエイターとしての波長は完璧にシンクロしていた。"
			);
			
			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……本当に、あなたって人は。少しは季節感というものをコンパイルしてください」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は呆れたようにため息をつき、少し距離を開けて歩き始めた。"
			);

			data.setC1Love(3); data.setC1Like(1);
			data.setC2Love(1); data.setC2Like(3);
			data.setC3Love(0); data.setC3Like(0);
			break;

		case 2: // 【承】かじかむ手と物理的な温もり
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(	
				"[NAME:NONE]光のトンネルを抜けた先の広場で、冷たい北風が強く吹き抜けた。" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……っ、寒……。手袋、持ってくるの忘れちゃいました」" +
				"[NEXT]" +
				"[NAME:NONE]サユキちゃんは両手を擦り合わせながら、白くかじかんだ指先にふーっと息を吹きかけている。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「あの、" + pName + "さん。……手が冷たすぎて、このままだと明日、キーボードもペンも握れなくなっちゃうかもしれないです……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は上目遣いで、チラチラとこちらの『手』と『ポケット』を交互に見つめてきた。明確なサインだ。"
			);
			data.setChoice1Text("（無言で、彼女の冷たい手をギュッと握る）（Love大幅アップ）");
			data.setChoice2Text("俺のコートのポケット、片方空いてるよ（Like大幅アップ）");
			data.setChoice3Text("自販機で温かい缶コーヒー買ってくるよ（Bad）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「っ……。……あ……」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……。……あったかいです。……もう、アトリエに着くまで、絶対に離してあげませんからね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は俺の手に自分の指を絡ませ、恋人のようにしっかりと握り返してきた。"
			);
			
			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「えっ……？ ポ、ポケットの中って、それじゃ完全に、手と手が、密着……」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも、遠慮しません。……お邪魔、します……っ。……すごく、温かいです」" +
				"[NEXT]" +
				"[NAME:NONE]俺のポケットの中で、彼女の冷たい手がそっと俺の手に重なった。特別な信頼を感じる温もりだった。"
			);
			
			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……ちがいます。私は缶コーヒーが握りたいわけじゃありません！」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「もういいです！ 自分で温めますから！」" +
				"[NEXT]" +
				"[NAME:NONE]不器用なサインを見逃してしまった。彼女はプイと横を向いてしまった。"
			);

			data.setC1Love(3); data.setC1Like(1);
			data.setC2Love(1); data.setC2Like(3);
			data.setC3Love(0); data.setC3Like(0);
			break;

		case 3: // 【転】一年の振り返りと終わりの予感
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(	
				"[NAME:NONE]広場のベンチに並んで座り、二人で温かいココアを分け合う。<br>" +
				"出会った春の頃のよそよそしさが嘘のように、今の俺たちは自然に肩を寄せ合っていた。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……なんだか、あっという間でしたね。春からずっと一緒にゲームを作ってきて……もうすぐ、本当に完成しちゃうんですね」" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「嬉しいはずなのに。最高の作品ができたのに。……なんだか少しだけ、胸の奥がチクチクします。……ゲームが完成したら、私たちはどうなるんでしょうか」"
			);
			data.setChoice1Text("どうもならないよ。これからもずっと一緒にいる（Love大幅アップ）");
			data.setChoice2Text("俺たちはこれからも、最高の開発パートナーだよ（Like大幅アップ）");
			data.setChoice3Text("契約終了だし、それぞれの道に進むだけだよ（Bad）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。ずっと、一緒……。……本当に？ 嘘ついたら、ソースコード全部消去しますからね？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……ふふ。信じます。……私から離れることなんて、絶対に許しませんから」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は俺の肩にコツンと頭を預け、幸せそうに目を閉じた。"
			);
			
			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「最高の、開発パートナー……。……そうですね。私たちの『連携』は、一つの作品が終わったくらいで途切れるような、ヤワな設計じゃありませんよね」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「これからも、私の隣の特等席で、私を支え続けてくださいね」" +
				"[NEXT]" +
				"[NAME:NONE]クリエイターとして、そして人間として、揺るぎない絶対の絆を確かめ合った。"
			);
			
			data.setRes3(
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……。……そう、ですよね。私たちはただの仕事仲間。……私が、勘違いしていただけです」" +
				"[NEXT]" +
				"[NAME:NONE]冷酷な事実を突きつけてしまった。彼女の表情は、冬の夜よりも冷たく沈んでしまった。"
			);

			data.setC1Love(3); data.setC1Like(1);
			data.setC2Love(1); data.setC2Like(3);
			data.setC3Love(0); data.setC3Like(0);
			break;

		case 4: // 【結①】帰る前の少しのわがまま
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(	
				"[NAME:NONE]空気がさらに冷え込んできた。そろそろアトリエに戻らなければ。" +
				"[NEXT]" +
				"[NAME:PLAYER]「そろそろ帰ろうか。あまり冷えると風邪を引くよ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「…………。……いや、です」" +
				"[NEXT]" +
				"[NAME:NONE]立ち上がろうとした俺のコートの裾を、サユキちゃんがギュッと強く握りしめて引き留めた。" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……アトリエに戻ったら、また『ゲーム開発者のサユキ』と『技術顧問の" + pName + "さん』に、戻っちゃう気がして。……だから、もう少しだけ……」"
			);
			data.setChoice1Text("じゃあ、もう少しだけ『一人の女の子』として甘えていいよ（Love大幅アップ）");
			data.setChoice2Text("アトリエに戻っても、俺たちはずっと特別な相棒だよ（Like大幅アップ）");
			data.setChoice3Text("わがまま言わないの。ほら、帰るよ（Bad）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「っ……！ ～～～っ、本当にあなたって人は……！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……言いましたね？ ……じゃあ、あと10分だけ。……このまま、抱きしめてて、ください……っ」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は限界まで赤くなった顔を俺の胸に押し付け、ぎゅっとしがみついてきた。愛おしさが爆発しそうだった。"
			);
			
			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……特別な、相棒……。……。……ふふ。そうでした。どこにいても、私たちは私たちでしたね」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ありがとうございます。おかげで、変なバグ（不安）が直りました。帰りましょう、私たちの居場所に」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は力強く頷き、俺の腕に腕を絡ませて歩き出した。強い信頼で結ばれた二人の足取りは軽かった。"
			);
			
			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……分かりましたよ。帰ればいいんでしょ、帰れば」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は乱暴に立ち上がり、ズンズンと一人で先に歩いて行ってしまった。"
			);

			data.setC1Love(3); data.setC1Like(1);
			data.setC2Love(1); data.setC2Like(3);
			data.setC3Love(0); data.setC3Like(0);
			break;

		case 5: // 【結②】結果発表
			if (s.getEventScore() >= 24) {
				if (s.getLikePoint() > s.getLovePoint()) {
					// 👉 仕事仲間（Like）寄りだった場合：Loveを底上げ
					data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
					data.setMessage(	
						"[NAME:NONE]アトリエへの帰り道。繋いだ手から伝わる温もりが、冷え切った体を芯から温めてくれる。" +
						"[NEXT]" +
						"[IMG:Sayuki_mesorasi.png]" +
						"[NAME:SAYUKI]「……あの。マスターアップが終わっても、またこうして……二人で、手を繋いで歩いてくれますか……？」" +
						"[NEXT]" +
						"[NAME:NONE]（冬のデートの大成功により、仕事の枠を完全に超え、一人の異性としての愛情が最高潮に達した！：Loveボーナス +5）"
					);
					s.addLovePoint(5); 
				} else {
					// 👉 恋愛（Love）寄りだった場合：Likeを底上げ
					data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
					data.setMessage(	
						"[NAME:NONE]アトリエへの帰り道。並んで歩く俺たちの歩幅は、示し合わせたようにピッタリと同じだった。" +
						"[NEXT]" +
						"[IMG:Sayuki_nomal.png]" +
						"[NAME:SAYUKI]「" + pName + "さん。私、来年も再来年も、ずっとあなたと一緒に最高のエンディングを作り続けたいです」" +
						"[NEXT]" +
						"[NAME:NONE]（冬のデートの大成功により、どんな壁も乗り越えられる、唯一無二のパートナーとしての絆が完成した！：Likeボーナス +5）"
					);
					s.addLikePoint(5); 
				}

			} else {
				// ❌ スコア不足
				data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
				data.setMessage(	
					"[NAME:NONE]アトリエへの帰り道。" +
					"[NEXT]" +
					"[IMG:Sayuki_dakara.png]" +
					"[NAME:SAYUKI]「……冷えちゃいましたね。早く戻って、温かいコーヒーでも飲みながら作業の続きをしましょう」" +
					"[NEXT]" +
					"[NAME:NONE]サユキちゃんは足早に歩き出してしまった。せっかくの冬のイルミネーションだったが、少し距離を遠ざけてしまったかもしれない……。（ボーナスなし）"
				);
			}
			
			data.setChoice1Text("日常に戻る"); data.setChoice2Text("日常に戻る"); data.setChoice3Text("日常に戻る");
			data.setRes1(""); data.setRes2(""); data.setRes3("");
			break;
		}
		return data;
	}
}