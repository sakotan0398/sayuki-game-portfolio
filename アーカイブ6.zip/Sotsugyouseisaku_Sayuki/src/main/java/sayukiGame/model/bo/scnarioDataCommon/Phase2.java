package sayukiGame.model.bo.scnarioDataCommon;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;

public class Phase2 {

	public ScenarioData getScenario(int num, String pName) {
		ScenarioData data = new ScenarioData();
		data.setPoolType("Common");

		// 💡 背景画像
		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 
		
		switch (num) {
		case 0: // 【ケース0：居眠りと無防備な境界線】
			data.setVisuals(new VisualBeans("Sayuki_mesorasi.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]昼下がりのオフィス。窓から差し込む陽光が、サユキのダボついたジャケットを白く照らしている。" +
				"[NEXT]" +
				"[NAME:PLAYER]（……ん？ タイピング音が止まってるな）" +
				"[NEXT]" +
				"[NAME:NONE]ふと隣を見ると、サユキがモニターを前にして、カクンカクンと舟を漕いでいた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（普段はあんなにピリピリしてるのに、寝顔は年相応というか……。完全に無防備だ）" +
				"[NEXT]" +
				"[NAME:NONE]その時、大きく首が揺れ、彼女は飛び起きるように目を開けた。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！ は、はいっ！ 起きてます！ バグは潰しましたっ！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……あ。……なんだ、" + pName + "さんですか。……今の、見てました？」"
			);

			data.setChoice1Text("顔でも洗ってきたら？（プロとして助言）");
			data.setChoice2Text("仕事中だぞ、集中しなよ（厳しく指摘）");
			data.setChoice3Text("無理しないで。俺の肩、貸そうか？（甘やかす）");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……そうですね。このままだとミスを連発しそうです。少し冷たい水で、脳内CPUを冷却してきます」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は自分の頬をパチンと叩き、洗面所へ向かった。適度な距離感でのアドバイスが、プロ意識の高い彼女には一番響いたようだ。"
			);
			data.setC1Love(1); data.setC1Like(3); // 【正解】信頼が大きく上がる

			data.setRes2(
				"[IMG:Sayuki_musu.png]" +
				"[NAME:SAYUKI]「……言われなくても分かってます。たった数秒、思考の海に潜っていただけです」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「あなたに監督される筋合いはありません。自分の進捗を心配したらどうですか？」" +
				"[NEXT]" +
				"[NAME:NONE]言い返されてしまった。正論すぎると、彼女のプライドを傷つけてしまうらしい。"
			);
			data.setC2Love(-1); data.setC2Like(0); // 【停滞】

			data.setRes3(
				"[IMG:Sayuki_scary_smile.png]" +
				"[NAME:SAYUKI]「……は？ なんで私があなたの肩なんかで寝なきゃいけないんですか」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「眠気も吹き飛ぶくらい気持ち悪いです。……セクハラ、ですよね？ オーナーに報告案件ですよ、これ」" +
				"[NEXT]" +
				"[NAME:NONE]親密になろうとしたが、完全に逆効果だった。彼女にとって、ここはまだ『神聖な職場』なのだ……。"
			);
			data.setC3Love(2); data.setC3Like(-3); // 【ハイリスク】好感度は上がるが、信頼がガタ落ちする
			data.setRes3Visuals(new VisualBeans("Sayuki_scary_smile.png", bgDay, "cross_fade", "close_up", "day"));
			break;

		case 1: // 【ケース1：プログラミングの迷宮とプライド】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]夕暮れ時のオフィスに、サユキが激しくマウスをカチカチと連打する音が響く。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……っ。なんで。なんでここでエラーが吐き出されるのよ……」" +
				"[NEXT]" +
				"[NAME:NONE]サユキは何度もリファレンスサイトと自分の汚いコードを往復している。モニターに反射する彼女の瞳には、明らかな焦りの色があった。" +
				"[NEXT]" +
				"[NAME:PLAYER]（最初の頃なら隠してただろうけど……今は俺の前でも悩みを隠さなくなってきたな）"
			);

			data.setChoice1Text("プロの俺が、特別に見てあげようか？");
			data.setChoice2Text("どのあたりで詰まってるの？（並走する）");
			data.setChoice3Text("ググり方が甘いんじゃない？（突き放す）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「プロ……。……っ、そうでしたね。あなたはこれでお金を貰ってるんでした」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……じゃあ、その。……お言葉に甘えてもいいですか？ ここのループ処理なんですけど……」" +
				"[NEXT]" +
				"[NAME:NONE]少し悔しそうに、だが明確な『敬意』を持って、彼女は画面をこちらに向けてきた。"
			);
			data.setC1Love(1); data.setC1Like(4); // 【Like特化】エンジニアとしての威厳を見せた
			data.setRes1Visuals(new VisualBeans("Sayuki_mesorasi.png", bgSunset, "cross_fade", "normal", "sunset"));

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ありがとうございます。ここの、条件分岐がどうしても矛盾しちゃって」" +
				"[NEXT]" +
				"[NAME:NONE]二人で画面を覗き込み、解決策を探る。自然と顔が近づき、彼女の微かな香りが鼻をくすぐった。" +
				"[NEXT]" +
				"[NAME:PLAYER]（……サユキも、少しは俺を頼ってくれるようになったんだな）"
			);
			data.setC2Love(3); data.setC2Like(1); // 【Love特化】協力作業で距離が縮まった
			data.setRes2Visuals(new VisualBeans("Sayuki_nomal.png", bgSunset, "cross_fade", "normal", "sunset"));

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。そんなマウントを取るためだけに口を開いたんですか？ 暇なんですね」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「死ぬ気で検索してますよ。……いいです、自分でやりますから。話しかけないで」" +
				"[NEXT]" +
				"[NAME:NONE]本気で軽蔑の眼差しを向けられた。プロとして最悪の回答をしてしまったらしい。"
			);
			data.setC3Love(-3); data.setC3Like(-3); // 【大失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_jitome.png", bgSunset, "cross_fade", "close_up", "sunset"));
			break;

		case 2: // 【ケース2：深夜のコード・リスペクト】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]時計の針がテッペンを超えた。アトリエには青白いモニターの光だけが満ちている。" +
				"[NEXT]" +
				"[NAME:NONE]サユキが、俺が昨日プッシュしたコードのドキュメントを読みながら、ポツリとこぼした。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……" + pName + "さんの設計、本当に……気持ち悪いほど綺麗ですね」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「無駄な計算が一切なくて、まるで数学の証明を見ているみたいです。……正直、驚きました」" +
				"[NEXT]" +
				"[NAME:PLAYER]（あのサユキが、ここまで素直に俺の技術を称賛してくるとは……！）"
			);

			data.setChoice1Text("その言葉、最高の褒め言葉だよ");
			data.setChoice2Text("サユキさんの色彩感覚こそ天才的だよ");
			data.setChoice3Text("この二人なら、世界を驚かせられるね");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「ええ。エンジニアにとって、効率化は正義でしょう？」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「私もイラストのレイヤー構成には自信がありますけど……。……完敗、かもしれませんね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は満足げに頷いた。プロ同士としての確固たる信頼の絆が結ばれた瞬間だった。"
			);
			data.setC1Love(1); data.setC1Like(4); // 【Like特化】技術者同士の共鳴

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！ ……急に、私の絵の話なんてしてないでしょう」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……からかわないでください。あなたのコードに感動してた自分がバカみたいじゃないですか……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は顔を赤らめ、ヘッドホンを深く被り直した。恋愛的な空気にはなったが、仕事の話を流したことに少し不満があるようだ。"
			);
			data.setC2Love(4); data.setC2Like(0); // 【Love特化】
			data.setRes2Visuals(new VisualBeans("Sayuki_mesorasi.png", bgNight, "cross_fade", "normal", "night"));

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「世界を、驚かせる……？」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ふふっ。大きく出ましたね。でも、私たちのスキルが本当に組み合わさったら……」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……不可能じゃないかも、しれません。ふふ、楽しみですね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は不敵に微笑んだ。お互いの夢がリンクし、関係が一歩先に進んだ気がした。"
			);
			data.setC3Love(2); data.setC3Like(2); // 【バランス正解】夢の共有
			break;

		case 3: // 【ケース3：夕暮れの感傷と作業音】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]オフィス全体がオレンジ色に焼けている。外から聞こえる遠い喧騒が、室内の静寂を際立たせていた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「もう夕方……。……不思議ですね」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「あんなに煩わしいと思っていたあなたのキーボードの音が、今は……少しだけ、落ち着く気がします」" +
				"[NEXT]" +
				"[NAME:PLAYER]（サユキの横顔が、夕日に照らされて少し柔らかく見える）"
			);

			data.setChoice1Text("作業効率が上がっている証拠だね");
			data.setChoice2Text("俺のタイピング音、録音して配布しようか？");
			data.setChoice3Text("ずっとこのまま、二人で作業していたいな");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「ふふ、そうかもしれませんね。ゾーンに入りやすくなったのは確かです」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……感謝してください。あなたが作業しやすいように、私が空気を調整してあげてるんですから」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は軽口を叩きながら、再びペンを走らせ始めた。最高の作業パートナーだ。"
			);
			data.setC1Love(1); data.setC1Like(3); // 【Like寄り】

			data.setRes2(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……いりません。調子に乗らないでください」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「あくまで、不快な騒音が『日常の背景音』に格下げされただけですから」" +
				"[NEXT]" +
				"[NAME:NONE]ジト目で睨まれたが、その声にトゲはなかった。彼女なりの照れ隠しなのだろう。"
			);
			data.setC2Love(2); data.setC2Like(1); // 【Love寄り】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「っ…………！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……っ。……バカじゃないですか、あなた。そんなこと、言ってどうするんですか」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……作業に戻ります。さっさと手を動かしてください。……バカ」" +
				"[NEXT]" +
				"[NAME:NONE]激しく動揺させすぎてしまった。彼女の顔は夕日の赤さよりもずっと赤くなっていた。"
			);
			data.setC3Love(5); data.setC3Like(-2); // 【Love最大 / Likeマイナス】重すぎる発言はプロとしての信頼を削る
			data.setRes3Visuals(new VisualBeans("Sayuki_mesorasi.png", bgSunset, "cross_fade", "close_up", "sunset"));
			break;

		case 4: // 【ケース4：不器用な糖分補給】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]サユキがもじもじしながら、ジャケットの大きなポケットをごそごそと探っている。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……あの。これ。……あげるわけじゃなくて、廃棄処分の押し付けなんですけど」" +
				"[NEXT]" +
				"[NAME:NONE]彼女が差し出してきたのは、高級そうなチョコレートの箱だった。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「糖分が足りないと、コードの論理構造も破綻するでしょう？ ……私の進捗に影響が出るので、食べてください」"
			);

			data.setChoice1Text("ありがとう。お返し、期待しててね");
			data.setChoice2Text("サユキさんが選んだの？ センスいいね");
			data.setChoice3Text("チョコより、カフェラテ淹れてよ");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「っ！ お、お返しなんていりません！ ……本当に、廃棄処分ですから！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも、まぁ。……どうしてもと言うなら、その。……トマト以外のお菓子なら、検討してあげなくもないです」" +
				"[NEXT]" +
				"[NAME:NONE]不器用な優しさに心が温まった。"
			);
			data.setC1Love(3); data.setC1Like(1); // 【Love寄り】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「ええ。デザイン性の高いパッケージですし、味も定評があります。……って、なんで私が選んだ前提なんですか！」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……まぁ、そうですよ。……仕事ができる人間には、それ相応の燃料が必要だと思っただけです」" +
				"[NEXT]" +
				"[NAME:NONE]彼女なりの、エンジニアとしての俺への評価なのかもしれない。"
			);
			data.setC2Love(1); data.setC2Like(3); // 【Like寄り】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……死ぬほど図々しいですね、あなた。……チョコ、返してください」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「やっぱりあなたにあげる糖分なんて、1ミリも存在しませんでした」" +
				"[NEXT]" +
				"[NAME:NONE]好意を台無しにしてしまった。彼女の機嫌は一気に氷点下まで逆戻りした。"
			);
			data.setC3Love(-2); data.setC3Like(-2); // 【大失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_jitome.png", bgDay, "cross_fade", "close_up", "day"));
			break;
		case 5: // 【ケース5：デスクの領土問題と資料の山】
			data.setVisuals(new VisualBeans("Sayuki_jitome.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]サユキのデスクが、描きかけのスケッチや設定資料、専門書で溢れかえっている。" +
				"[NEXT]" +
				"[NAME:NONE]その一部が境界線を越え、俺のキーボードのすぐ近くまで浸食してきていた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（……さすがにこれは邪魔だな。サユキさんは描くのに夢中で気づいてないみたいだけど）" +
				"[NEXT]" +
				"[NAME:PLAYER]「サユキさん、資料がこっちまで溢れてるよ。少し片付けようか？」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「っ！ ……あ。すみません、つい。……でも、今は手が離せないんです」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「どこに何があるか分からなくなるので、勝手に触らないでくださいね。……いいですね？」"
			);

			data.setChoice1Text("整理を手伝うよ（バディとして協力）");
			data.setChoice2Text("散らかってる方が天才っぽくていい（肯定）");
			data.setChoice3Text("管理人がこれじゃ困るな（厳しく指摘）");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……じゃあ、その。そっちの資料を、このクリアファイルにまとめてもらえますか？」" +
				"[NEXT]" +
				"[NAME:NONE]二人で黙々と整理を進める。彼女の思考の断片に触れた気がして、チームとしての連帯感が強まった。"
			);
			data.setC1Love(1); data.setC1Like(3); // 【Like特化】作業効率を優先

			data.setRes2(
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……変な励まし方をしないでください。……嫌味じゃなければ、いいですけど」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は少し呆れたような顔をしたが、心なしか表情が和らいだ。だらしない自分を許容された安心感があったようだ。"
			);
			data.setC2Love(3); data.setC2Like(-1); // 【Love特化】甘やかすとプロとしての締まりはなくなる

			data.setRes3(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……分かってます。後でやりますよ。……そんなに小言を言われるなら、やっぱりパーテーション立てます？」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は不機嫌そうに資料を端に寄せ、壁を作るように作業に戻ってしまった。"
			);
			data.setC3Love(-2); data.setC3Like(1); // 【停滞】
			break;

		case 6: // 【ケース6：ブルーライトと瞳のケア】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]夕方。サユキが何度も瞬きをし、目頭を指で押さえている。" +
				"[NEXT]" +
				"[NAME:PLAYER]（朝からずっとモニターを見続けてるからな。……瞳が少し充血してる気がする）" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……うぅ、画面の白が目に刺さる……。でも、輝度を下げると色の正確性が……」" +
				"[NEXT]" +
				"[NAME:PLAYER]（クリエイター特有の悩みだな。エンジニアの俺から何か言えることは……）"
			);

			data.setChoice1Text("PCの夜間モード設定を勧める（技術的解決）");
			data.setChoice2Text("蒸気で温めるアイマスクを渡す（物理的ケア）");
			data.setChoice3Text("若いのに疲れ目？ おばあちゃんかよ（弄る）");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……カラープロファイルを維持したままブルーライトをカットするソフト？ そんなのあるんですか？」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……助かりました。流石プロのエンジニアですね。道具の使いこなし方は参考になります」"
			);
			data.setC1Love(0); data.setC1Like(4); // 【Like最大】エンジニアとしての知識を披露

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……えっ。あ、ありがとうございます。……コンビニで買ってきたんですか？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……。１０分だけ、休憩します。……これ、ラベンダーのいい香りがしますね……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は少し照れながらアイマスクを着け、椅子に深く背を預けた。甘い空気が流れる。"
			);
			data.setC2Love(4); data.setC2Like(0); // 【Love最大】一人の女性としての気遣い

			data.setRes3(
				"[IMG:Sayuki_scary_smile.png]" +
				"[NAME:SAYUKI]「……。デリカシー、マザーボードのどこかに忘れてきたんですか？」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「あなたの冗談を聞くと、眼精疲労よりひどい頭痛がしてくるんです。黙っててください」"
			);
			data.setC3Love(-3); data.setC3Like(-2); // 【大失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_scary_smile.png", bgSunset, "cross_fade", "close_up", "sunset"));
			break;

		case 7: // 【ケース7：共有BGMの好みの不一致】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]サユキが片方のイヤホンを外し、こちらの様子を伺ってきた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「あの……" + pName + "さん。いつも無音で作業してますけど、退屈じゃないですか？」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「もし良ければ、私が今聴いているプレイリスト、スピーカーから流してもいいですけど」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女なりの歩み寄りだろうか。でも、音楽の好みで作業効率が変わるからな……）"
			);

			data.setChoice1Text("無音が一番集中できる（ストイック）");
			data.setChoice2Text("サユキさんのオススメが聴きたい（興味）");
			data.setChoice3Text("音が漏れててうるさいんだけど（苦情）");

			data.setRes1(
				"[IMG:Sayuki_musu.png]" +
				"[NAME:SAYUKI]「……。そうですか。ストイックというか、遊びがないというか……」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……いいですよ。私もイヤホンに戻ります。気が合わなくて残念です」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は少し意外そうな顔をしたが、お互いのスタイルの違いを尊重してくれたようだ。"
			);
			data.setC1Love(-1); data.setC1Like(2); // Likeは上がるが、心の距離は開く

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。こだわり強いですよ、私。……引かないでくださいね？」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は少し嬉しそうに端末を操作し始めた。流れてきたのは、アップテンポでエモーショナルな……魔法少女アニメの主題歌だった。" +
				"[NEXT]" +
				"[NAME:PLAYER]（サユキさんの意外な一面を知れた気がするな）"
			);
			data.setC2Love(3); data.setC2Like(1); // 【Love寄り】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。すみません、以後気を付けます。……もうイヤホン外しませんから」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は気まずそうに顔を伏せてしまった。冷たくしすぎたかもしれない……。"
			);
			data.setC3Love(-3); data.setC3Like(-3);
			break;

		case 8: // 【ケース8：深夜の糖分とブラックコーヒー】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]午前2時。アトリエには青白いモニターの光だけが満ちている。サユキが大きな欠伸をした。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……んっ……。流石にこの時間は、意識が遠のきますね……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は机に置いてある、冷え切った真っ黒なコーヒーを一口飲んだ。……直後、あからさまに顔をしかめる。" +
				"[NEXT]" +
				"[NAME:PLAYER]（……サユキさん、さっきから無理してブラック飲んでないか？）"
			);

			data.setChoice1Text("本当は苦いの苦手でしょ？（指摘）");
			data.setChoice2Text("温かいカフェラテ、淹れてこようか？（提案）");
			data.setChoice3Text("健康のために寝たほうがいい（正論）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ！？ ……っ、苦くなんてありません！ これがクリエイターの嗜みです！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……ただ、今日はちょっと豆のコンディションが悪かっただけで……」" +
				"[NEXT]" +
				"[NAME:NONE]図星だったようだ。必死に強がる姿が少し微笑ましい。"
			);
			data.setC1Love(2); data.setC1Like(0);

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「カフェ……ラテ……？」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……砂糖とミルク、たっぷりめでお願いします。……これは、あくまで低血糖を防ぐための戦略的摂取ですからね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は素直に俺の提案を受け入れた。深夜の連帯感が二人を包む。"
			);
			data.setC2Love(3); data.setC2Like(2); // 【バランス正解】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。分かってますよ、そんなこと。……もういいです。やる気失せました。寝ます」" +
				"[NEXT]" +
				"[NAME:NONE]せっかくの情緒ある空気を台無しにしてしまった。彼女を怒らせてしまったようだ。"
			);
			data.setC3Love(-1); data.setC3Like(-1);
			break;

		case 9: // 【ケース9：作画崩壊のスランプ】
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]サユキが何度も「Ctrl + Z」を繰り返している。ペンを握る手に迷いが見えた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……ダメ。全然納得いかない。……何を描いても、嘘っぽく見える……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女はラフを全選択してデリートキーを押した。……画面が真っ白に戻る。" +
				"[NEXT]" +
				"[NAME:PLAYER]（かなり深刻なスランプみたいだ。プロの俺から見て、どう声をかけるべきか……）"
			);

			data.setChoice1Text("技術的な構図のミスを指摘する（論理的アドバイス）");
			data.setChoice2Text("外の空気でも吸いに行かない？（リフレッシュ）");
			data.setChoice3Text("サユキさんでも才能が枯れるんだね（挑発）");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……構図のパースがズレてる？ ……あ。本当だ。……ここをこうすれば……」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……。あなた、意外とよく見てるんですね。……プロのエンジニアの観察眼、少しだけ認めます」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は再びペンを走らせ始めた。プロとしての信頼が盤石なものになった。"
			);
			data.setC1Love(1); data.setC1Like(4); // 【Like特化】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「え……。散歩、ですか？ ……。……まあ、そうですね。このまま画面を見ていても発狂しそうですし」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……少しだけ、ですよ？ 迷子にならないように、隣、歩いてあげますから」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は立ち上がり、控えめに俺の服の袖を掴んだ。……心の壁が、大きく崩れた音がした。"
			);
			data.setC2Love(5); data.setC2Like(-1); // 【Love最大】

			data.setRes3(
				"[IMG:Sayuki_scary_smile.png]" +
				"[NAME:SAYUKI]「…………。死ねばいいのに」" +
				"[NEXT]" +
				"[NAME:NONE]最悪の失言だった。彼女の瞳からハイライトが消え、アトリエに死のような沈黙が訪れた……。"
			);
			data.setC3Love(-5); data.setC3Like(-5); // 【致命的失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_scary_smile.png", bgSunset, "cross_fade", "close_up", "sunset"));
			break;
		}

		return data;
	}
}