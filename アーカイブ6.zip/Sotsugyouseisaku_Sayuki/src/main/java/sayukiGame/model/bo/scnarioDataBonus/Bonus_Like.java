package sayukiGame.model.bo.scnarioDataBonus;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;

public class Bonus_Like {

	public ScenarioData getScenario(int step, String pName) {
		ScenarioData data = new ScenarioData();
		data.setPoolType("Bonus");

		// 後日談は選択肢なしの一本道で進める
		data.setChoice1Text("続きを読む ▼");
		data.setChoice2Text("続きを読む ▼");
		data.setChoice3Text("続きを読む ▼");
		data.setRes1(""); data.setRes2(""); data.setRes3("");

		String bgNight = "bg068n19201440.jpg";

		switch (step) {
		case 0: // 【起】次回作、深夜の開発佳境
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgNight, "fade", "normal", "night"));
			data.setMessage(
				"【🤝 Like End 後日談：背中を預ける最強の戦線】<br><br>" +
				"[NEXT]" +
				"[NAME:NONE]前作の記録的な大ヒットからしばらく経ち、俺たちのスタジオはさらなる高みを目指して次回作の大型プロジェクトを始動させていた。" +
				"[NEXT]" +
				"[NAME:NONE]時刻は深夜2時。静まり返ったアトリエの中で、俺の激しいタイピング音と、サユキの液晶ペンタブレットが擦れる小気味いい音だけが重なり合っている。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「よし……！ メインヒロインのカットインアニメーション、240フレーム分、すべてのキーフレームの打ち込みが完了しました！」" +
				"[NEXT]" +
				"[NAME:PLAYER]「タイミング完璧。バックエンド側のイベントトリガーの結合テストロジックも、たった今組み終わったところだ。ローカル環境でビルドするよ」"
			);
			break;

		case 1: // 【承】阿吽の呼吸、変態的最適化
			data.setMessage(
				"[NAME:NONE]キーボードのエンターキーを叩き、画面上でテスト用の戦闘シーンを再生する。" +
				"[NEXT]" +
				"[NAME:NONE]サユキが描いた圧倒的な密度のエフェクトが、俺の組んだ描画エンジンに乗って、一コマの引っかかりもなく滑らかに画面上を舞い踊った。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「……嘘。これだけ重いパーティクルを何千個もバラまいているのに、60fpsに張り付いたままビクともしない……！？」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png][NAME:SAYUKI]「やっぱりあなた、天才を通り越してただのコードの変態ですね！ 一体どういうメモリマネジメントをしたら、こんな芸芸当ができるんですか！？」" +
				"[NEXT]" +
				"[NAME:PLAYER]「サユキの最高のアートを1ピクセルも劣化させずに動かすのが、俺の存在価値だからな」"
			);
			break;

		case 2: // 【転1】最高のコーヒーブレイク
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgNight, "cross_fade", "close_up", "night"));
			data.setMessage(
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「ふふっ、本当に頼もしい相棒です。……よし、ビルドが通った記念に、10分だけコーヒーブレイクにしましょう」" +
				"[NEXT]" +
				"[NAME:NONE]サユキは立ち上がり、いつもの給湯室で少し濃いめのブラックコーヒーを二人分淹れて持ってきてくれた。" +
				"[NEXT]" +
				"[NAME:NONE]お互いのデスクの間に椅子を寄せ、温かいマグカップを傾けながら、ふぅと深く息を吐き出す。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「思えば、最初のゲームを作っていたあの1年間（52ターン）は、毎日がバグと仕様変更の戦争でしたね」" +
				"[NEXT]" +
				"[IMG:Sayuki_jitome.png][NAME:SAYUKI]「私がめちゃくちゃなグラフィックアセットを投げるたびに、あなたは『仕様書をコンパイルし直せ』って冷酷な顔で怒るし……」"
			);
			break;

		case 3: // 【転2】戦友としての絆
			data.setMessage(
				"[NAME:PLAYER]「あの時はサユキも、絶対に俺を自分のテリトリーに入らせないって、境界線のテープまで引いて尖ってたからな」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「っ！ そ、それは黒歴史ですから記憶のメモリから消去してくださいって言ったはずです……っ！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……でも。あなたが私のワガママや、絵に対する頑固さに最後まで妥協せず、技術で真っ向から殴り合ってくれたから」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「だから私は、自分の限界を遥かに超えた、世界一のゲームを描き切ることができたんです」" +
				"[NEXT]" +
				"[NAME:NONE]サユキはコーヒーを一口啜り、モニターに映る次回作のソースコードを、戦友を見つめるような熱い目で見つめた。"
			);
			break;

		case 4: // 【転3】サユキのバディ独占欲
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgNight, "fade", "normal", "night"));
			data.setMessage(
				"[IMG:Sayuki_dakara.png][NAME:SAYUKI]「前作のヒットの後、他の有名な開発スタジオから、あなたに引き抜きのスカウトメールが何通も届いてたの……実は知ってるんですよ？」" +
				"[NEXT]" +
				"[NAME:PLAYER]「え、知ってたのか。全部その場で即座に断ったけど」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「当然です！ あなたのあの変態的な最適化の技術を100%引き出して、ゲームという極上のエンターテインメントに昇華できるのは、世界中で私だけですからね」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png][NAME:SAYUKI]「一生、私のコードを書いてもらうって、打ち上げの日に約束したんです。誰にも、あなたを私の隣から奪わせません」" +
				"[NEXT]" +
				"[NAME:NONE]冗談めかしてはいるが、その言葉に含まれた信頼の重さは、生半可な恋愛感情よりも遥かに深く、強固なものだった。"
			);
			break;

		case 5: // 【転4】バディの境界線
			data.setVisuals(new VisualBeans("Sayuki_mesorasi.png", bgNight, "cross_fade", "close_up", "night"));
			data.setMessage(
				"[NAME:PLAYER]「わかってるよ。俺だって、サユキの描く世界以外のコードなんて、もう退屈で書く気にならない」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「っ……。な、なんですかそれ。……まるで、私以外の絵には興味がない、みたいじゃないですか」" +
				"[NEXT]" +
				"[NAME:PLAYER]「事実だよ。俺のエンジニアとしての魂は、サユキのアートに完全にハッキングされてるんだから」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「ハ、ハッキングって……！ ～～～っ！！」" +
				"[NEXT]" +
				"[NAME:NONE]仕事の話ならどれだけ強気でも、不意にこういう個人的な全幅の信頼をストレートにぶつけられると、彼女は一瞬で「クリエイターの顔」を崩してしまう。"
			);
			break;

		case 6: // 【結1】マグカップの距離
			data.setMessage(
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……あなたって、たまに狙い澄ましたクリティカルバグみたいな言葉を放ちますよね。コンパイルエラーで胸の奥がめちゃくちゃです……」" +
				"[NEXT]" +
				"[NAME:NONE]サユキは耳まで真っ赤にしながらマフラーに顔を埋め、照れ隠しにふいっと顔を背けた。" +
				"[NEXT]" +
				"[NAME:NONE]だが、並べられた二人のマグカップの距離は、出会った春の頃の何倍も、いや、数センチの隙間もないほど近くに触れ合っている。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……でも、いいです。それだけ私のクリエイティブに命を懸けてくれてるって証拠、ですから」"
			);
			break;

		case 7: // 【結2】最強の誓い
			data.setMessage(
				"[IMG:Sayuki_nomal.png eclipse]「" + pName + "さん。私たちは、ただの仲良しグループでも、馴れ合いの恋人でもありません」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「お互いの才能を誰よりも引き出し合い、背中を預けて世界に挑む、最強のバディ（相棒）です」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「この次回作が完成したとき、私たちはインディーゲーム界の新しい歴史を塗り替えることになります。……付いてきて、くれますね？」" +
				"[NEXT]" +
				"[NAME:PLAYER]「並んで走るさ。どこまでも、お前が描く未来の果てまで」"
			);
			break;

		case 8: // 【結3】徹夜のブースト開始
			data.setVisuals(new VisualBeans("Sayuki_dakara.png", bgNight, "cross_fade", "normal", "night"));
			data.setMessage(
				"[IMG:Sayuki_dakara.png][NAME:SAYUKI]「ふふ、最高の解答コードです！ さすが私の選んだメインエンジニア！」" +
				"[NEXT]" +
				"[NAME:NONE]サユキは空になったマグカップを置くと、バチンと自分のキーボードを叩くようにデスクを叩いて立ち上がった。" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png][NAME:SAYUKI]「休憩は終わり！ 脳のクロック数を限界まで引き上げて、デバッグの続きをやりますよ！ 朝までにアルファ版の全ステージ、チェック完了させます！」" +
				"[NEXT]" +
				"[NAME:PLAYER]「望むところだ。夜明けまでに、完璧なマスターデータをビルドして見せるよ」"
			);
			break;

		case 9: // 【終】ギャラリーへ戻る導線
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgNight, "fade", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]アトリエの夜はまだ明けない。だが、暗闇を照らす二つのモニターの光は、どんな星空よりも熱く未来を照らしていた。<br>" +
				"誰にも真似できない、俺たちだけの最高のアーキテクチャを、これからもアップデートし続けるために。" +
				"[NEXT]" +
				"[NAME:SYSTEM]（Like End 後日談 - 完）"
			);
			
			// 最終ページはボタンのテキストを「ギャラリーへ戻る」に変える
			data.setChoice1Text("ギャラリーへ戻る");
			data.setChoice2Text("ギャラリーへ戻る");
			data.setChoice3Text("ギャラリーへ戻る");
			break;
		}

		return data;
	}
}