package sayukiGame.model.bo.scnarioDataLove;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;
import sayukiGame.model.bo.scnarioDataCommon.Phase5;

public class LovePhase5 extends Phase5 {

	@Override
	public ScenarioData getScenario(int num, String pName) {
		
		// 0〜8 は親クラス（Common）の、仕事の追い込みや達成感の共有を呼び出す
		if (num <= 8) {
			return super.getScenario(num, pName);
		}

		// 9〜14：Loveルート専用（言い訳できなくなった好意と、溢れ出す感情）
		ScenarioData data = new ScenarioData();
		data.setPoolType("Love");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 

		switch (num) {
		case 9: // 【ケース9：俺の仕事の区切りと、彼女の不安】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]俺が受けていたフリーランスの大きな案件が、一つ無事に納品完了を迎えた。" +
				"[NEXT]" +
				"[NAME:PLAYER]「ふぅ……。ようやくこっちのプロジェクトも一段落だ」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……えっ。……終わったん、ですか？ あなたの仕事……」" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……。そう、ですか。……じゃあ、あなたの目標は一つ達成されたんですね。……よかったですね」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女はモニターから目を伏せ、ひどく心細そうな顔をした。俺の仕事が減ることで、この環境が変わってしまうとでも思ったのだろうか）"
			);
			data.setChoice1Text("でも、サユキさんのゲームが完成するまでは一緒にいるよ");
			data.setChoice2Text("やっと解放されるよ。長かった");
			data.setChoice3Text("仕事が減った分、もっとサユキさんを手伝えるよ");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……約束、ですよ？ 私のゲームのデバッグ、最後まで付き合ってもらうんですからね」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:NONE]彼女は少しだけホッとしたように息を吐き、俺の顔を盗み見た。仕事という大義名分に縋っている。"
			);
			data.setC1Love(3); data.setC1Like(3); // 【バランス正解】

			data.setRes2(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……そうですか。せいぜい自宅でゆっくり休めばいいじゃないですか」" +
				"[NEXT]" +
				"[NAME:NONE]冗談のつもりだったが、彼女は冷たく言い捨て、完全に背を向けてしまった。"
			);
			data.setC2Love(-4); data.setC2Like(-2); // 【失敗】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……。て、手伝うって……頼んでませんけど……っ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも。……そこまで言うなら、私の作業、手伝わせてあげなくもないです……」" +
				"[NEXT]" +
				"[NAME:NONE]顔を赤らめながらも、彼女は明確に俺の存在を求めてくれた。"
			);
			data.setC3Love(5); data.setC3Like(0); // 【Love最大】
			break;

		case 10: // 【ケース10：自販機での甘え】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]深夜。二人で廊下の自販機まで飲み物を買いに来た時のこと。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「…………」" +
				"[NEXT]" +
				"[NAME:PLAYER]（いつもなら冷たいコーヒーを買うサユキさんが、なぜか俺の服の袖を小さく引っ張ってきた）" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……あの。今日は、冷たいのじゃなくて……。……温かいココアが、いいです」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……その。……半分こ、しませんか。……一人じゃ、飲みきれないので……」"
			);
			data.setChoice1Text("間接キスになるけど、いいの？");
			data.setChoice2Text("俺がもう一つ買ってあげるよ");
			data.setChoice3Text("いいよ。温まろうか");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「っ……！ ～～～っ！」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……分かってて言ってますよね、あなた。……バカ。……いいから、早くボタン押してください……っ」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は顔を真っ赤にして俺をポカポカと叩いたが、提案を引っ込めることはしなかった。完全にデレている。"
			);
			data.setC1Love(5); data.setC1Like(-1); // 【Love最大】照れ隠し

			data.setRes2(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……。……そういうことじゃないんです。……いいです、やっぱり冷たいコーヒーにします」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の不器用な甘えを、実務的な気遣いで台無しにしてしまった。"
			);
			data.setC2Love(-3); data.setC2Like(1); // 【失敗】

			data.setRes3(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……はい。……ありがとうございます」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:NONE]二人で一つの温かい缶を交互に握りしめ、甘いココアを分け合った。夜の廊下に、優しい時間が流れた。"
			);
			data.setC3Love(4); data.setC3Like(2); // 【Love寄り・大正解】
			break;

		case 11: // 【ケース11：徹夜明けの無防備と、触れる距離】
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]明け方。サユキが自分のデスクに突っ伏して眠っていた。連日の追い込みで限界だったのだろう。" +
				"[NEXT]" +
				"[NAME:PLAYER]（パーカーが少しはだけて、華奢な肩が冷えそうだ。……風邪を引かれては困る）" +
				"[NEXT]" +
				"[NAME:NONE]俺はそっと自分の上着を彼女の肩に掛けようと、身を屈めた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……ん……。……" + pName + "、さん……」" +
				"[NEXT]" +
				"[NAME:NONE]寝言で俺の名前を呼んだ彼女の手が、無意識に俺の胸ぐらをきゅっと掴んだ。"
			);
			data.setChoice1Text("（そのまま、彼女の頭を優しく撫でる）");
			data.setChoice2Text("（そっと手を解いて、上着だけ掛ける）");
			data.setChoice3Text("起きなよ、風邪引くよ（声をかける）");

			data.setRes1(
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……んっ……。……えへへ……。……ずっと、そばにいて……」" +
				"[NEXT]" +
				"[NAME:NONE]俺の手のひらに頬をすり寄せ、彼女は幸せそうに微笑んだ。もはや言い訳のしようがないほどの、純粋な好意だ。"
			);
			data.setC1Love(6); data.setC1Like(0); // 【Love最大】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ん……。……あったか、い……」" +
				"[NEXT]" +
				"[NAME:NONE]上着の温もりに安心したように、彼女は再び深い眠りに落ちた。俺への絶対的な信頼を感じる。"
			);
			data.setC2Love(2); data.setC2Like(4); // 【Like寄り】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……はっ！？ な、なんですか！？ ……っ、私、変なこと言いませんでしたよね！？」" +
				"[NEXT]" +
				"[NAME:NONE]彼女を飛び起きさせてしまった。せっかくの甘い寝顔を堪能するチャンスを逃した。"
			);
			data.setC3Love(-2); data.setC3Like(-1); // 【失敗】
			break;

		case 12: // 【ケース12：整理整頓と、苦しい言い訳】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]自分の案件がひと段落した俺は、気分転換にデスク周りの私物や技術書を整理し始めていた。" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……何、してるんですか」" +
				"[NEXT]" +
				"[NAME:PLAYER]「少し散らかってきたから、使わない資料をまとめようと思って」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……ダメです！ まだ……UIの細かいフォントの調整とか、エンドロールの余白のピクセルとか……終わってません！」" +
				"[NEXT]" +
				"[NAME:PLAYER]（それは俺の管轄外だ。彼女もそれを分かっているはずなのに、俺の荷物が片付けられることに過剰に反応している）"
			);
			data.setChoice1Text("それは俺の仕事じゃないだろ？");
			data.setChoice2Text("分かった。エンドロールが終わるまで散らかしておくよ");
			data.setChoice3Text("……サユキさんが片付けてほしくないなら、このままにするよ");

			data.setRes1(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。……そうですか。じゃあ勝手にしてください」" +
				"[NEXT]" +
				"[NAME:NONE]正論で彼女の不器用な反応を切り捨ててしまった。彼女は深く傷ついたような顔をした。"
			);
			data.setC1Love(-4); data.setC1Like(-2); // 【大失敗】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……はい」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……最後まで、見届けてください。あなたが技術サポートしてくれた作品なんですから」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は安堵の息を吐き、嬉しそうに頷いた。プロとしての理由を残してあげることが優しさだ。"
			);
			data.setC2Love(2); data.setC2Like(4); // 【Like寄り】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！ か、片付けてほしくないなんて言ってません！ ただ、あなたがいた方が……」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……。……。……ばか。……分かってるなら、黙ってそのままにしておいてください……」" +
				"[NEXT]" +
				"[NAME:NONE]ついに彼女は言い訳を放棄し、俯きながら本音をこぼした。もう、ただの仕事仲間の境界線は存在しない。"
			);
			data.setC3Love(6); data.setC3Like(0); // 【Love最大】
			data.setRes3Visuals(new VisualBeans("Sayuki_mesorasi.png", bgSunset, "cross_fade", "close_up", "sunset"));
			break;

		case 13: // 【ケース13：エンディングへの恐怖】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]テストプレイ中。画面には、サユキが描いた美しい一枚絵と共に、スタッフロールが流れ始めた。" +
				"[NEXT]" +
				"[NAME:PLAYER]「ここまで来れたね。最高のエンディングだよ」" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……。……私。この画面、見たくありません」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……この画面を見終わったら。……ここでこうして一緒に過ごす時間が、本当に終わっちゃう気がして。……怖いです」"
			);
			data.setChoice1Text("一緒にエンディングを見届けよう。大丈夫だ");
			data.setChoice2Text("俺がいなくなっても、この作品は残るよ");
			data.setChoice3Text("ゲームが完成しても、俺たちの関係は終わらないよ");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……。……はい。……あなたがそう言うなら、最後まで見ます」" +
				"[NEXT]" +
				"[NAME:NONE]俺たちは並んで座り、流れるスタッフロールを静かに見つめた。確かな達成感と、少しの切なさが入り混じる。"
			);
			data.setC1Love(2); data.setC1Like(4); // 【Like寄り】

			data.setRes2(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……作品さえ残ればいいなんて、そんなこと言ってません。……あなたは何も分かってない」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は画面から目を背けてしまった。彼女が本当に求めているのは『作品』ではなく『俺』だったのに。"
			);
			data.setC2Love(-3); data.setC2Like(-1); // 【失敗】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……本当、ですか……？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……。……信じますからね。……もし裏切ったら、世界中探し出して……地の果てまで追いかけますから……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は涙声で強がりを言いながら、俺の腕にギュッとすがりついた。彼女の全てを受け止める覚悟が決まった。"
			);
			data.setC3Love(5); data.setC3Like(1); // 【Love最大】
			break;

		case 14: // 【ケース14：言い訳の終わりと、その先の予感】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]全ての制作工程が完了した、ある晴れた日。サユキが俺のデスクの横に立ち、まっすぐな瞳でこちらを見つめてきた。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……もう、バグもありません。仕様の追加もありません。……あなたをここに呼ぶための『仕事上の理由』は、もう全部使い切っちゃいました」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……ねぇ、" + pName + "さん。……。……仕事が終わったら、私たちは……ただの『元・同居人』になっちゃうんですか？」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女は震える手で、俺のシャツの袖をきつく握りしめていた。その瞳には、言葉にできない想いが溢れそうになっている）"
			);
			data.setChoice1Text("戻らないよ。俺はこれからもサユキのそばにいたい");
			data.setChoice2Text("最高のパートナーだったね。ありがとう");
			data.setChoice3Text("……サユキさんの本当の気持ち、聞かせて？");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！ ……。……。……あ、当たり前です。逃がすなんて言ってませんから」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……覚悟、しておいてくださいね。……。……さあ、最後の一歩……踏み出しましょうか」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は嬉しそうに、でもどこか泣きそうな顔で微笑んだ。二人の物語の本当の結末は、もうすぐそこまで来ている。"
			);
			data.setC1Love(5); data.setC1Like(2); // 【Loveルートの大正解】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……。ええ、そうですね。……ありがとうございました」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は寂しそうに微笑み、深く一礼した。プロとしての絆は深まったが、決定的な一歩を踏み出すことはできなかった。"
			);
			data.setC2Love(1); data.setC2Like(5);

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「っ！？ ……。……。……今は、まだ、言えません」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……全部片付いて、このアトリエでの役目が本当に終わった時に。……ちゃんと、私の言葉で伝えますから……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は顔を真っ赤にしてそっぽを向いた。本当の決着は、エンディングの瞬間へと持ち越された。"
			);
			data.setC3Love(4); data.setC3Like(1);
			break;

		default:
			return super.getScenario(0, pName);
		}
		return data;
	}
}