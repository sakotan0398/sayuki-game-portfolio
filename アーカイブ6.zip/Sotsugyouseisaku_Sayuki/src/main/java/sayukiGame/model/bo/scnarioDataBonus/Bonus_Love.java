package sayukiGame.model.bo.scnarioDataBonus;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;

public class Bonus_Love {

	public ScenarioData getScenario(int step, String pName) {
		ScenarioData data = new ScenarioData();
		data.setPoolType("Bonus");

		// 後日談は選択肢なしの一本道で進める
		data.setChoice1Text("続きを読む ▼");
		data.setChoice2Text("続きを読む ▼");
		data.setChoice3Text("続きを読む ▼");
		data.setRes1(""); data.setRes2(""); data.setRes3("");

		String bgNight = "bg068n19201440.jpg";

		switch (step) {
		case 0: // 【起】リリース後のアトリエの夜
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgNight, "fade", "normal", "night"));
			data.setMessage(
				"【💖 Love End 後日談：私だけの、特権だから】<br><br>" +
				"[NEXT]" +
				"[NAME:NONE]ゲームのリリースから数週間。怒涛のデバッグ作業と配信手続きが一段落し、オフィスにはいつもの穏やかな静寂が戻っていた。" +
				"[NEXT]" +
				"[NAME:NONE]深夜。PCの微かな排熱音だけが響く部屋で、俺は次のパッチ修正のコードをのんびりと眺めていた。" +
				"[NEXT]" +
				"[NAME:NONE]すると、隣のデスクからキャスターの「カラカラ……」という音が聞こえ、俺の椅子のすぐ真横に、お馴染みの影がピタリと並んだ。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……何、そんなに熱心に画面見てるんですか。仕事はもう、お休みって言ったはずですけど」"
			);
			break;

		case 1: // 【承】付き合いたての距離感
			data.setMessage(
				"[NAME:PLAYER]「サユキの方こそ、ペン握りっぱなしじゃないか」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png][NAME:SAYUKI]「これは仕事じゃなくて、ただの趣味の落書きです！ ～～というか、寂しいから構えって無言でアピールしてるのに、なんで気づかないんですか、バカ」" +
				"[NEXT]" +
				"[NAME:NONE]サユキはマフラーに顔を埋めるように、部屋着のトップスの襟元に顎をちょこんと乗せて、じと目でこちらを見つめてくる。" +
				"[NEXT]" +
				"[NAME:PLAYER]「ごめんごめん。ほら、温かいカフェオレ淹れてきたよ」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「あ……マグカップ、お揃いのやつ。……ふふ、ありがとうございます」"
			);
			break;

		case 2: // 【転1】消え去った不安
			data.setVisuals(new VisualBeans("Sayuki_mesorasi.png", bgNight, "cross_fade", "close_up", "night"));
			data.setMessage(
				"[NAME:NONE]サユキはマグカップを両手で大切そうに包み込み、温かい湯気をふーっと吹きながら、ぽつりと呟いた。" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png][NAME:SAYUKI]「……実は、ゲームがリリースされて、開発の『契約』が終わった瞬間……本当にあなたがアトリエからいなくなっちゃうんじゃないかって、毎日すごく怖かったんです」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「あの時、泣きじゃくる私を抱きしめて『どこにも行かない、サユキの彼氏だから』って言ってくれたとき……本当に、心臓が破裂するかと思いました」" +
				"[NEXT]" +
				"[NAME:PLAYER]「俺だってサユキから離れる気なんて最初からなかったよ。ずっとそばにいたかったから」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「なっ……！ ～～～っ、そういう恥ずかしいセリフ、本当にサラッと言いよるんだから、このバグの塊は……！」"
			);
			break;

		case 3: // 【転2】「私のエンジニア」という独占欲
			data.setMessage(
				"[NAME:NONE]真っ赤になってそっぽを向いたサユキ。だが、しばらくすると俺のシャツの袖を、細い指先でぎゅっと小さく引っ張ってきた。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……でも、嬉しいです。仕事としての関係は終わったのに、今こうして、前よりもずっと近い距離であなたの隣にいられるの」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png][NAME:SAYUKI]「これで名実ともに、あなたは『私だけのエンジニア』、ですから。……他の女の子のデバッグなんてしたら、絶対に許しませんからね？」" +
				"[NEXT]" +
				"[NAME:PLAYER]「もちろん。俺のソースコードは、一生サユキにしかコミットしないよ」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「～っ！ だから、プログラムに例えてカッコいいこと言わなくていいです！ 脳内が処理オーバー起こします！」"
			);
			break;

		case 4: // 【転3】膝の上の特等席
			data.setVisuals(new VisualBeans("Sayuki_mesorasi.png", bgNight, "fade", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]ジタバタと照れ隠しに怒る彼女が愛おしくて、俺は彼女の椅子を引き寄せ、その細い体を後ろからそっと抱きしめた。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「わ、わっ……！？ ちょ、ちょっと、不意打ち禁止です……っ！」" +
				"[NEXT]" +
				"[NAME:PLAYER]「こうしてると、すごく落ち着くんだ。サユキ、すごくいい匂いするし」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……そんなの、気のせいに決まってます……。……。……でも、……私も、あなたの匂い、落ち着きます……」" +
				"[NEXT]" +
				"[NAME:NONE]サユキは俺の腕の中にすっぽりと収まり、抵抗するのをやめて、背中を俺の胸に完全に預けてきた。"
			);
			break;

		case 5: // 【転4】恋人としての特権
			data.setVisuals(new VisualBeans("Sayuki_mesorasi.png", bgNight, "cross_fade", "close_up", "night"));
			data.setMessage(
				"[NAME:NONE]トク、トク、と、密着した背中から、彼女の少し早い心臓の鼓動がダイレクトに伝わってくる。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……ねぇ、" + pName + "さん。昔、私が居眠りしてた時、私の頭、優しく撫でてくれましたよね」" +
				"[NEXT]" +
				"[NAME:PLAYER]「あ、気づいてたの？」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「ふふ、あったかくて気持ちよかったから、寝たフリしてたんです」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「あの頃は『管理人としての壁』を崩しちゃいけないって強がってたけど……今はもう、恋人、なんですよね」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「だから……寝たフリなんてしなくても、ちゃんと甘えていい、権利……ありますよね？」"
			);
			break;

		case 6: // 【結1】初めての、甘いキス
			data.setMessage(
				"[NAME:NONE]彼女は腕の中でゆっくりと身体を回転させ、正面から俺の目を見つめてきた。<br>" +
				"潤んだ瞳が、暗いアトリエのモニターの光を反射して、花火の時のように綺麗に輝いている。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……おねがい、します。……私のバグ、全部溶かすくらい……たくさん、甘やかしてください……っ」" +
				"[NEXT]" +
				"[NAME:NONE]消え入りそうな声の懇願に、俺が応えないわけがなかった。<br>" +
				"そっと彼女の顎を持ち上げ、重なるように唇を寄せた。" +
				"[NEXT]" +
				"[NAME:NONE]――ん、と、静かなオフィスに、小さなリップ音が小さく溶けていく。"
			);
			break;

		case 7: // 【結2】幸せのオーバーフロー
			data.setMessage(
				"[NAME:NONE]一度離れた唇が、名残惜しそうに、もう一度、深く自然に重なり合う。<br>" +
				"付き合いたての初々しい甘さが、お互いの体温を通じてどこまでも溶け出していくようだった。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……はぁ……っ、……ん……」" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「……ふぇぇ。……やっぱりあなたといると、私の頭、完全に処理落ちしちゃいます……」" +
				"[NEXT]" +
				"[NAME:NONE]キスが終わり、俺の胸にポスッと額を押し付けたサユキが、完全にゆでだこ状態でフーフーと息を漏らしている。"
			);
			break;

		case 8: // 【結3】終わらない開発と日常
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgNight, "cross_fade", "normal", "night"));
			data.setMessage(
				"[NAME:PLAYER]「少しは元気が充電できたか？」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「はい！ バッテリー100%どころか、限界突破（オーバーフロー）して溢れそうなくらいです！」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png][NAME:SAYUKI]「……でも、幸せすぎて明日起きられなくなったら、あなたのせいですからね？ ちゃんとモーニングコール、してくださいよ？」" +
				"[NEXT]" +
				"[NAME:PLAYER]「喜んで。毎朝だってかけるよ」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「ふふ、約束です。仕事としてのゲーム開発が終わっても……私とあなたの共同制作（まいにち）は、一生アップデートし続けますからね！」"
			);
			break;

		case 9: // 【終】ギャラリーへ戻る
			data.setMessage(
				"[NAME:NONE]アトリエの境界線を完全に飛び越えた俺たちの日常は、これからも甘い音を奏でながら続いていく。<br>" +
				"私だけのエンジニア、そして俺だけの可愛いイラストレーターとして。" +
				"[NEXT]" +
				"[NAME:SYSTEM]（Love End 後日談 - 完）"
			);
			
			// 最終ページはボタンのテキストを「ギャラリーへ戻る」に変える
			data.setChoice1Text("ギャラリーへ戻る");
			data.setChoice2Text("ギャラリーへ戻る");
			data.setChoice3Text("ギャラリーへ戻る");
			break;
		}

		return data;
	}
}