package sayukiGame.model.bo.scnarioDataTrue;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;
import sayukiGame.model.bo.scnarioDataCommon.Phase5;

public class TruePhase5 extends Phase5 {

	@Override
	public ScenarioData getScenario(int num, String pName) {
		
		// 0〜8 は親クラス（Common）の、仕事の追い込みや達成感の共有を呼び出す
		if (num <= 8) {
			return super.getScenario(num, pName);
		}

		// 9〜14：Trueルート専用（プロとしての絶対的信頼と、隠しきれない愛情の完全な融合）
		ScenarioData data = new ScenarioData();
		data.setPoolType("True");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 

		switch (num) {
		case 9: // 【ケース9：最強の嫉妬イベント】
			data.setVisuals(new VisualBeans("Sayuki_jitome.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]作業の合間、俺のスマホにフリーランスの仕事仲間（女性デザイナー）から『この前の案件助かりました！ 今度打ち上げ行きましょう♡』とメッセージが届いた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（相変わらず気さくな人だな、と思わずクスッと笑ってしまった、その時）" +
				"[NEXT]" +
				"[IMG:Sayuki_scary_smile.png]" +
				"[NAME:SAYUKI]「……随分と楽しそうですね。私のデバッグ中だっていうのに」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……そんなにそのデザイナーさんが優秀なら、そっちの専属になればいいじゃないですか。ここから出ていって」" +
				"[NEXT]" +
				"[NAME:PLAYER]（サユキがかつてないほど冷たい声で、しかし肩を微かに震わせながらこちらを睨みつけている。これは……）"
			);
			data.setChoice1Text("ただの仕事仲間だよ。サユキさんが一番の相棒だ");
			data.setChoice2Text("俺はサユキさん専属の技術顧問だから、行かないよ");
			data.setChoice3Text("……もしかして、本気でヤキモチ焼いてる？");

			data.setRes1(
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……。……一番の相棒、ですか。……なら、いいですけど」" +
				"[NEXT]" +
				"[NAME:NONE]少し不満げだが、プロとしての『一番』という言葉に納得したようだ。"
			);
			data.setC1Love(2); data.setC1Like(4); // 【Like寄り】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……当たり前です。私がどれだけあなたに……っ」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……コホン。ええ、技術顧問としての契約（口約束）が残ってますからね。浮気は許しません」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は照れ隠しに咳払いをして、嬉しそうにモニターに向き直った。"
			);
			data.setC2Love(4); data.setC2Like(4); // 【True寄り】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！！ や、ヤキモチなんて……！！」" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「……焼いてますよ。……バカ。……私以外のところで、そんな顔しないでください……っ」" +
				"[NEXT]" +
				"[NAME:NONE]図星を突かれ、彼女はついに言い訳を放棄して顔を覆った。独占欲と愛情が完全に混ざり合った、最高のデレだった。"
			);
			data.setC3Love(6); data.setC3Like(2); // 【Love最大】嫉妬の大爆発
			data.setRes3Visuals(new VisualBeans("Sayuki_anxiety.png", bgDay, "cross_fade", "close_up", "day"));
			break;

		case 10: // 【ケース10：言葉のない最終デバッグ】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]マスターアップ直前。最後の最後で、致命的なメモリーリークのバグが発覚した。" +
				"[NEXT]" +
				"[NAME:PLAYER]（原因の特定が難しい。……だが、俺がログを追っている間に、サユキは何も言わずにUIのアセットを極限まで軽量化し始めた）" +
				"[NEXT]" +
				"[NAME:NONE]俺がメモリの解放処理を書き終えた瞬間、彼女の軽量化データが共有フォルダにアップされた。完全に同時のタイミングだった。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……これで、どうですか」"
			);
			data.setChoice1Text("完璧だ。コンパイル通すよ");
			data.setChoice2Text("流石だね。信じてたよ");
			data.setChoice3Text("（無言で頷き、二人同時にエンターキーを叩く）");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「ええ。私たちの最高傑作です。……絶対に、通ります」" +
				"[NEXT]" +
				"[NAME:NONE]見事にエラーは消え去った。最高の仕事仲間だ。"
			);
			data.setC1Love(1); data.setC1Like(4); // 【Like寄り】

			data.setRes2(
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……私も。あなたが直してくれるって、信じてましたから」" +
				"[NEXT]" +
				"[NAME:NONE]少し照れたように笑い合う。深い信頼と好意が交差する。"
			);
			data.setC2Love(4); data.setC2Like(2); // 【Love寄り】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……ふふっ」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:NONE]ターンッ！と二人のタイピング音が重なり、エラー表示が『SUCCESS』に変わった。言葉すらもはや不要な、究極のシンクロだった。"
			);
			data.setC3Love(4); data.setC3Like(5); // 【True最大】プロフェッショナルの阿吽の呼吸
			break;

		case 11: // 【ケース11：静寂と温もりの朝】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]全てのデータ提出を終えた早朝。アトリエに窓から青白い光が差し込む。長い戦いが、ついに終わったのだ。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「終わっ、た……。本当に、完成したんですね……」" +
				"[NEXT]" +
				"[NAME:NONE]椅子にもたれ、放心状態のサユキ。……と、彼女のキャスター付きの椅子が、ゆっくりと吸い寄せられるようにこちらへ滑ってきた。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……" + pName + "さん。……。５分だけ……」" +
				"[NEXT]" +
				"[NAME:NONE]コツン、と。彼女が『自分から』、俺の肩に頭を預けてきた。シャンプーの甘い香りと、微かな寝息が伝わってくる。"
			);
			data.setChoice1Text("お疲れ様。よく頑張ったね");
			data.setChoice2Text("５分じゃ足りないだろ？");
			data.setChoice3Text("（何も言わず、彼女の頭を優しく引き寄せる）");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……はい。あなたが一緒に戦ってくれたおかげです……。おやすみなさい、相棒……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は目を閉じたまま、穏やかな声で呟いた。戦友としての確かな絆が、今ここにある。"
			);
			data.setC1Love(2); data.setC1Like(5);

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……バカ。……足りないなら、あなたが一生かけて、埋めてくださいよ……」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の肩が微かに震えた。朝の静寂の中で、二人の距離が完全にゼロになった。"
			);
			data.setC2Love(5); data.setC2Like(1);

			data.setRes3(
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……んっ……」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……あったかい。……。……もう、離れたくなくなっちゃったじゃないですか。……どうしてくれるんですか」" +
				"[NEXT]" +
				"[NAME:NONE]余計な言葉はいらなかった。朝日が昇るまで、二人は寄り添い、お互いの存在を確かめ合っていた。"
			);
			data.setC3Love(5); data.setC3Like(5);
			break;

		case 12: // 【ケース12：混ざり合った二人の『居場所』】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]アトリエの整理をしていた時のこと。俺の技術書とサユキの画集。二人のデスクの境目はとうに消え、物は完全に混ざり合っていた。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……ねぇ、" + pName + "さん。……ここのテープの跡、憶えてますか？ 最初に私が引いた『絶対境界線』の」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……今思うと、笑っちゃいますね。こんなにあなたの存在が、私の『日常』の一部になるなんて思わなかったから」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女は少し悪戯っぽく、それでいて慈しむような瞳で部屋を見回した）"
			);
			data.setChoice1Text("今なら笑って話せる思い出だね");
			data.setChoice2Text("もう線なんていらないよ。ここは俺たちの部屋だ");
			data.setChoice3Text("引き直す？ 今度は俺がサユキを囲っちゃうけど");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「ふふ、そうですね。あんなに尖っていた自分が懐かしいです。……あなたに出会って、丸くなったのかもしれません」" +
				"[NEXT]" +
				"[NAME:NONE]柔らかな微笑みが、今の彼女の心の安定を物語っていた。"
			);
			data.setC1Love(2); data.setC1Like(4);

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……俺たちの、部屋……。……。……いいですね、その響き。……特別に許可してあげます」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は顔を赤らめつつも、満足そうに頷いた。共同生活以上の深い結びつきを確認できた。"
			);
			data.setC2Love(5); data.setC2Like(3);

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ……！ ～～っ！」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……バカ。……囲わなくても、私はここから動きませんよ。……。……あなたがいなきゃ、描けなくなっちゃったんですから……責任取ってくださいね」" +
				"[NEXT]" +
				"[NAME:NONE]強烈な信頼と愛情が返ってきた。もはや二人の間に壁など存在しなかった。"
			);
			data.setC3Love(5); data.setC3Like(5);
			break;

		case 13: // 【ケース13：消えない環境音】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]ゲーム完成から数日後。俺は自分のフリーランスの案件をこなすため、いつものようにアトリエでキーボードを叩いていた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（サユキさんは休んでいるかと思ったが……横を見ると、彼女は液タブに向かって新しいラフを描き始めていた）" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……何見てるんですか。次の作品の構想を練ってるんです。クリエイターに完全な休みなんてありません」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……それに。あなたのそのタイピング音がないと……もう、静かすぎて集中できなくなっちゃったので」"
			);
			data.setChoice1Text("完全に俺の音に依存してるね（からかう）");
			data.setChoice2Text("俺も、サユキさんの描く音が聞こえないと落ち着かないよ");
			data.setChoice3Text("じゃあ、これからもずっとこの音を聞かせてあげる");

			data.setRes1(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「い、依存なんてしてません！ ただの環境BGMです！ ……もう、静かにしてください」" +
				"[NEXT]" +
				"[NAME:NONE]ムキになって否定する姿が、少しだけ可愛らしかった。"
			);
			data.setC1Love(3); data.setC1Like(0); // 【Love寄り】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！ ……。……。……同じ、ですか」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……プロ同士、環境の好みが完全に一致してるみたいですね。……嫌いじゃないです、その感覚」" +
				"[NEXT]" +
				"[NAME:NONE]お互いの『仕事の音』が共鳴し合う。これ以上ないクリエイターとしての共感だ。"
			);
			data.setC2Love(3); data.setC2Like(5); // 【Like寄り】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……約束、ですからね。……私の隣の席、一生空けておきますから」" +
				"[NEXT]" +
				"[NAME:NONE]彼女はとても優しく、幸せそうに微笑んだ。日常の中に、永遠の誓いが溶け込んでいる。"
			);
			data.setC3Love(5); data.setC3Like(4); // 【True最大】
			break;

		case 14: // 【ケース14：真の契約（専属技術顧問へのオファー）】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]サユキが真剣な顔で、一枚の書類を俺のデスクに置いた。……それは、以前彼女が口にしていた『専属顧問契約』の書類だった。" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……以前も言いましたけど、正式に、オファーさせてください」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「あなたの技術力、そして何より……私のクリエイティブにここまで深く踏み込み、高めてくれる人は、世界中探してもあなたしかいません」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……お金の話じゃありません。……私の隣に、これからもずっといてほしいんです。……いいですか？」"
			);
			data.setChoice1Text("喜んで。一生、サユキさんの作品を支え続けるよ");
			data.setChoice2Text("俺でいいの？ 他にも優秀な人はいるよ？");
			data.setChoice3Text("悪いけど、俺は自分の道を行くよ");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！ ……ふふ。……はいっ」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……言いましたね？ なら、覚悟してください。一生、私のバグ修正に縛り付けてやりますから。……私の『相棒』」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の瞳には、一切の迷いがなかった。二人の旅路は、ここから新しく始まるのだ。Likeルート完遂の証だ。"
			);
			data.setC1Love(3); data.setC1Like(10); // 【Likeルートの大正解・完結】

			data.setRes2(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……馬鹿なこと言わないでください。優秀な人間なんていくらでもいます」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「私が求めているのは、あなた、なんです。……。……もう一度、聞き直します。……私の隣、空けておいてもいいですか？」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の真っ直ぐな想いに、言葉を失った。"
			);
			data.setC2Love(5); data.setC2Like(3);

			data.setRes3(
				"[IMG:Sayuki_scary_smile.png]" +
				"[NAME:SAYUKI]「…………。そう、ですか。分かりました。……。……今まで、お世話になりました」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の瞳から完全に光が消えた。二人の関係は、ここで完全に終わってしまった。Likeルート・バッドエンドだ。"
			);
			data.setC3Love(-10); data.setC3Like(-10); // 【致命的失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_scary_smile.png", bgDay, "cross_fade", "close_up", "day"));
			break;

		default:
			return super.getScenario(0, pName);
		}
		return data;
	}
}