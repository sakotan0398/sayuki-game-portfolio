package sayukiGame.model.bo.scnarioDataTrue;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;
import sayukiGame.model.bo.scnarioDataCommon.Phase3;

public class TruePhase3 extends Phase3 {

	@Override
	public ScenarioData getScenario(int num, String pName) {
		
		// 0〜8 が選ばれた場合は、親クラス（Common）の共通の日常会話を呼び出す
		if (num <= 8) {
			return super.getScenario(num, pName);
		}

		// 9〜14：Trueルート専用（互いの仕事に干渉しすぎないが、絶大な信頼を置いている距離感）
		ScenarioData data = new ScenarioData();
		data.setPoolType("True");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 
		
		switch (num) {
		case 9: // 【ケース9：阿吽の呼吸（付かず離れずのサポート）】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]自分の案件で、外部APIの仕様書を確認しようとモニターに目線を外さず手探りで探していた時のこと。" +
				"[NEXT]" +
				"[NAME:NONE]俺が探すより一瞬早く、サユキがその仕様書のファイルを、こちらへ差し出していた。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「あ……。これですよね。さっきから裏でサーバーの挙動をテストしてるみたいだったので」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ふふっ。最近、あなたのタイピングのパターンで、今何の作業で詰まってるか分かるようになってきました」" +
				"[NEXT]" +
				"[NAME:PLAYER]（互いに自分の仕事をしているだけなのに、必要なものがスッと出てくる。心地よいリズムが出来上がっている）"
			);
			data.setChoice1Text("ありがとう。流石、気が利くね");
			data.setChoice2Text("思考を読まれるのはちょっと怖いな（冗談）");
			data.setChoice3Text("俺たち、作業の息がピッタリ合ってきたね");

			data.setRes1(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……別に。あなたが早くエラーを吐き出し終えた方が、この部屋が静かになるからです」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は少し得意げに笑い、すぐに自分の作業へ戻った。有能な同居人としての自負を満たせたようだ。"
			);
			data.setC1Love(1); data.setC1Like(4); // 【Like特化】

			data.setRes2(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……せっかく気を利かせてあげたのに。もう二度と手伝いませんからね」" +
				"[NEXT]" +
				"[NAME:NONE]冗談のつもりだったが、ファイルを机に乱暴に置かれてしまった。"
			);
			data.setC2Love(-2); data.setC2Like(-2); // 【失敗】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……はい」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「なんだか……それぞれ別の仕事をしてるのに、同じ空間で歯車が噛み合ってるみたいで……。少し、不思議ですね」" +
				"[NEXT]" +
				"[NAME:NONE]本を受け取る時、彼女は少しだけ目線を逸らし、小さく笑った。仕事の境界線を守りつつ、深い結びつきを感じる。"
			);
			data.setC3Love(3); data.setC3Like(4); // 【True最大】適度な距離感でのシンクロ
			break;

		case 10: // 【ケース10：彼女の作品と、技術の裏方】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]サユキが自分のゲームに組み込んだLive2Dのモーション。その物理演算が重かったため、俺が最適化のコードをいくつか助言した後のこと。" +
				"[NEXT]" +
				"[NAME:NONE]モニターの中で、サユキの描いたキャラクターが、驚くほど滑らかに、そして魅力的に動いた。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……すごい……っ」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……" + pName + "さんが教えてくれた最適化ロジックを通したら、私が想定していた通りの完璧な動きになりました」"
			);
			data.setChoice1Text("サユキさんの元の絵の魅力が引き立ったね");
			data.setChoice2Text("俺は少し助言しただけ。サユキさんの力だよ");
			data.setChoice3Text("この調子で、絶対に大ヒットさせてくれ");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……絵だけじゃ、こんなに滑らかには動きません。あなたが私の『やりたいこと』を技術で翻訳してくれたからです」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は照れくさそうに頬を掻きながら、しっかりとこちらの技術を評価してくれた。最高の関係性だ。"
			);
			data.setC1Love(3); data.setC1Like(5); // 【True最大】相手の作品を立てる

			data.setRes2(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……謙遜しすぎです。そういうの、逆に嫌味に聞こえますよ」" +
				"[NEXT]" +
				"[NAME:NONE]少し突き放したような言い方になってしまい、彼女は不満げに画面に向き直ってしまった。"
			);
			data.setC2Love(1); data.setC2Like(0); // 【停滞】

			data.setRes3(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……はいっ！ 私の作品、絶対に世に出して評価させてみせますから。……また詰まったら、相談に乗ってくださいね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女のクリエイターとしての闘志に火をつけた。あくまで『彼女のゲーム』としての立ち位置を守れている。"
			);
			data.setC3Love(1); data.setC3Like(4); // 【Like寄り】
			break;

		case 11: // 【ケース11：コーヒーブレイク】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]深夜。キリの良いところで給湯室にコーヒーでも淹れようと立ち上がると、全く同じタイミングでサユキも財布を手に立ち上がった。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「あ……」" +
				"[NEXT]" +
				"[NAME:PLAYER]「あ……」" +
				"[NEXT]" +
				"[NAME:NONE]深夜のオフィスで、お互いに見つめ合う形になってしまった。"
			);
			data.setChoice1Text("もしかして、以心伝心？");
			data.setChoice2Text("俺、後で淹れるよ。お先どうぞ");
			data.setChoice3Text("ちょうどいいし、一緒に淹れに行こうか");

			data.setRes1(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「い、以心伝心って……！ たまたまカフェインが切れるタイミングが被っただけですっ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも、まあ。……悪くない偶然、ですね」" +
				"[NEXT]" +
				"[NAME:NONE]ムキになって否定したが、最後は小さく微笑んだ。"
			);
			data.setC1Love(4); data.setC1Like(1); // 【Love寄り】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「あ……いえ、コーヒーくらい二人で淹れに行っても問題ないじゃないですか。……変に気を使わないでください」" +
				"[NEXT]" +
				"[NAME:NONE]過剰に譲り合ってしまい、少しだけ変な空気が流れた。気を使われすぎると壁を感じるようだ。"
			);
			data.setC2Love(-1); data.setC2Like(-1); // 【失敗】

			data.setRes3(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「あ……。……ふふっ。考えること、一緒ですね。じゃあ、一緒に淹れましょうか。あ！私のは……」" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「あ！私のは……その……甘めで……」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:NONE]二人でオフィス内の小さな給湯室へ向かい、自販機の前で他愛のない雑談をしながらコーヒーを淹れる。派手さはないが、確かな信頼を感じる時間だ。"
			);
			data.setC3Love(3); data.setC3Like(4); // 【True最大】適度な距離での休憩
			break;

		case 12: // 【ケース12：彼女のこだわりと技術の盾】
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]サユキが自分の作品について、データ容量の制約に頭を悩ませている。" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……この解像度を落とす変更、どうしても納得いかないんです。イラストの細部の質感が完全に潰れちゃいます」" +
				"[NEXT]" +
				"[NAME:PLAYER]（確かに彼女の言う通りだ。だが、このままではシステムの動作要件を満たせない。俺の持っている知識でなんとか……）"
			);
			data.setChoice1Text("画質を維持したまま圧縮するスクリプトを組んでみるよ");
			data.setChoice2Text("俺が代わりにプログラマーとして、クライアントに直談判しようか？");
			data.setChoice3Text("サユキさんの絵が一番大事だから、妥協しないで");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「" + pName + "さん……！ そんなこと、できるんですか！？」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ありがとうございます！ 私の絵を守るために技術を使ってくれるなんて……最高のアドバイザーですね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の瞳に強い光が戻った。彼女の作品の領域を侵さず、外側から技術の盾で守る。これが二人の正しい共闘だ。"
			);
			data.setC1Love(3); data.setC1Like(5); // 【True最大】フリーエンジニアとしての的確なサポート

			data.setRes2(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……は？ 私の作品ですよ？ なんで赤の他人のあなたが直談判するんですか。出しゃばらないでください」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の『自分の作品』へのプライドを無視した提案をしてしまい、激しく拒絶された。"
			);
			data.setC2Love(-3); data.setC2Like(-4); // 【大失敗】領分を越えすぎた

			data.setRes3(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……っ。精神論じゃ容量の問題は解決しないんです。無責任な肯定ならいりません」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は少し呆れたようにため息をついた。プロとして、無責任な肯定は求めていなかったようだ。"
			);
			data.setC3Love(1); data.setC3Like(-2); // 【Loveは少し上がるがLikeは下がる】
			break;

		case 13: // 【ケース13：間借りの折り返し地点】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:SAYUKI]「……気がつけば、あなたがこのオフィスを間借りし始めてから、もう何ヶ月も経つんですね」" +
				"[NEXT]" +
				"[NAME:NONE]ふと、サユキが壁のホワイトボードを見上げて呟いた。" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「最初は、絶対にすぐ追い出してやるって思ってたのに……」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「なんだか、このアトリエに頼りになる技術顧問が一人いる環境も……少しだけ、悪くないなって思い始めてます」"
			);
			data.setChoice1Text("最後までお互いの仕事、頑張ろう");
			data.setChoice2Text("俺はサユキさんと毎日会えて嬉しいよ");
			data.setChoice3Text("俺も、すごく居心地のいいオフィスだと思うよ");

			data.setRes1(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……そうですね。ここの契約期間が終わるまで、私のバグ修正に付き合ってもらいますから覚悟してくださいね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は自分の頬を軽く叩き、照れ隠しのように気合を入れ直した。"
			);
			data.setC1Love(0); data.setC1Like(3); // 【Like寄り】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ。……そういうこと、平気な顔して言いますよね、貴方って人は」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:NONE]彼女は少し赤くなってそっぽを向いたが、少し踏み込みすぎたかもしれない。"
			);
			data.setC2Love(3); data.setC2Like(-1); // 【Love寄り】

			data.setRes3(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「えっ……」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……ふふっ。そうですか。……家主の代理として、その評価は誇らしいですね」" +
				"[NEXT]" +
				"[NAME:NONE]お互いの個人的な領域には踏み込みすぎず、それでも『今の環境が最適だ』という本音を共有できた。心地よい時間が流れている。"
			);
			data.setC3Love(3); data.setC3Like(3); // 【True最大】適度な距離感での肯定
			break;

		case 14: // 【ケース14：クリエイターとしてのハイタッチ】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:SAYUKI]「……よしっ！ コンパイル通りました！ あなたが教えてくれた処理、完璧に動いてます！」" +
				"[NEXT]" +
				"[NAME:NONE]数日がかりの彼女の難題を、俺の技術的知見でクリアした瞬間。俺たちは自然とお互いの手を上げ――パァンッ、と乾いたハイタッチをした。" +
				"[NEXT]" +
				"[NAME:PLAYER]（……いつもなら、すぐに手を離して自分のデスクに戻るところだが）"
			);
			data.setChoice1Text("（そのまま、彼女の指先を軽く握る）");
			data.setChoice2Text("（ハイタッチの後、少しだけ顔を見合わせて微笑む）");
			data.setChoice3Text("（すぐに手を引っ込めて伸びをする）");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……えっ。ちょ、ちょっと……" + pName + "さん？ 触りすぎです……っ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:NONE]彼女は驚いて顔を赤くし、サッと手を引いてしまった。達成感の余韻よりも警戒心が勝ってしまったようだ。"
			);
			data.setC1Love(1); data.setC1Like(-2); // 【失敗】距離の詰め間違い

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……あっ。えと……その、お疲れ様です……っ」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:NONE]手を離した後も、お互いの視線がほんの数秒だけ絡み合った。言葉はなくても、お互いへの深いリスペクトと、微かな温もりが伝わってくる。これ以上ない関係だ。"
			);
			data.setC2Love(4); data.setC2Like(4); // 【True最大】過度な接触を避けた視線の交差

			data.setRes3(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「…………はい。さっさと自分の仕事に戻りましょう」" +
				"[NEXT]" +
				"[NAME:NONE]せっかくの達成感と余韻が、あっさりと霧散してしまった。少し素っ気なさすぎたかもしれない。"
			);
			data.setC3Love(-2); data.setC3Like(-1); // 【失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_dakara.png", bgNight, "cross_fade", "normal", "night"));
			break;

		default:
			return super.getScenario(0, pName);
		}
		return data;
	}
}