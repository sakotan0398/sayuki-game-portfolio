package sayukiGame.model.bo.scnarioDataCommon;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;

public class PhaseED {

	public ScenarioData getScenario(int step, String edType, String pName) {
		ScenarioData data = new ScenarioData();
		data.setPoolType("Ending");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 

		// ==========================================
		// 👑 True End：最高のパートナー兼恋人
		// ==========================================
		if ("True".equals(edType)) {
			switch (step) {
			case 0:
				data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "fade", "normal", "day"));
				data.setMessage(
					"[NAME:NONE]マスターアップから数ヶ月後。俺たちが作ったゲームは、インディーゲーム界隈で瞬く間に話題となり、異例の大ヒットを記録した。" +
					"[NEXT]" +
					"[NAME:NONE]パブリッシャーからのオファー、メディアからの取材依頼。怒涛のような日々を乗り越え……今日、俺たちは都内の綺麗なオフィスビルの一室にいた。" +
					"[NEXT]" +
					"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「……すごいですね。まさか、二人で本当にゲーム会社を立ち上げることになるなんて」" +
					"[NEXT]" +
					"[NAME:PLAYER]「サユキ代表取締役。これからは社長って呼ばないとな」" +
					"[NEXT]" +
					"[IMG:Sayuki_dakara.png][NAME:SAYUKI]「からかわないでください！ 私は絵を描くことしかできません。……あなたが隣で、最高のコードを書いてくれないと、すぐに倒産しちゃいますよ」" +
					"[NEXT]" +
					"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……思えば、あの狭いアトリエにあなたが来てくれた日から、私の世界は大きく変わり始めたんです」" +
					"[NEXT]" +
					"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「最初は、絶対に自分の領域に踏み込ませないって警戒してたのに。……いつの間にか、あなたのタイピング音が聞こえないと、不安で絵が描けなくなってました」" +
					"[NEXT]" +
					"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……ねぇ、" + pName + "さん。会社としての契約書にはサインしましたけど……。私たち、公私ともにパートナーになるっていう『裏契約』も、ちゃんと結びましたよね？」"
				);
				data.setChoice1Text("一生、サユキの専属エンジニアで、彼氏だよ");
				data.setChoice2Text("まずは最高のビジネスパートナーとして、よろしく");
				data.setChoice3Text("裏契約？ 何のことだっけ？");

				data.setRes1("[IMG:Sayuki_surprised.png][NAME:SAYUKI]「っ！ ～～～っ、そういうこと、社長室で堂々と言わないでくださいっ」[NEXT][IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……でも。……嬉しい、です。……これからも、ずっと私の隣で、私だけのバグを直してくださいね」[NEXT][IMG:Sayuki_nomal.png][NAME:SAYUKI]「……愛してます、" + pName + "。さあ、私たちの新しい世界を作りに行きましょう！」[NEXT]👑【 True End：境界線のないアトリエ 】");
				data.setRes2("[IMG:Sayuki_nomal.png][NAME:SAYUKI]「……もう。そういう真面目なところも、あなたらしいですけど」[NEXT][IMG:Sayuki_dakara.png][NAME:SAYUKI]「でも、覚悟しておいてくださいね。仕事でもプライベートでも、絶対に逃がしませんから」[NEXT][IMG:Sayuki_nomal.png][NAME:SAYUKI]「さあ、私たちの新しい世界を作りに行きましょう！」[NEXT]👑【 True End：境界線のないアトリエ 】");
				data.setRes3("[IMG:Sayuki_surprised.png][NAME:SAYUKI]「……は？ 嘘ですよね？ 私、あんなに恥ずかしい思いをして……っ」[NEXT][IMG:Sayuki_dakara.png][NAME:SAYUKI]「もういいです！ 今すぐ仕様書（婚姻届）にサインさせますからね！」[NEXT][IMG:Sayuki_nomal.png][NAME:SAYUKI]「……逃がしませんから。さあ、新しい世界を作りますよ！」[NEXT]👑【 True End：境界線のないアトリエ 】");
				break;
			case 1:
				data.setMessage(""); data.setChoice1Text("エンディングへ"); data.setChoice2Text("エンディングへ"); data.setChoice3Text("エンディングへ");
				break;
			}

		// ==========================================
		// 💖 Love End：最高の恋人
		// ==========================================
		} else if ("Love".equals(edType)) {
			switch (step) {
			case 0:
				data.setVisuals(new VisualBeans("Sayuki_mesorasi.png", bgNight, "fade", "normal", "night"));
				data.setMessage(
					"[NAME:NONE]ゲームのリリースデータ送信ボタンを押した直後。平和な静寂が戻ってきた深夜のアトリエ。" +
					"[NEXT]" +
					"[NAME:NONE]俺のデスクの横には、キャスター付きの椅子を寄せてきて、俺の肩に頭を預けて眠るサユキの姿があった。" +
					"[NEXT]" +
					"[NAME:SAYUKI]「……んっ……むにゃ……。" + pName + "さん、そのコード……ちがう……」" +
					"[NEXT]" +
					"[NAME:PLAYER]（寝言でも開発してるのか。……本当によく頑張ったな）" +
					"[NEXT]" +
					"[NAME:NONE]壊れ物に触れるように優しく頭を撫でてやると、彼女はゆっくりと目を覚ました。" +
					"[NEXT]" +
					"[IMG:Sayuki_surprised.png][NAME:SAYUKI]「……あ、あれ。私、寝ちゃって……。……って、近っ！」" +
					"[NEXT]" +
					"[IMG:Sayuki_anxiety.png][NAME:SAYUKI]「ご、ごめんなさい、重かったですよね……っ。……あれ？ 終わっ……たんですか？」" +
					"[NEXT]" +
					"[NAME:PLAYER]「ああ、無事に全部送信されたよ。俺たちの仕事は、これで一旦終わりだ」" +
					"[NEXT]" +
					"[NAME:NONE]その言葉を聞いた瞬間、彼女の目からポロポロと大粒の涙がこぼれ落ちた。" +
					"[NEXT]" +
					"[IMG:Sayuki_anxiety.png][NAME:SAYUKI]「……っ。……うぅ……。終わっちゃった……。……終わったら、あなたは……どうするんですか……？」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「契約終了だからって……いなくならないでくださいね。……私、もうあなたがいなきゃ、ダメになっちゃったんだから……っ」"
				);
				data.setChoice1Text("どこにも行かないよ。仕事が終わってもサユキの彼氏としてここにいるよ");
				data.setChoice2Text("泣かないで。ずっとそばにいるよ");
				data.setChoice3Text("じゃあ、これからは俺を養ってね");

				data.setRes1("[IMG:Sayuki_surprised.png][NAME:SAYUKI]「……っ！ ……ほ、ほんとですね？ 絶対ですからね……っ」[NEXT][IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……。私の彼氏の特権ですから、頭撫でるの、許可してあげます」[NEXT][NAME:NONE]ゲーム開発が終わっても、甘い日常はずっと続く。[NEXT]💖【 Love End：私だけのエンジニア 】");
				data.setRes2("[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……ずるいです、そういう優しく甘やかすところ……」[NEXT][IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……もうちょっとだけ、このまま……抱きしめてて、ください」[NEXT][NAME:NONE]ゲーム開発が終わっても、甘い日常はずっと続く。[NEXT]💖【 Love End：私だけのエンジニア 】");
				data.setRes3("[IMG:Sayuki_jitome.png][NAME:SAYUKI]「……え？ あ、ヒモ志願ですか……？ まさかのクズ発言……！？」[NEXT][IMG:Sayuki_nomal.png][NAME:SAYUKI]「……ふふ。いいですよ。私の稼ぎで、一生囲ってあげます」[NEXT][NAME:NONE]ゲーム開発が終わっても、甘い日常はずっと続く。[NEXT]💖【 Love End：私だけのエンジニア 】");
				break;
			case 1:
				data.setMessage(""); data.setChoice1Text("エンディングへ"); data.setChoice2Text("エンディングへ"); data.setChoice3Text("エンディングへ");
				break;
			}

		// ==========================================
		// 🤝 Like End：最高のバディ
		// ==========================================
		} else if ("Like".equals(edType)) {
			switch (step) {
			case 0:
				data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "fade", "normal", "day"));
				data.setMessage(
					"[NAME:NONE]ゲームの大ヒットを記念した、関係者だけの小さな打ち上げの席。" +
					"[NEXT]" +
					"[NAME:SAYUKI]「お疲れ様です、" + pName + "さん。私たちの最高傑作、大反響ですね！ 各所からレビューの嵐です」" +
					"[NEXT]" +
					"[NAME:PLAYER]「ああ、サユキのアートと俺のシステムが完璧に噛み合った最高の結果だね」" +
					"[NEXT]" +
					"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「ええ。あなたの書いたあの変態的な最適化コードがなければ、私のイラストはあんなに滑らかに動きませんでした」" +
					"[NEXT]" +
					"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……正直に言います。最初は、ただの口うるさいアドバイザーだと思ってました。でも、あなたの技術力は本物でした。……完敗です」" +
					"[NEXT]" +
					"[NAME:NONE]彼女はそう言って、初めて俺に対して、心からの敬意を込めてグラスを掲げた。" +
					"[NEXT]" +
					"[IMG:Sayuki_dakara.png][NAME:SAYUKI]「……ということで。休む暇なんて与えませんよ？ 次の新作の企画書、もう書き上がってますから」" +
					"[NEXT]" +
					"[NAME:NONE]ドンッ、と分厚いファイルの束がテーブルに置かれる。中には、さらにスケールアップした次回作の構想がびっしりと書かれていた。" +
					"[NEXT]" +
					"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「言ったでしょ？ 一生、私のコードを書いてもらうって。……覚悟してくださいね、相棒（バディ）」"
				);
				data.setChoice1Text("望むところだ。最高の開発環境を用意してくれよ");
				data.setChoice2Text("一生こき使われるのか……仕方ないな");
				data.setChoice3Text("ちょっと待って、有給休暇は？");

				data.setRes1("[IMG:Sayuki_nomal.png][NAME:SAYUKI]「ええ！ 私たちが組めば、業界の覇権を取るのも時間の問題です！」[NEXT][IMG:Sayuki_dakara.png][NAME:SAYUKI]「さあ、明日からまた徹夜ですよ、相棒！」[NEXT][NAME:NONE]恋愛の枠に収まらない、唯一無二の戦友として。[NEXT]🤝【 Like End：最高の相棒（バディ） 】");
				data.setRes2("[IMG:Sayuki_nomal.png][NAME:SAYUKI]「ふふっ、嫌そうな顔して、実は楽しみにしてるの知ってますよ」[NEXT][IMG:Sayuki_nomal.png][NAME:SAYUKI]「あなたの能力を100%引き出せるのは、世界で私だけですからね」[NEXT][NAME:NONE]恋愛の枠に収まらない、唯一無二の戦友として。[NEXT]🤝【 Like End：最高の相棒（バディ） 】");
				data.setRes3("[IMG:Sayuki_jitome.png][NAME:SAYUKI]「有給？ クリエイターの辞書にそんな言葉はありません！」[NEXT][IMG:Sayuki_dakara.png][NAME:SAYUKI]「さあ、まずはこの企画書のレビューから徹夜でお願いしますね！」[NEXT][NAME:NONE]恋愛の枠に収まらない、唯一無二の戦友として。[NEXT]🤝【 Like End：最高の相棒（バディ） 】");
				break;
			case 1:
				data.setMessage(""); data.setChoice1Text("エンディングへ"); data.setChoice2Text("エンディングへ"); data.setChoice3Text("エンディングへ");
				break;
			}

		// ==========================================
		// 🍃 Normal End：普通の友人・知り合い
		// ==========================================
		} else {
			switch (step) {
			case 0:
				data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgSunset, "fade", "normal", "sunset"));
				data.setMessage(
					"[NAME:NONE]ゲームの納品が完了し、このオフィスの契約が満了した日。" +
					"[NEXT]" +
					"[NAME:NONE]俺が自分の機材をすべてダンボールに詰め終えると、サユキが入り口まで見送りに来てくれた。" +
					"[NEXT]" +
					"[NAME:SAYUKI]「……一年間、ありがとうございました。至らない代表で、ご迷惑もおかけしたと思います」" +
					"[NEXT]" +
					"[NAME:PLAYER]「そんなことないよ。素晴らしい経験になった。ゲーム、完成してよかったな」" +
					"[NEXT]" +
					"[IMG:Sayuki_mesorasi.png][NAME:SAYUKI]「……はい。あなたのアドバイスのおかげで、なんとか形にすることができました」" +
					"[NEXT]" +
					"[NAME:NONE]床を見ると、俺が初めてこのアトリエに来た日に引かれた『境界線のテープ』の跡が、薄っすらと残っていた。" +
					"[NEXT]" +
					"[NAME:PLAYER]（結局、俺たちは最後まで、あの線を完全に踏み越えることはできなかったのかもしれないな）" +
					"[NEXT]" +
					"[IMG:Sayuki_nomal.png][NAME:SAYUKI]「……。……そういえば、合鍵。返していただかないと」" +
					"[NEXT]" +
					"[NAME:NONE]俺はポケットから鍵を取り出し、彼女の手のひらに落とした。金属の冷たい音が、アトリエに響く。"
				);
				data.setChoice1Text("じゃあ、元気でな。これからの活躍を祈ってるよ");
				data.setChoice2Text("たまには連絡してきてもいいからな");
				data.setChoice3Text("バグが出たら、いつでも呼んでくれ");

				data.setRes1("[IMG:Sayuki_anxiety.png][NAME:SAYUKI]「……はい。あなたも、お元気で」[NEXT][NAME:NONE]深々と頭を下げる彼女。アトリエのドアが閉まる音。[NEXT][NAME:NONE]少しの寂しさを胸に、俺は歩き出す。[NEXT]🍃【 Normal End：境界線の向こう側 】");
				data.setRes2("[IMG:Sayuki_nomal.png][NAME:SAYUKI]「……ふふ。バグで泣きそうになったら、少しだけ愚痴を聞いてもらうかもしれません」[NEXT][IMG:Sayuki_anxiety.png][NAME:SAYUKI]「……お元気で。さようなら」[NEXT][NAME:NONE]少しの寂しさを胸に、俺は歩き出す。[NEXT]🍃【 Normal End：境界線の向こう側 】");
				data.setRes3("[IMG:Sayuki_nomal.png][NAME:SAYUKI]「……もうバグなんて出しませんよ。私一人でも、ちゃんとやれますから」[NEXT][IMG:Sayuki_anxiety.png][NAME:SAYUKI]「……今まで、本当にありがとうございました」[NEXT][NAME:NONE]少しの寂しさを胸に、俺は歩き出す。[NEXT]🍃【 Normal End：境界線の向こう側 】");
				break;
			case 1:
				data.setMessage(""); data.setChoice1Text("エンディングへ"); data.setChoice2Text("エンディングへ"); data.setChoice3Text("エンディングへ");
				break;
			}
		}

		return data;
	}
}