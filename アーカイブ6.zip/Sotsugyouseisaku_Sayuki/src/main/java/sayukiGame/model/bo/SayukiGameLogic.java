package sayukiGame.model.bo;

import sayukiGame.model.beans.Player;
import sayukiGame.model.beans.Sayuki_Sakota;
import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.bo.scnarioDataIvent.Ivent_Spring;
import sayukiGame.model.bo.scnarioDataIvent.Ivent_Winter;
import sayukiGame.model.bo.scnarioDataIvent.Ivent_fess;
import sayukiGame.model.dao.SayukiGameDAO;

public class SayukiGameLogic {

	// =============================================================
	// ① ロード時（doGet）や会話取得時に、画面を寸分狂わず復元するメソッド
	// =============================================================
	public ScenarioData getScenarioData(int phaseLevel, int scenarioNum, Player p, Sayuki_Sakota s) {
		String pName = p.getName();

		// 1. 特別イベント中（Phase 97, 98, 99）のロード復元
		if (phaseLevel == 97) {
			return new Ivent_Spring().getScenario(scenarioNum, pName, s); // 🌸春
		}
		if (phaseLevel == 98) {
			return new Ivent_fess().getScenario(scenarioNum, pName, s); // 🌻夏
		}
		if (phaseLevel == 99) {
			return new Ivent_Winter().getScenario(scenarioNum, pName, s); // ⛄冬
		}

		// 🌟ギャラリーから呼ばれる「おまけシナリオ（後日談：Phase 100〜103）」の呼び出し
		if (phaseLevel == 100)
			return new sayukiGame.model.bo.scnarioDataBonus.Bonus_True().getScenario(scenarioNum, pName);
		if (phaseLevel == 101)
			return new sayukiGame.model.bo.scnarioDataBonus.Bonus_Love().getScenario(scenarioNum, pName);
		if (phaseLevel == 102)
			return new sayukiGame.model.bo.scnarioDataBonus.Bonus_Like().getScenario(scenarioNum, pName);
		if (phaseLevel == 103)
			return new sayukiGame.model.bo.scnarioDataBonus.Bonus_Normal().getScenario(scenarioNum, pName);

		// 2. エピローグ（Phase 6）
		if (phaseLevel == 6) {
			String edType = "Normal";
			if (s.getLovePoint() >= 80 && s.getLikePoint() >= 80)
				edType = "True";
			else if (s.getLovePoint() >= 80)
				edType = "Love";
			else if (s.getLikePoint() >= 80)
				edType = "Like";

			return new sayukiGame.model.bo.scnarioDataCommon.PhaseED().getScenario(scenarioNum, edType, pName);
		}

		// 3. Phase 3以降（ルート分岐）
		if (phaseLevel >= 3) {
			int loveP = s.getLovePoint();
			int likeP = s.getLikePoint();
			int lLv = Math.min(5, (loveP / 20) + 1);
			int iLv = Math.min(5, (likeP / 20) + 1);

			if (phaseLevel == 3) {
				if (lLv >= 3 && iLv >= 3)
					return new sayukiGame.model.bo.scnarioDataTrue.TruePhase3().getScenario(scenarioNum, pName);
				if (lLv >= 3)
					return new sayukiGame.model.bo.scnarioDataLove.LovePhase3().getScenario(scenarioNum, pName);
				if (iLv >= 3)
					return new sayukiGame.model.bo.scnarioDataLike.LikePhase3().getScenario(scenarioNum, pName);
				return new sayukiGame.model.bo.scnarioDataCommon.Phase3().getScenario(scenarioNum, pName);
			}
			if (phaseLevel == 4) {
				if (lLv >= 4 && iLv >= 4)
					return new sayukiGame.model.bo.scnarioDataTrue.TruePhase4().getScenario(scenarioNum, pName);
				if (lLv >= 4)
					return new sayukiGame.model.bo.scnarioDataLove.LovePhase4().getScenario(scenarioNum, pName);
				if (iLv >= 4)
					return new sayukiGame.model.bo.scnarioDataLike.LikePhase4().getScenario(scenarioNum, pName);
				return new sayukiGame.model.bo.scnarioDataCommon.Phase4().getScenario(scenarioNum, pName);
			}
			if (phaseLevel == 5) {
				if (lLv >= 5 && iLv >= 5)
					return new sayukiGame.model.bo.scnarioDataTrue.TruePhase5().getScenario(scenarioNum, pName);
				if (lLv >= 5)
					return new sayukiGame.model.bo.scnarioDataLove.LovePhase5().getScenario(scenarioNum, pName);
				if (iLv >= 5)
					return new sayukiGame.model.bo.scnarioDataLike.LikePhase5().getScenario(scenarioNum, pName);
				return new sayukiGame.model.bo.scnarioDataCommon.Phase5().getScenario(scenarioNum, pName);
			}
		}

		// 4. Phase 0〜2（共通）
		switch (phaseLevel) {
		case 0:
			return new sayukiGame.model.bo.scnarioDataCommon.Phase0().getScenario(scenarioNum, pName);
		case 1:
			return new sayukiGame.model.bo.scnarioDataCommon.Phase1().getScenario(scenarioNum, pName);
		case 2:
			return new sayukiGame.model.bo.scnarioDataCommon.Phase2().getScenario(scenarioNum, pName);
		default:
			return new sayukiGame.model.bo.scnarioDataCommon.Phase0().getScenario(scenarioNum, pName);
		}
	}

	// =============================================================
	// ② 選択肢を選んだ時（doPost）に、次の会話やイベントを決定するメソッド
	// =============================================================
	public ScenarioData processTurn(int choice, int lastPhase, int lastNum, Sayuki_Sakota s, Player p, String userId) {
		String reaction = "";
		ScenarioData lastData = getScenarioData(lastPhase, lastNum, p, s);

		// --- 1. ポイント加算処理 ---
		if (lastData != null) {
			if (lastPhase == 97 || lastPhase == 98 || lastPhase == 99) {
				if (choice == 1) {
					s.setEventScore(s.getEventScore() + 8);
					s.addLovePoint(lastData.getC1Love());
					s.addLikePoint(lastData.getC1Like());
					reaction = lastData.getRes1();
				} else if (choice == 2) {
					s.setEventScore(s.getEventScore() + 8);
					s.addLovePoint(lastData.getC2Love());
					s.addLikePoint(lastData.getC2Like());
					reaction = lastData.getRes2();
				} else {
					s.addLovePoint(lastData.getC3Love());
					s.addLikePoint(lastData.getC3Like());
					reaction = lastData.getRes3();
				}
			} else {
				// 通常ターンの加算
				if (choice == 1) {
					s.addLovePoint(lastData.getC1Love());
					s.addLikePoint(lastData.getC1Like());
					reaction = lastData.getRes1();
				} else if (choice == 2) {
					s.addLovePoint(lastData.getC2Love());
					s.addLikePoint(lastData.getC2Like());
					reaction = lastData.getRes2();
				} else {
					s.addLovePoint(lastData.getC3Love());
					s.addLikePoint(lastData.getC3Like());
					reaction = lastData.getRes3();
				}
			}
		}

		// --- 2. 次の会話（ステート）の決定 ---
		int lovePhase = Math.min(5, (s.getLovePoint() / 20) + 1);
		int likePhase = Math.min(5, (s.getLikePoint() / 20) + 1);
		int currentPhase = Math.max(lovePhase, likePhase);
		int currentTurn = s.getCurrentTurn();
		ScenarioData nextData = null;

		// 【A】 51週目が終わったらエピローグ（Phase 6、ステップ0）へ強制突入！
		if (currentTurn == 51 && lastPhase != 6 && lastPhase < 90) {
			String edType = "Normal";
			if (s.getLovePoint() >= 80 && s.getLikePoint() >= 80)
				edType = "True";
			else if (s.getLovePoint() >= 80)
				edType = "Love";
			else if (s.getLikePoint() >= 80)
				edType = "Like";

			if (!"guest".equals(userId)) {
				new SayukiGameDAO().updateClearStatus(userId, edType); // 実績保存
			}
			nextData = getScenarioData(6, 0, p, s); // ここがスタート（ステップ0）
			nextData.setScenarioId(0);
			nextData.setPhaseLevel(6);

			// 🌟【B-1】 春夏冬イベントの「道中」進行（ステップ1〜4など）
		} else if ((lastPhase == 97 || lastPhase == 98 || lastPhase == 99) && lastNum < 5) {
			int nextStep = lastNum + 1;
			nextData = getScenarioData(lastPhase, nextStep, p, s);
			nextData.setScenarioId(nextStep);
			nextData.setPhaseLevel(lastPhase);

			// 🌟【B-2】 👑エンディング（Phase 6）：「ステップ0（読書・選択）」➔「ステップ1（リアクション画面）」へ
		} else if (lastPhase == 6 && lastNum == 0) {
			int nextStep = 1;
			nextData = getScenarioData(lastPhase, nextStep, p, s);
			nextData.setScenarioId(nextStep);
			nextData.setPhaseLevel(lastPhase);

			// 🌟【B-3】 👑エンディング最終話（ステップ1）読了時 ➔ Turnを「53」にしてending.jspへワープ！
		} else if (lastPhase == 6 && lastNum >= 1) {
			s.setCurrentTurn(53);
			nextData = new ScenarioData(); // 空データを送り、JSPの即時切り替えを誘発
			nextData.setPhaseLevel(6);
			nextData.setScenarioId(lastNum);

			// 🌟【B-4】🖼️おまけシナリオ（後日談）の「道中」進行（全10ページ：ステップ0〜9）
		} else if (lastPhase >= 100 && lastPhase <= 103 && lastNum < 9) {
			int nextStep = lastNum + 1;
			nextData = getScenarioData(lastPhase, nextStep, p, s);
			nextData.setScenarioId(nextStep);
			nextData.setPhaseLevel(lastPhase);

			// 🌟【B-5】🖼️おまけシナリオ最終ページ（ステップ9）読了時 ➔ ギャラリーへ送り返す！
		} else if (lastPhase >= 100 && lastPhase <= 103 && lastNum >= 9) { 
			nextData = new ScenarioData();
			nextData.setPhaseLevel(999);
			nextData.setScenarioId(lastNum);

			// ==================================================
			// 🌟 【C】 各種季節イベントの発生トリガー（ここがポイント！）
			// 特定の「期間内」で、かつ「ポイント条件」を満たしており、
			// なおかつ「まだそのイベントを見ていない」場合に割り込み発生！
			// ==================================================
		} else if (currentTurn >= 10 && currentTurn <= 15 && (s.getLovePoint() >= 20 || s.getLikePoint() >= 20)
				&& !s.isSpringEventSeen() && lastPhase < 90) {
			s.setSpringEventSeen(true); // 💡 一度発生したらフラグを立てて、二度と出ないようにする
			s.setEventScore(0);
			nextData = getScenarioData(97, 1, p, s);
			nextData.setScenarioId(1);
			nextData.setPhaseLevel(97);

		} else if (currentTurn >= 22 && currentTurn <= 28 && (s.getLovePoint() >= 40 || s.getLikePoint() >= 40)
				&& !s.isSummerEventSeen() && lastPhase < 90) {
			s.setSummerEventSeen(true);
			s.setEventScore(0);
			nextData = getScenarioData(98, 1, p, s);
			nextData.setScenarioId(1);
			nextData.setPhaseLevel(98);

		} else if (currentTurn >= 44 && currentTurn <= 50 && (s.getLovePoint() >= 70 || s.getLikePoint() >= 70)
				&& !s.isWinterEventSeen() && lastPhase < 90) {
			s.setWinterEventSeen(true);
			s.setEventScore(0);
			nextData = getScenarioData(99, 1, p, s);
			nextData.setScenarioId(1);
			nextData.setPhaseLevel(99);

		} else if (lastPhase == 0 && lastNum == 0) {
			nextData = getScenarioData(0, 1, p, s);
			nextData.setScenarioId(1);
			nextData.setPhaseLevel(0);

			// 【E】 通常の日常会話（ランダム抽選）
		} else {
			if (lastPhase == 97 || lastPhase == 98 || lastPhase == 99) {
				s.setEventScore(0);
				s.nextTurn(); // イベント終了時に通常タイムラインへ復帰
				currentTurn = s.getCurrentTurn();
			}

			int nextNum;
			int maxScenarios = (currentPhase >= 3) ? 15 : 10;
			do {
				nextNum = new java.util.Random().nextInt(maxScenarios);
			} while (nextNum == lastNum);

			nextData = getScenarioData(currentPhase, nextNum, p, s);
			nextData.setScenarioId(nextNum);
			nextData.setPhaseLevel(currentPhase);
		}

		// --- 3. メッセージ合体 ---
		String fullMessage = (reaction != null && !reaction.isEmpty()) ? reaction + "[NEXT]" + nextData.getMessage()
				: nextData.getMessage();
		nextData.setMessage(fullMessage);

		return nextData;
	}

	public String checkEnding(Sayuki_Sakota s) {
		boolean isLoveHigh = s.getLovePoint() >= 80;
		boolean isLikeHigh = s.getLikePoint() >= 80;
		if (isLoveHigh && isLikeHigh)
			return "True End：最高のパートナー兼恋人";
		if (isLoveHigh)
			return "Love End：最高の恋人";
		if (isLikeHigh)
			return "Like End：最高のバディ";
		return "Normal End：普通の友人・知り合い";
	}

	public String getCalendarDate(int turn) {
		int[] weeksInMonth = { 4, 5, 4, 5, 4, 4, 5, 4, 5, 4, 4, 4 };
		int tempTurn = turn;
		int currentMonth = 4;
		for (int i = 0; i < 12; i++) {
			if (tempTurn <= weeksInMonth[i]) {
				currentMonth = (4 + i > 12) ? 4 + i - 12 : 4 + i;
				String season = (currentMonth >= 3 && currentMonth <= 5) ? "🌸 春"
						: (currentMonth >= 6 && currentMonth <= 8) ? "🌻 夏"
								: (currentMonth >= 9 && currentMonth <= 11) ? "🍂 秋" : "⛄ 冬";
				return season + " " + currentMonth + "月 第" + tempTurn + "週";
			}
			tempTurn -= weeksInMonth[i];
		}
		return "不明な日付";
	}
}