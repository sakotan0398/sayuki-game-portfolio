package sayukiGame.model.bo.scnarioDataCommon;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;

public class Phase0 {

	public ScenarioData getScenario(int num, String pName) {
		ScenarioData data = new ScenarioData();
		data.setPoolType("Common");

		switch (num) {
		case 0: // 💡 ステップ0：廊下（誰もいない状態）
			data.setMessage(
					"[NAME:NONE]フリーランスのエンジニアとして独立して数年。" +
					"[NEXT]" +
					"[NAME:PLAYER]（ずっと自宅のデスクで作業していたが、代わり映えのしない景色と孤独感に、少し息が詰まってきたところだった）" +
					"[NEXT]" +
					"[NAME:PLAYER]（そんな時、仕事のオーナーのツテで『格安で間借りできるSOHOオフィス』を紹介してもらったのだ）" +
					"[NEXT]" +
					"[NAME:PLAYER]（『今は身内の女の子が管理人代わりに一人で使ってるだけだから、空いてる席を好きに使っていいよ。大人しい子だから』……か）" +
					"[NEXT]" +
					"[NAME:NONE]古い雑居ビルの廊下を進む。重厚な扉の前に立つと、かすかにPCの排気音のようなものが聞こえてきた。" +
					"[NEXT]" +
					"[NAME:PLAYER]（……中にいるみたいだな。どんな人だろう）");

			// 🌟 初期状態：背景は廊下、キャラ画像は無し（空文字）、演出は無し
			data.setVisuals(new VisualBeans("", "bg067800600.jpg", "none", "normal","day")); 

			data.setChoice1Text("丁寧にノックして開ける");
			data.setChoice2Text("軽く挨拶しながら開ける");
			data.setChoice3Text("静かにそっと開ける");

			// 選択後のリアクションテキスト
			data.setRes1("[NAME:NONE]コンコン、と礼儀正しくノックをしてから、ゆっくりとドアノブを回した。");
			data.setRes2("[NAME:PLAYER]「失礼しまーす」と、なるべく明るい声をかけながらドアを開けた。");
			data.setRes3("[NAME:NONE]中にいる人を驚かせないよう、息を潜めて静かにドアを開けた。");
			
			// リアクション後の画像：背景をアトリエに切り替えるが、キャラはまだ出さない
			VisualBeans enterRoomVisual = new VisualBeans("", "bg06819201440.jpg", "cross_fade", "normal","day");
			data.setRes1Visuals(enterRoomVisual);
			data.setRes2Visuals(enterRoomVisual);
			data.setRes3Visuals(enterRoomVisual);
			
			data.setScenarioId(0);
			break;

		case 1: // ステップ1：アトリエ・サユキ登場！
			data.setVisuals(new VisualBeans("", "bg06819201440.jpg", "none", "normal","day"));

			data.setMessage(
					"[NAME:NONE]ガチャリとドアを開けた瞬間、独特な空気が鼻を突いた。" +
					"[NEXT]" +
					"[NAME:NONE]遮光カーテンで閉ざされた薄暗い室内に、何台ものモニターの光が煌々と輝いている。デスク周りにはケーブルが這い、コーヒーの空きカップが積まれていた。" +
					"[NEXT]" +
					"[NAME:NONE]そして、奥の巨大な液晶タブレットに向かっているのは――" +
					"[NEXT]" +
					"[NAME:PLAYER]（……女の子！？ しかも……なんだあの服は）" +
					"[NEXT]" +
					"[NAME:NONE]ダボダボの特大ジャケットを羽織り、華奢な肩を無防備に露出させた、まるでサイバーパンクの世界から抜け出してきたような少女だった。" +
					"[NEXT]" +
					"[NAME:NONE]誰かが入ってきた気配に気づいたのか、ペンを動かしていた彼女がビクッと肩を震わせ、勢いよく振り返る。" +
					"[NEXT]" +
					"[IMG:Sayuki_surprised.png]" + 
					"[NAME:SAYUKI]「……っ！？ だ、誰ですかあなた！？ ここ、私しか使ってないはず……！」" +
					"[NEXT]" +
					"[NAME:NONE]彼女は咄嗟に胸元のジャケットをかき寄せ、信じられないものを見るような目でこちらを睨みつけた。");

			data.setChoice1Text("今日から間借りする" + pName + "です");
			data.setChoice2Text("オーナーから聞いてませんか？");
			data.setChoice3Text("……すごい服ですね");

			// 選択肢1：普通に返す
			data.setRes1(
					"[IMG:Sayuki_anxiety.png]" +
					"[NAME:SAYUKI]「えっ、" + pName + "……？ あっ、オーナーが言っていたフリーのエンジニア……」" +
					"[NEXT]" +
					"[IMG:Sayuki_dakara.png]" +
					"[NAME:SAYUKI]「……来るなら来るって、もっと事前に連絡を……っ。とにかく、ジロジロ見ないでください！」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「私は私のペースで仕事をしているんです。いくら同居人になったとはいえ、絶対に私の領域には干渉しないでくださいね」" +
					"[NEXT]" +
					"[NAME:PLAYER]（誰も来ないと思って、完全に油断していたらしい……。当分は警戒されそうだ）");
			data.setC1Love(0); data.setC1Like(0); // 普通の挨拶
			data.setRes1Visuals(new VisualBeans("Sayuki_dakara.png", "bg06819201440.jpg", "cross_fade", "normal","day"));

			// 選択肢2：少し理詰めで返す
			data.setRes2(
					"[IMG:Sayuki_musu.png]" +
					"[NAME:SAYUKI]「……聞いてはいましたけど、来月くらいからだと思ってたんです。急に来ないでください」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「ここは元々、私のプライベート空間だったんです。あなたが家賃を払っていようと、私の作業の邪魔だけはしないでください」" +
					"[NEXT]" +
					"[NAME:NONE]自分の聖域を侵された野良猫のように、彼女は強い警戒心を露わにしている。" +
					"[NEXT]" +
					"[NAME:PLAYER]（まいったな……。仲良くなるには相当時間がかかりそうだ）");
			data.setC2Love(0); data.setC2Like(1);
			data.setRes2Visuals(new VisualBeans("Sayuki_musu.png", "bg06819201440.jpg", "cross_fade", "normal","day"));

			// 選択肢3：怒らせる
			data.setRes3(
					"[IMG:Sayuki_scary_smile.png]" +
					"[NAME:SAYUKI]「……は？ 初対面の人にいきなりそれですか？ デリカシーって言葉、知ってます？」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「ここは私の部屋です。私がどんな格好で作業しようが勝手でしょう。……最悪」" +
					"[NEXT]" +
					"[NAME:SAYUKI]「これ以上不快な発言をするなら、オーナーに言って即刻追い出しますからね。覚えておいてください」" +
					"[NEXT]" +
					"[NAME:NONE]恥ずかしさと怒りが入り交じったような、氷点下の視線で睨まれてしまった……。先が思いやられる。");
			data.setC3Love(0); data.setC3Like(0);
			data.setRes3Visuals(new VisualBeans("Sayuki_scary_smile.png", "bg06819201440.jpg", "cross_fade", "close_up","day"));
			
			data.setScenarioId(1);
			break;
		}
		return data;
	}
}