package sayukiGame.model.bo.scnarioDataCommon;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;

public class Phase3 {

	public ScenarioData getScenario(int num, String pName) {
		ScenarioData data = new ScenarioData();
		data.setPoolType("Common");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 
		
		switch (num) {
		case 0: // 【ケース0：境界線の侵食と言い訳】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]このオフィスを間借りし始めてしばらく。かつて彼女が引いた『絶対境界線』は、いつの間にか曖昧になっていた。" +
				"[NEXT]" +
				"[NAME:PLAYER]（ふと気づくと、サユキさんのラフ画や専門書が、俺のデスクの領域まで浸食してきている）" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……あ。すみません。少し資料がはみ出しました」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……でも、そっちのスペース、空いてますよね？ デッドスペースにするくらいなら、私が有効活用してあげてるんですからね」" +
				"[NEXT]" +
				"[NAME:PLAYER]（相変わらず素直じゃないが、警戒心が薄れているのは間違いない）"
			);
			data.setChoice1Text("全然。むしろ仕事の刺激になるよ");
			data.setChoice2Text("じゃあ、俺の機材もそっちに置いていい？");
			data.setChoice3Text("もっとこっちに寄ってきてもいいよ");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……刺激、ですか。……まぁ、エンジニアにとってもUIの設計思想を知ることはマイナスにはならないでしょうし」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「特別に、私のアイデアの源泉を見ることを許可します。……片付けが面倒なわけじゃありませんよ」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は満足げに言い訳を並べた。プロとしての理解を示したことで、信頼が深まったようだ。"
			);
			data.setC1Love(0); data.setC1Like(4); // 【Like特化】作業環境の共有

			data.setRes2(
				"[IMG:Sayuki_musu.png]" +
				"[NAME:SAYUKI]「……は？ なんでそうなるんですか。あなたの無骨な機材なんて置かれたら、私の美的感覚が狂います」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも、まぁ。……小さいUSBメモリとか、それくらいなら……置いてあげなくもないです」" +
				"[NEXT]" +
				"[NAME:NONE]文句を言いつつも、少しだけ妥協してくれた。お互いの距離が少しずつ近づいている。"
			);
			data.setC2Love(2); data.setC2Like(2); // 【バランス正解】

			data.setRes3(
				"[IMG:Sayuki_scary_smile.png]" +
				"[NAME:SAYUKI]「……調子に乗らないでください。あくまで『資料』がはみ出しただけで、私があなたにすり寄ったわけじゃありません」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「これ以上不快な発言をするなら、その口をガムテープで塞ぎますよ」" +
				"[NEXT]" +
				"[NAME:NONE]完全に警戒されてしまった。不用意に距離を詰めるべきではなかった。"
			);
			data.setC3Love(-2); data.setC3Like(-2); // 【失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_scary_smile.png", bgDay, "cross_fade", "close_up", "day"));
			break;

		case 1: // 【ケース1：カフェラテの密約（素顔の露呈）】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]サユキが共有キッチンで淹れた『プロ仕様のブラックコーヒー』。" +
				"[NEXT]" +
				"[NAME:PLAYER]（……ん？ 今、サユキさん……）" +
				"[NEXT]" +
				"[NAME:NONE]俺は見てしまった。彼女がキッチンカウンターの死角で、ガムシロップとミルクを３つずつ、必死にコーヒーに投入している姿を。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「なっ！？ ……っ、見、見てたんですか！？」" +
				"[NEXT]" +
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「ち、違います！ これは脳の糖分が足りない時の緊急措置です！ 私が甘党だとか、苦いのが飲めないとか、そういう低俗な理由じゃありません！」"
			);
			data.setChoice1Text("わかる。エンジニアも糖分必須だからね");
			data.setChoice2Text("今度、俺が美味しいカフェラテ淹れるよ");
			data.setChoice3Text("お子様舌なんだね（弄る）");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……わ、分かってくれますか？ そうなんです、クリエイターたるもの、常に血糖値をコントロールしなければ……」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……コホン。とにかく、この『戦略的糖分補給』のことはオーナーには絶対内緒ですからね」" +
				"[NEXT]" +
				"[NAME:NONE]理屈でフォローしたことで、彼女はホッと胸を撫で下ろした。秘密を共有したことで信頼が上がった。"
			);
			data.setC1Love(1); data.setC1Like(4); // 【Like特化】プロとしての擁護

			data.setRes2(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……エンジニアが淹れるカフェラテ？ ……分量も適当な素人の味なんて、期待してませんけど」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……でも。……どうしてもあなたが淹れたいと言うなら、実験台くらいにはなってあげます」" +
				"[NEXT]" +
				"[NAME:NONE]彼女なりの言い回しで、提案を受け入れてくれた。強がっているが、少し嬉しそうだ。"
			);
			data.setC2Love(4); data.setC2Like(1); // 【Love寄り】ツンデレのデレを引き出す

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。そうですか。あなたの中ではそういう認識なんですね」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「二度と口きかないでください。次話しかけたら、あなたの書いたコード、全部削除してやりますから」" +
				"[NEXT]" +
				"[NAME:NONE]本気で怒らせてしまった。彼女のプライドをからかうのはご法度だ。"
			);
			data.setC3Love(-3); data.setC3Like(-3); // 【大失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_jitome.png", bgDay, "cross_fade", "close_up", "day"));
			break;

		case 2: // 【ケース2：深夜のLive2Dと意地】
			data.setVisuals(new VisualBeans("Sayuki_anxiety.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]深夜のアトリエ。サユキが制作中のLive2Dモデルの挙動が、どうしても不自然で詰まっているらしい。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……うぅ。ここ、物理演算の計算式が干渉し合って、まばたきする度に髪が荒ぶる……」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女はイラストの天才だが、こういったロジカルなトラブルにはまだ弱い）" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……っ。見ないでください。これくらい、自分で直せますから」"
			);
			data.setChoice1Text("俺がデバッグ用のスクリプト書こうか？");
			data.setChoice2Text("頑張れ。プロの意地、見せてよ");
			data.setChoice3Text("そんなポンコツな動きも可愛いよ");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……スクリプト？ そんな方法で解決できるんですか？」" +
				"[NEXT]" +
				"[NAME:NONE]俺が数分でコードを書き換えると、モデルは嘘のように滑らかに動き始めた。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……。流石、ですね。……技術力の差を、まざまざと見せつけられました。……。……ありがとうございます」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は悔しそうに唇を噛みながらも、エンジニアとしての俺に最大限の敬意を払ってくれた。"
			);
			data.setC1Love(1); data.setC1Like(5); // 【Like最大】エンジニアとしての絶対的信頼

			data.setRes2(
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……言われなくても。……ここで妥協したら、クリエイター失格ですから」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……。……見守っててください。絶対に、完璧に動かしてみせます」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の負けず嫌いな心に火をつけたようだ。自立したプロとしての関係性が強まった。"
			);
			data.setC2Love(3); data.setC2Like(2); // 【バランス正解】

			data.setRes3(
				"[IMG:Sayuki_scary_smile.png]" +
				"[NAME:SAYUKI]「……馬鹿にしてるんですか？」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「私は『可愛いゴミ』を作りたいんじゃなくて、完璧な『作品』を作りたいんです。不真面目な評価はいりません」" +
				"[NEXT]" +
				"[NAME:NONE]完全に逆鱗に触れた。クリエイターとしての苦悩を軽視してしまった。"
			);
			data.setC3Love(-3); data.setC3Like(-3); // 【大失敗】
			data.setRes3Visuals(new VisualBeans("Sayuki_scary_smile.png", bgNight, "cross_fade", "close_up", "night"));
			break;

		case 3: // 【ケース3：視線の交差点とごまかし】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]夕暮れ時。複雑なアルゴリズムの実装を終え、俺はふうっと大きく息を吐いて視線を上げた。" +
				"[NEXT]" +
				"[NAME:NONE]ーーその瞬間。すぐ隣のデスクから、こちらをじっと見つめていたサユキと、バッチリ目が合った。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「…………っ」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:NONE]彼女はハッとしてすぐに目を逸らしたが、どこか気まずそうに自分の髪の毛をいじっている。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……なんですか。人の顔に何か付いてますか？」"
			);
			data.setChoice1Text("いや、真剣な顔しててかっこいいなと");
			data.setChoice2Text("俺の顔にバグでも付いてた？");
			data.setChoice3Text("見とれちゃってさ");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……っ。……当たり前です。仕事中なんですから」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「あなたこそ、集中力が切れてるんじゃないですか？ 私はあなたの作業ペースを観察してただけです。勘違いしないでください」" +
				"[NEXT]" +
				"[NAME:NONE]言い訳がましいが、プロとしての評価を交えたことで、彼女も悪い気はしていないようだ。"
			);
			data.setC1Love(2); data.setC1Like(3); // 【Like寄り】

			data.setRes2(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……ええ。あなたの存在自体が私の集中力をバグらせてるんです。責任取ってください」" +
				"[NEXT]" +
				"[NAME:NONE]冗談めかして言ったつもりだったが、思いのほかストレートな言葉が返ってきて、逆にこちらがドキッとしてしまった。"
			);
			data.setC2Love(4); data.setC2Like(1); // 【Love寄り】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。……いきなり何を。……思考回路ショートしたんですか？」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「そういうのは……もう少し、マシな場所で言ってください。ここ、職場ですよ。……馬鹿なんですか？」" +
				"[NEXT]" +
				"[NAME:NONE]突き放されたが、彼女の顔は夕日の赤さよりもずっと赤くなっていた。好感度は上がったが、仕事仲間としての信頼は少し損ねたかもしれない。"
			);
			data.setC3Love(4); data.setC3Like(-2); // 【ハイリスク・ハイリターン】
			data.setRes3Visuals(new VisualBeans("Sayuki_jitome.png", bgSunset, "cross_fade", "close_up", "sunset"));
			break;
			
		case 4: // 【ケース4：休日の過ごし方と不可侵条約】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:SAYUKI]「そういえば、" + pName + "さん。……あなたは休みの日は、どこで何をしているんですか？」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「オーナーが、あなたはたまに一人で変な場所に出かけるって言ってましたけど。……同居人として、不審な行動を取られては困るので」" +
				"[NEXT]" +
				"[NAME:PLAYER]（ついに休日の過ごし方を聞かれた。言い訳がましいが、彼女なりにこちらに興味を持ち始めたのだろうか）"
			);
			data.setChoice1Text("今度の休み、一緒に出かけない？");
			data.setChoice2Text("新しいデバイスの視察とかかな");
			data.setChoice3Text("ずっと寝てるよ。不健康でしょ？");

			data.setRes1(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……は？ なんで私が貴重な休日を削って、あなたと外を歩かなければならないんですか？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……それに、私はインドア派です。……どうしても私の意見が必要な周辺機器の買い出しとかなら、考えてもいいですけど」" +
				"[NEXT]" +
				"[NAME:NONE]冷たくあしらわれたが、条件付きながら完全には否定されなかった。誘うにはまだ少し早かったようだ。"
			);
			data.setC1Love(2); data.setC1Like(-1); // 【Love微増】デレるには早すぎるためLikeは下がる

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……なるほど。エンジニアなら常に最新のハードウェアをチェックしておくべきですね。納得しました」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「今度、私が使ってる液タブの最新モデルも見てきてください。あなたのフラットな意見が聞きたいです」" +
				"[NEXT]" +
				"[NAME:NONE]不審がられることなく、プロとしてのリスペクトを得た。一歩ずつ、確実に彼女の信頼を得ている実感がある。"
			);
			data.setC2Love(1); data.setC2Like(4); // 【Like最大】プロとしての価値観が一致

			data.setRes3(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……自覚があるなら少しは外の空気を吸ってください。ここで倒れられたら、事故物件になって私が困るんです」" +
				"[NEXT]" +
				"[NAME:NONE]呆れたように小言を言われてしまった。今の彼女にとって、俺は『放っておくと面倒な職場仲間』くらいの認識らしい。"
			);
			data.setC3Love(1); data.setC3Like(1); // 【微増】
			break;

		case 5: // 【ケース5：ペンの落下と過剰反応】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]コロコロ……と、サユキの机から液タブ用のペンが転がり落ち、俺の足元へ転がってきた。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「あ……っ！」" +
				"[NEXT]" +
				"[NAME:PLAYER]（俺はペンを拾い上げ、彼女の方へと手を伸ばした）"
			);
			data.setChoice1Text("はい、どうぞ");
			data.setChoice2Text("（わざと手渡しで指先を触れさせる）");
			data.setChoice3Text("自分で拾いなよ");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……す、すみません。助かりました。このペン、重心のバランスが特殊で、落とすとヒヤッとするんです」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は少し早口で言い訳をしながらペンを受け取り、すぐに作業に戻った。スマートなやり取りにLikeが上がる。"
			);
			data.setC1Love(1); data.setC1Like(3); // 【Like寄り】

			data.setRes2(
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「っ！ ……な、何するんですか！ 触らないでください！」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……そういうの、本気で気持ち悪いので。次やったらパーテーション立てますからね」" +
				"[NEXT]" +
				"[NAME:NONE]一瞬指先が触れ合うと、彼女は過剰なほど激しく手を引っ込めた。心の距離を詰めるには、まだ焦りは禁物のようだ。"
			);
			data.setC2Love(-1); data.setC2Like(-2); // 【Love特化失敗】Phase3でこのアプローチはまだ拒絶される

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。そうですか。……足元のペンを拾うだけの思いやりもないんですね、あなたは」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は不機嫌そうに身を乗り出し、自分でペンを拾い上げた。完全に機嫌を損ねてしまった。"
			);
			data.setC3Love(-1); data.setC3Like(-2); // 【失敗】
			break;

		case 6: // 【ケース6：完成した線画と厳しい自己評価】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:SAYUKI]「ふぅー……っ。……よし」" +
				"[NEXT]" +
				"[NAME:NONE]サユキがペンを置き、椅子に深く背をもたれさせた。長時間の作業を終えたようだ。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……" + pName + "さん。少しだけ、見てくれませんか？ メインキャラの線画、一応終わったんですけど……」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女が自分から制作途中の絵を見せてくるのは珍しい。相当悩んでいるか、意見が欲しいのだろう）"
			);
			data.setChoice1Text("お疲れ様。すごく綺麗に描けてるよ");
			data.setChoice2Text("目のハイライトの入れ方、変えた？");
			data.setChoice3Text("少し右のバランスが崩れてるかも");

			data.setRes1(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……適当なこと言わないでください。『綺麗』なんて、誰でも言える無難な感想です」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「私はプロのエンジニアとしてのあなたの意見を求めたんです。……期待した私が馬鹿でした」" +
				"[NEXT]" +
				"[NAME:NONE]素直な労いの言葉は、今の彼女が求めているものではなかったようだ。"
			);
			data.setC1Love(0); data.setC1Like(-1); // 【Love寄り失敗】薄っぺらい褒め言葉は刺さらない

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！ わかりますか？ そうなんです、前回よりも少しだけレイヤーの透明度を弄って……」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……流石ですね。細かい変化を見抜く観察眼は、一応評価してあげます。……少しだけ、自信が出ました」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は誇らしげにモニターを指差した。クリエイター同士の純粋なリスペクトが心地よい。"
			);
			data.setC2Love(2); data.setC2Like(4); // 【Like特化・大正解】

			data.setRes3(
				"[IMG:Sayuki_anxiety.png]" +
				"[NAME:SAYUKI]「えっ？ ……右、ですか？ ……あ。……本当だ、パースが少し……」" +
				"[NEXT]" +
				"[IMG:Sayuki_musu.png]" +
				"[NAME:SAYUKI]「……。……言われなくても、後で直すつもりでした！ ……ご指摘、どうも！」" +
				"[NEXT]" +
				"[NAME:NONE]図星を突かれて悔しかったのか、彼女はムスッとして画面に向き直った。しかし、的確な指摘をしたことでエンジニアとしての信頼は少し上がった。"
			);
			data.setC3Love(-1); data.setC3Like(3); // 【Like寄り】
			break;

		case 7: // 【ケース7：眠気と強がり】
			data.setVisuals(new VisualBeans("Sayuki_mesorasi.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]作業中、ふと隣を見ると、サユキがうとうとと首を揺らしていた。" +
				"[NEXT]" +
				"[NAME:NONE]ガクッと頭が大きく揺れ、彼女はハッとして飛び起きた。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！ い、今、寝てませんよ！ まばたきの時間が少し長かっただけですっ」" +
				"[NEXT]" +
				"[NAME:PLAYER]（必死に目をこすって強がっているが、完全に限界のようだ……）"
			);
			data.setChoice1Text("寝顔、すごく可愛かったよ");
			data.setChoice2Text("15分だけ仮眠しなよ。俺が起こすから");
			data.setChoice3Text("俺のコーヒー、少し飲む？");

			data.setRes1(
				"[IMG:Sayuki_scary_smile.png]" +
				"[NAME:SAYUKI]「……なっ！？ み、見ないでくださいっ！ 気持ち悪い……！」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……最低です。もう、あなたの前では絶対に隙を見せませんからね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は両手で顔を覆い隠し、本気で怒ってしまった。距離感を間違えたようだ。"
			);
			data.setC1Love(-2); data.setC1Like(-2); // 【Love特化失敗】Phase3でこの発言は地雷

			data.setRes2(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……起こして、くれるんですか？ ……。……。……じゃあ、仕方ないですね」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「１５分後、キッカリに起こしてください。……もし放置したら、恨みますからね」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は不満げに言い捨てて、机に突っ伏した。だが、その背中は完全にこちらを信頼して預けられている。"
			);
			data.setC2Love(2); data.setC2Like(4); // 【Like特化・正解】安全なパートナーとしての信頼

			data.setRes3(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……！ ……い、いいんですか？ あなたが口をつけたマグカップなんて嫌ですけど……」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……紙コップで分けてくれるなら、もらってあげます。……苦いやつ、お願いします」" +
				"[NEXT]" +
				"[NAME:NONE]素直じゃないが、どうやらカフェインを欲していたのは事実らしい。少しだけ彼女の力になれた。"
			);
			data.setC3Love(2); data.setC3Like(2); // 【バランス正解】
			break;

		case 8: // 【ケース8：深夜の帰路と距離感】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]深夜。キリの良いところで作業を終え、俺が帰り支度をしていると、サユキがチラチラとこちらを見てきた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「あの、" + pName + "さん。……もう、帰るんですか？」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「私も、ちょうど……本当に、たった今キリが良くなったところなんですけど。……偶然ですね」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女の方から話しかけてくるなんて珍しい。これは……）"
			);
			data.setChoice1Text("じゃあ、一緒に駅まで帰る？");
			data.setChoice2Text("夜道は危ないし、送っていくよ");
			data.setChoice3Text("お疲れ様。戸締まりよろしくね");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「あ……っ。……はい。……一人で歩く深夜の廊下、少しだけ不気味だと思ってたんです」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:NONE]彼女は静かに荷物をまとめ、俺の少し後ろを歩き始めた。適度な距離感を保った、良い関係だ。"
			);
			data.setC1Love(2); data.setC1Like(3); // 【バランス正解】自然な流れ

			data.setRes2(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……送るって。私は子供じゃありません。一人で帰れます」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……でも、どうしてもあなたが心配性でついてきたいと言うなら……勝手についてくればいいじゃないですか」" +
				"[NEXT]" +
				"[NAME:NONE]少しムッとされたが、完全には拒絶されなかった。少し歩幅を合わせてくれる彼女の姿が印象的だった。"
			);
			data.setC2Love(4); data.setC2Like(0); // 【Love寄り】ツンデレの「ツン」を発動させるが、好感度は上がる

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。ええ、そうですね。私は管理人ですから。……。……お疲れ様でした。気をつけて」" +
				"[NEXT]" +
				"[NAME:NONE]どこか寂しそうで、怒気を孕んだ声に見送られ、俺は一人でアトリエを後にした。チャンスを完全に無駄にしてしまったようだ。"
			);
			data.setC3Love(-3); data.setC3Like(-2); // 【大失敗】
			break;

		default:
		}
		return data;
	}
}