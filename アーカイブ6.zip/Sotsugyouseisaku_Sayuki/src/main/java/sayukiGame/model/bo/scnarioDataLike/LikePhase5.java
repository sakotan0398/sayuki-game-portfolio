package sayukiGame.model.bo.scnarioDataLike;

import sayukiGame.model.beans.ScenarioData;
import sayukiGame.model.beans.VisualBeans;
import sayukiGame.model.bo.scnarioDataCommon.Phase5;

public class LikePhase5 extends Phase5 {

	@Override
	public ScenarioData getScenario(int num, String pName) {
		
		// 0〜8 は親クラス（Common）の、仕事の追い込みや達成感の共有を呼び出す
		if (num <= 8) {
			return super.getScenario(num, pName);
		}

		// 9〜14：Likeルート専用（プロ同士の深い信頼、代えのきかない『個』への敬意）
		ScenarioData data = new ScenarioData();
		data.setPoolType("Like");

		String bgDay = "bg06819201440.jpg"; 
		String bgSunset = "bg06819201440.jpg"; 
		String bgNight = "bg06819201440.jpg"; 

		switch (num) {
		case 9: // 【ケース9：主人公の納品と、彼女の評価】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]俺が受けていたフリーランスの大きな案件が一つ、無事に納品完了を迎えた。" +
				"[NEXT]" +
				"[NAME:PLAYER]「ふぅ……。ようやくこっちのプロジェクトも一段落だ」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「お疲れ様です。……さっきの最終デバッグのログ、少し見えましたけど」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「あの短期間で、これだけ堅牢な設計を一人で組むなんて。……正直、驚きました」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……流石ですね。管理人の代理として、あなたがここで仕事をしていることを誇らしく思います」"
			);
			data.setChoice1Text("サユキさんの集中力には負けるよ");
			data.setChoice2Text("俺の腕を見込んでここに入れたんでしょ？");
			data.setChoice3Text("次はサユキさんのゲームを完成させよう");

			data.setRes1(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「ふふ、そうですね。私の集中力はプロの間でも定評がありますから」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「お互い、妥協しない姿勢は似ているのかもしれませんね。……お疲れ様でした」" +
				"[NEXT]" +
				"[NAME:NONE]お互いの仕事の流儀を認め合い、静かに頷き合った。"
			);
			data.setC1Love(1); data.setC1Like(4); // 【Like寄り】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「っ！ ……相変わらず、憎たらしいほど自信満々ですね」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「でも、その自信を裏切らない成果を出す。……そういうプロ、私は嫌いじゃありません」" +
				"[NEXT]" +
				"[NAME:NONE]彼女なりの最大限の賛辞をもらえた。"
			);
			data.setC2Love(1); data.setC2Like(5); // 【Like最大】

			data.setRes3(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「言われなくても。……あなたの技術サポート、これからも存分に使い倒させてもらいますからね？」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の瞳には、更なる高みを目指す情熱が宿っていた。"
			);
			data.setC3Love(1); data.setC3Like(4);
			break;

		case 10: // 【ケース10：給湯室での技術談義】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgDay, "none", "normal", "day"));
			data.setMessage(
				"[NAME:NONE]休憩中、ビルの古びた給湯室でサユキと鉢合わせた。彼女はポットのお湯が沸くのをじっと待っている。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……最近、私のゲームのシェーダー周りの挙動、少し変えてみたんです」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「あなたが前に言っていた、グラフィックボードの負荷を分散させる考え方……。あれを応用したら、色の深みがもっと出せる気がして」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女は、俺が何気なく話した技術的なアドバイスを、自分の感性としっかり融合させていた）"
			);
			data.setChoice1Text("飲み込みが早いね。流石だよ");
			data.setChoice2Text("俺なら、もっと効率的なやり方を教えられるけど？");
			data.setChoice3Text("たまには仕事以外の話もしようよ");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……！ 私を誰だと思ってるんですか。天才ですよ？」" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……でも、ベースになるロジックが分かりやすかったからです。……感謝、してますよ」" +
				"[NEXT]" +
				"[NAME:NONE]湯気の中に、彼女の穏やかな微笑みが浮かんだ。"
			);
			data.setC1Love(2); data.setC1Like(4); // 【バランス正解】

			data.setRes2(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……ふん、強気ですね。じゃあ、戻ったらその『やり方』、コードで見せてください」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「口だけじゃないところ、期待してますから」" +
				"[NEXT]" +
				"[NAME:NONE]彼女の負けず嫌いに火をつけてしまった。これも彼女なりのコミュニケーションだ。"
			);
			data.setC2Love(1); data.setC2Like(5); // 【Like最大】

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……。今の私からクリエイティブを引いたら、何も残らないんですけど。……冷めました。戻ります」" +
				"[NEXT]" +
				"[NAME:NONE]作品作りに命を懸けている今の彼女にとって、仕事以外の話は無駄でしかなかったようだ。"
			);
			data.setC3Love(-3); data.setC3Like(-2); // 【大失敗】
			break;

		case 11: // 【ケース11：騒音から、環境音へ】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgSunset, "none", "normal", "sunset"));
			data.setMessage(
				"[NAME:NONE]夕暮れ。沈黙に包まれたアトリエに、二人の作業音だけが響く。" +
				"[NEXT]" +
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「……そういえば。出会った頃、あなたのタイピング音を『不快な騒音』だなんて言いましたよね」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……撤回します。今は、この音が聞こえないと……なんだか、自分のペースが掴めなくなってきました」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……。……変なバグが移ったんですかね」"
			);
			data.setChoice1Text("俺のタイピング音、録音してあげようか？");
			data.setChoice2Text("俺も、サユキさんの描く音が聞こえないと落ち着かないよ");
			data.setChoice3Text("それだけ、俺たちが慣れたってことだね");

			data.setRes1(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……いりません。本物の音じゃないと意味ないじゃないですか？ ……。……。……あ、今のは忘れてください」" +
				"[NEXT]" +
				"[NAME:NONE]墓穴を掘って真っ赤になる彼女。彼女の中で俺の存在が不可欠になっていることが伝わってきた。"
			);
			data.setC1Love(4); data.setC1Like(1); // 【Love寄り】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「……っ！ ……。……。……同じ、ですか」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……プロ同士、環境の好みが一致するのは、合理的ですね。……嫌いじゃないです、その感覚」" +
				"[NEXT]" +
				"[NAME:NONE]お互いの『仕事の音』が共鳴し合う。これ以上ないクリエイターとしての共感だ。"
			);
			data.setC2Love(3); data.setC2Like(5); // 【Like最大・大正解】

			data.setRes3(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……まぁ、そうですね。ただの馴れ合いと言えばそれまでですけど。……でも、悪くない変化、だと思いますよ」" +
				"[NEXT]" +
				"[NAME:NONE]淡々としているが、彼女なりの肯定を受け取ることができた。"
			);
			data.setC3Love(1); data.setC3Like(3);
			break;

		case 12: // 【ケース12：遺されたコードへの信頼】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]深夜。サユキが俺が昔書いた、共通ライブラリのソースコードを読み込んでいた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……" + pName + "さん。あなたのコード、コメントの一つ一つにまで……私の制作への配慮が感じられます」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「『将来的にグラフィックが変更されても、ここだけ変えれば対応できるように』……。そんな風に、私の先を見越して設計してくれていたんですね」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……ここまで私の作品に寄り添ってくれるエンジニア、他にいません」"
			);
			data.setChoice1Text("プロの仕事をしたまでだよ");
			data.setChoice2Text("サユキさんの作品を、俺の技術で守りたかったんだ");
			data.setChoice3Text("そんなところまで読んでたの？ 恥ずかしいな");

			data.setRes1(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……。冷たい言い方。……でも、そのストイックさがあったからこそ、私は安心して描けたんです」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「最高のプロに会えたこと、感謝します」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は尊敬の念を込めて頷いた。"
			);
			data.setC1Love(1); data.setC1Like(5); // 【Like最大】

			data.setRes2(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「守る……。……」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……。……。ずるいです。……技術者としての誠実さに、一人の人間としての優しさを混ぜるなんて。……反則ですよ」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は目を潤ませて、画面を見つめ直した。プロとしての信頼が、深い好意へと昇華していく。"
			);
			data.setC2Love(5); data.setC2Like(4); // 【True寄り・大正解】

			data.setRes3(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「ふふ、エンジニアが自分のソースコードを恥ずかしがるなんて。……美しく書けた自覚があるんでしょう？」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「自信を持ってください。……私が認めたコードなんですから」" +
				"[NEXT]" +
				"[NAME:NONE]穏やかな夜の時間が過ぎていった。"
			);
			data.setC3Love(1); data.setC3Like(4);
			break;

		case 13: // 【ケース13：乾杯と、無言の約束】
			data.setVisuals(new VisualBeans("Sayuki_nomal.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]深夜、少ない豆で淹れたカフェラテを二人で分け合った。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……乾杯、しませんか」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「お互い、最高に良い仕事ができたこと。……そして、このアトリエが……最高のチームになれたことに」" +
				"[NEXT]" +
				"[NAME:PLAYER]（彼女は少し震える手で、俺のコップに自分のコップを重ねた）"
			);
			data.setChoice1Text("俺たちの未来に乾杯");
			data.setChoice2Text("また明日からも、最高の仕事をしよう");
			data.setChoice3Text("飲み終わったら、残りのタスクやっつけようか");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「未来……。……。ええ、そうですね。私たちの物語は、まだ始まったばかりなんですから」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は幸せそうに目を細めた。運命を共にすることを選んだ二人の、誓いの儀式だった。"
			);
			data.setC1Love(5); data.setC1Like(3); // 【Love寄り】

			data.setRes2(
				"[IMG:Sayuki_nomal.png]" +
				"[NAME:SAYUKI]「はいっ！ 当然です。……私の背中を預けられるのは、あなたしかいないんですから」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「カチンッ」と乾いた音が響く。相棒としての固い握手を交わしたような、熱い夜だった。"
			);
			data.setC2Love(2); data.setC2Like(6); // 【Like最大・大正解】

			data.setRes3(
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……。相変わらず余裕がないですね。……でも、まぁ、そのやる気は評価します。……さっさと飲み干しましょう」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は一気に飲み干すと、キーボードに向かった。どこか寂しそうではあったが。"
			);
			data.setC3Love(-1); data.setC3Like(4);
			break;

		case 14: // 【ケース14：至近距離のエンカウント】
			data.setVisuals(new VisualBeans("Sayuki_focus.png", bgNight, "none", "normal", "night"));
			data.setMessage(
				"[NAME:NONE]深夜。俺が複雑なUIの挙動を調整していると、背後からスッと気配が近づいてきた。" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……そこの処理、もう少しだけアニメーションのイージングを緩やかにできませんか？」" +
				"[NEXT]" +
				"[NAME:PLAYER]（サユキさんが、俺の背後から身を乗り出して画面を覗き込んでいる。……彼女の髪が俺の肩に触れるほど近い）" +
				"[NEXT]" +
				"[NAME:PLAYER]「こんな感じかな？ どう？」" +
				"[NEXT]" +
				"[NAME:NONE]俺が何気なく振り返った――その瞬間。" +
				"[NEXT]" +
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「えっ……」" +
				"[NEXT]" +
				"[NAME:NONE]お互いの鼻先が触れそうなほどの至近距離で、視線が完全に交差した。彼女の甘い吐息が頬をかすめる。"
			);
			data.setChoice1Text("（そのまま、数秒間見つめ合ってしまう）");
			data.setChoice2Text("ごめん！ 近すぎたね");
			data.setChoice3Text("……サユキさん、顔赤いよ？");

			data.setRes1(
				"[IMG:Sayuki_surprised.png]" +
				"[NAME:SAYUKI]「っ……！ ～～～っ！！」" +
				"[NEXT]" +
				"[IMG:Sayuki_mesorasi.png]" +
				"[NAME:SAYUKI]「……ち、近いです……っ。……ばか。……心臓、止まるかと……っ」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は弾かれたように後ずさり、顔を真っ赤にして口元を覆った。だが、その視線は俺から離れようとはしなかった。完全に一人の異性として意識している。"
			);
			data.setC1Love(5); data.setC1Like(0); // 【Love最大】言葉のない見つめ合い

			data.setRes2(
				"[IMG:Sayuki_dakara_syomen.png]" +
				"[NAME:SAYUKI]「……っ。……別に、あなたが急に振り返るから驚いただけです」" +
				"[NEXT]" +
				"[NAME:SAYUKI]「……もう、後ろから画面見るのやめます。作業の邪魔ですよね、すみません」" +
				"[NEXT]" +
				"[NAME:NONE]俺が過剰に避けたことで、彼女は少し傷ついたように自分の席へ戻ってしまった。"
			);
			data.setC2Love(-3); data.setC2Like(-1); // 【大失敗】過剰な拒絶

			data.setRes3(
				"[IMG:Sayuki_jitome.png]" +
				"[NAME:SAYUKI]「……は？ 赤くなんてなってません。モニターの光の反射です」" +
				"[NEXT]" +
				"[IMG:Sayuki_dakara.png]" +
				"[NAME:SAYUKI]「……そういうデリカシーのないからかい方、本当に嫌われますよ。仕事に戻ってください」" +
				"[NEXT]" +
				"[NAME:NONE]彼女は不機嫌そうに言い捨てたが、その足取りはどこか逃げるように早かった。"
			);
			data.setC3Love(2); data.setC3Like(-2); // 【Loveは上がるがLikeは下がる】
			data.setRes3Visuals(new VisualBeans("Sayuki_dakara.png", bgNight, "cross_fade", "close_up", "night"));
			break;
		default:
			return super.getScenario(0, pName);
		}
		return data;
	}
}