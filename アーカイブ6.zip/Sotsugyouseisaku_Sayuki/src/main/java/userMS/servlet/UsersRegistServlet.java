package userMS.servlet;

import java.io.IOException;
import java.time.LocalDate;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import userMS.model.beans.UsersBeans;
import userMS.model.bo.UserLogic;

@WebServlet("/UsersRegistServlet")
public class UsersRegistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UsersRegistServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// login入力画面へforwardする
		RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/jsp/Login/regist.jsp");

		// forwardを実行する
		rd.forward(request, response);
	}

	// 登録処理
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");

		// 1. 入力値を取得してBeansに詰める
		String id = request.getParameter("id");
		String hn = request.getParameter("hn");
		String pass = request.getParameter("pass");
		LocalDate bday = LocalDate.parse(request.getParameter("birthday"));

		UsersBeans ub = new UsersBeans(id, hn, pass, bday, null);

		// 2. BOに丸投げ（戻り値を boolean に変更し、requestは渡さない）
		boolean isSuccess = UserLogic.usersRegist(ub);

		// 3. 結果を見て画面を切り替える
		if (isSuccess) {
		    // 登録したばかりの情報をそのままセッションに入れる
		    HttpSession session = request.getSession();
		    session.setAttribute("loginUser", ub); 
		    
		    // そのままメイン画面へワープ！
		    response.sendRedirect("MainServlet");
		    return;
		} else {
			
			// 【失敗時】エラーメッセージを持って登録画面（regist.jsp）に戻る
			String errorMsg = "<p style=\"color:red\">※ 登録に失敗しました。IDが既に使われている可能性があります。</p>";
			request.setAttribute("errorMsg", errorMsg);
			request.setAttribute("ub", ub); 

			RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/jsp/Login/regist.jsp");
			rd.forward(request, response);
		}
	}

}
