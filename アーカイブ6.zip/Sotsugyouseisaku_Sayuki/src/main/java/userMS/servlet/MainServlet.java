package userMS.servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import sayukiGame.model.beans.Sayuki_Sakota;
import sayukiGame.model.dao.SayukiGameDAO;
import userMS.model.beans.UsersBeans;

@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 1. セッションからユーザー情報を取得
		HttpSession session = request.getSession();
		UsersBeans loginUser = (UsersBeans) session.getAttribute("loginUser");

		if (loginUser == null) {
			response.sendRedirect("UsersLoginServlet");
			return;
		}

		// 2. セーブデータの存在確認とスロット情報の取得
		boolean hasSaveData = false;
		if (!"guest".equals(loginUser.getId())) {
			SayukiGameDAO dao = new SayukiGameDAO();

			// 💡 いずれかのスロットにデータがあるか（CONTINUEボタンの有効化判定用）
			hasSaveData = dao.checkSaveDataExists(loginUser.getId());

			// 🌟 追加：全スロットのデータを取得してJSPへ渡す（ロード画面の表示用）
			List<Sayuki_Sakota> saveSlots = dao.getAllSlots(loginUser.getId());
			request.setAttribute("saveSlots", saveSlots);
		}

		// 3. 結果をリクエストスコープにセット
		request.setAttribute("hasSaveData", hasSaveData);

		// 💡 SaveGameServletから戻ってきた時の通知用
		String saveSuccess = request.getParameter("saveSuccess");
		if ("true".equals(saveSuccess)) {
			request.setAttribute("infoMsg", "ゲームの進行状況を保存しました。");
		}

		// 4. JSP(main.jsp)へフォワード
		request.getRequestDispatcher("WEB-INF/jsp/main.jsp").forward(request, response);
	}
}