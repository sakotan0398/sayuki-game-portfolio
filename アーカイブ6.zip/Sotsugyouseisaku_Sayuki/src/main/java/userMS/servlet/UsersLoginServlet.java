package userMS.servlet;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import userMS.model.beans.UsersBeans;
import userMS.model.bo.UserLogic;

@WebServlet("/UsersLoginServlet")
public class UsersLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UsersLoginServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// ゲストログイン
		// 目印（action）を受け取る
		// 1. まず「合言葉」を確認する
		String action = request.getParameter("action");

		// --- 【ゲストログイン処理】 ---
		if ("guest".equals(action)) {
			UsersBeans guestUser = new UsersBeans("guest", "ゲスト", "", LocalDate.now(), LocalDateTime.now());
			HttpSession session = request.getSession();
			// ★名前を "loginUser" に統一して、MainServletの門番を通れるようにする
			session.setAttribute("loginUser", guestUser);

			response.sendRedirect("MainServlet");

			return; // 処理終了！
		}

		// --- 【ログアウト処理】 ---
		if ("logout".equals(action)) {
			HttpSession session = request.getSession();
			session.invalidate(); // セッション破棄
			// 破棄した後は、パラメータなしの自分に戻る（これで無限ループ回避）
			response.sendRedirect("UsersLoginServlet");
			return;
		}

		// ここでJSPを呼び出す
		RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/jsp/Login/Login_main.jsp");

		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// ログイン
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		String pass = request.getParameter("pass");

		UsersBeans usersBeans = new UsersBeans(id, pass);
		UsersBeans ub = UserLogic.login(usersBeans); // BOを呼び出し

		if (ub != null) {
			// セッションに保存して、メイン画面へリダイレクト
			HttpSession session = request.getSession();
			session.setAttribute("loginUser", ub);

			// MainServlet という名前のサーブレットがある前提です
			response.sendRedirect("MainServlet");
			return;

		} else {
			// 【失敗】エラーメッセージをセットして、ログイン画面へ「フォワード」
			String errorMsg = "<p style=\"color:red\">※ IDまたはパスワードが違います</p>";
			request.setAttribute("errorMsg", errorMsg);

			RequestDispatcher dr = request.getRequestDispatcher("WEB-INF/jsp/Login/Login_main.jsp");
			dr.forward(request, response);
			return;
		}
	}
}