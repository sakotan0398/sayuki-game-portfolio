package userMS.model.bo; 

import userMS.model.beans.UsersBeans;
import userMS.model.dao.UsersDAO;

public class UserLogic {

	/**
	 * 会員登録処理を実行する（IDの半角英数字チェック付き）
	 * @param ub 登録情報入りのBeans
	 * @return 登録成功時はtrue、入力エラーまたはDB登録失敗時はfalse
	 */
	public static boolean usersRegist(UsersBeans ub) {
		// 1. Beansから入力されたログインIDを取り出す
		String userId = ub.getId();

		// 2. 半角英数字かつ「4文字以上20文字以下」のみを許可する正規表現のパターン
		// ※文字数を制限しない場合は "^[a-zA-Z0-9]+$" でもOK
		String idPattern = "^[a-zA-Z0-9]{4,20}$";

		// 3. 二重チェック：IDが未入力、または半角英数字パターンに一致しない場合は即登録拒否
		if (userId == null || !userId.matches(idPattern)) {
			System.out.println("【システム警告】無効なID形式（日本語や不正な文字数）を検知したため、登録をブロックしました: " + userId);
			return false; // DAO（職人）に回す前に、ここで即座に処理を打ち切る
		}

		// 4. チェックをクリアした安全なデータのみ、職人（DAO）に丸投げする
		return UsersDAO.usersRegist(ub);
	}

	/**
	 * ログイン処理を実行する
	 * @param inputUser JSPから送られてきたID/PASS入りのBeans
	 * @return ログイン成功時はDBから取得した全情報入りBeans、失敗時はnull
	 */
	public static UsersBeans login(UsersBeans inputUser) {
		// DAOを呼び出してデータを探す
		UsersDAO dao = new UsersDAO();
		UsersBeans loginUser = dao.findUser(inputUser);        
		
		return loginUser;
	}
}