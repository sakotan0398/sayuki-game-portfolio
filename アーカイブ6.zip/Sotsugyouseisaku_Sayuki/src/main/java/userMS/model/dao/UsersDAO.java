package userMS.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;

import userMS.model.beans.UsersBeans;

public class UsersDAO {

	// 接続情報
	private static final String URL = "jdbc:mysql://localhost:3306/sayuki_page";
	private static final String USER = "root";
	private static final String PASS = "1234";

	public static boolean usersRegist(UsersBeans ub) {

	    // 登録成功時：true / 失敗時：false
	    boolean result = false;

	    // MySQLのドライバーを呼び出す
	    mySqlDriver();

	    String sql = "INSERT INTO users (id, hn, pass, birthday, created_at) VALUES (?, ?, ?, ?, NOW())";

	    // 【ポイント】ps も try のカッコ内に入れることで、自動クローズ（安全）にする
	    try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
	         PreparedStatement ps = conn.prepareStatement(sql)) {

	        // ? に値をセット
	        ps.setString(1, ub.getId());
	        ps.setString(2, ub.getHn());
	        ps.setString(3, ub.getPass());
	        ps.setDate(4, java.sql.Date.valueOf(ub.getBirthday()));

	        // デバッグ用：実行されるSQLをコンソールに表示
	        System.out.println("実行SQL: " + ps.toString());

	        // SQL実行（戻り値は「追加された行数」）
	        int count = ps.executeUpdate();

	        // 1行追加 成功
	        if (count == 1) {
	            result = true;
	        }

	    } catch (SQLException e) {
	        // エラーが出たらコンソールに詳細を出す
	        e.printStackTrace();
	    }
	    
	    return result; // 最終的な成否を返す
	}

	// ログイン
	public UsersBeans findUser(UsersBeans inputUser) {

		// MySQLのドライバーを呼び出す
		mySqlDriver();

		// UsersBeansの変数を宣言する
		// nullで初期化する
		UsersBeans usersBeans = null;

		// SQL文
		String sql = "SELECT * FROM users WHERE ID = ? AND PASS = ?"; // MySQLサーバーに接続する
		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);

				// connにsetする
				PreparedStatement ps = conn.prepareStatement(sql)) {

			// ? に値をセット
			ps.setString(1, inputUser.getId());
			ps.setString(2, inputUser.getPass());

			// 実行
			ResultSet rs = ps.executeQuery();

			// 一致するユーザーがいたら、Beansに詰め直す
			if (rs.next()) {
				String id = rs.getString("ID");
				String hn = rs.getString("HN");
				String pass = rs.getString("PASS");

				// LocalDate/LocalDateTimeへの変換（getObjectを使うのが現代的です）
				LocalDate birthday = rs.getObject("BIRTHDAY", LocalDate.class);
				LocalDateTime createdAt = rs.getObject("CREATED_AT", LocalDateTime.class);

				usersBeans = new UsersBeans(id, hn, pass, birthday, createdAt);
			}

		} catch (SQLException e) {

			e.printStackTrace();
			return null;
		}
		return usersBeans; // 見つからなければ null、見つかればユーザー情報を返す

	} // MySQLのドライバーを呼び出す

	public static void mySqlDriver() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

		} catch (ClassNotFoundException e) {
			System.out.println("ドライバーが読み込めません");

		}
	}
}