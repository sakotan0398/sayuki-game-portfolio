package userMS.model.beans;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class UsersBeans implements Serializable{
	
	// フィールド
	private String 			id;
	private String 			hn;
	private String 			pass;
	private LocalDate		birthday;
	private LocalDateTime 	created_at;
	
	
	// ログインで使うコンストラクタ
	public UsersBeans(String id, String pass) {
		super();
		this.id = id;
		this.pass = pass;
	}


	// ログイン後のコンストラクタ
	public UsersBeans(String id, String hn, String pass, LocalDate birthday, LocalDateTime created_at) {
		super();
		this.id = id;
		this.hn = hn;
		this.pass = pass;
		this.birthday = birthday;
		this.created_at = created_at;
	}

	
	// getter setter
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getHn() {
		return hn;
	}

	public void setHn(String hn) {
		this.hn = hn;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public LocalDate getBirthday() {
		return birthday;
	}

	public void setBirthday(LocalDate birthday) {
		this.birthday = birthday;
	}

	public LocalDateTime getCreated_at() {
		return created_at;
	}

	public void setCreated_at(LocalDateTime created_at) {
		this.created_at = created_at;
	}

}
